import React, { useEffect, useState, useCallback } from "react";
import {
  LayoutDashboard,
  MessageSquare,
  FileText,
  Cpu,
  Users,
  History,
  LogOut,
  Wrench,
} from "lucide-react";
import { LoginView } from "./components/LoginView.tsx";
import { AssistantView } from "./components/AssistantView.tsx";
import { ManualManagementView } from "./components/ManualManagementView.tsx";
import {
  AdminDashboardView,
  EngineerDashboardView,
  SupervisorDashboardView,
} from "./components/DashboardsView.tsx";
import {
  MachineManagementView,
  QueryHistoryView,
  UserManagementView,
} from "./components/AdminRegistryViews.tsx";
import type { MachineRecord, ManualRecord, UserRecord } from "./types.ts";

export function App() {
  const [user, setUser] = useState<UserRecord | null>(null);
  const [token, setToken] = useState<string>("");
  const [activeView, setActiveView] = useState<string>("dashboard");
  const [selectedMachineCode, setSelectedMachineCode] = useState<string>("HP200");
  const [machines, setMachines] = useState<MachineRecord[]>([]);
  const [manuals, setManuals] = useState<ManualRecord[]>([]);

  const refreshMachinesAndManuals = useCallback(async (authToken: string) => {
    if (!authToken) return;
    try {
      const [machRes, manRes] = await Promise.all([
        fetch("/api/machines/", {
          headers: { Authorization: `Bearer ${authToken}` },
        }),
        fetch("/api/manuals/", {
          headers: { Authorization: `Bearer ${authToken}` },
        }),
      ]);
      if (machRes.ok) {
        const machData = await machRes.json();
        if (Array.isArray(machData)) setMachines(machData);
      }
      if (manRes.ok) {
        const manData = await manRes.json();
        if (Array.isArray(manData)) setManuals(manData);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (token) {
      refreshMachinesAndManuals(token);
    }
  }, [token, refreshMachinesAndManuals]);

  const handleLoginSuccess = (loggedInUser: UserRecord, authToken: string) => {
    setUser(loggedInUser);
    setToken(authToken);
    setActiveView("dashboard");
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout/", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch {}
    setUser(null);
    setToken("");
    setActiveView("dashboard");
  };

  const handleNavigate = (view: string, machineCode?: string) => {
    if (machineCode) {
      setSelectedMachineCode(machineCode);
    }
    setActiveView(view);
  };

  if (!user) {
    return <LoginView onLoginSuccess={handleLoginSuccess} />;
  }

  const getRoleNavItems = (
    role: UserRecord["role"]
  ): Array<{ id: string; label: string; icon: React.ReactNode }> => {
    if (role === "ENGINEER") {
      return [
        {
          id: "dashboard",
          label: "Overview",
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: "assistant",
          label: "AI Assistant",
          icon: <MessageSquare className="w-4 h-4" />,
        },
        {
          id: "history",
          label: "Query History",
          icon: <History className="w-4 h-4" />,
        },
      ];
    }

    if (role === "ADMIN") {
      return [
        {
          id: "dashboard",
          label: "Overview",
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: "manuals",
          label: "Manuals",
          icon: <FileText className="w-4 h-4" />,
        },
        {
          id: "machines",
          label: "Machines",
          icon: <Cpu className="w-4 h-4" />,
        },
        {
          id: "users",
          label: "Users",
          icon: <Users className="w-4 h-4" />,
        },
        {
          id: "history",
          label: "Query Monitoring",
          icon: <History className="w-4 h-4" />,
        },
      ];
    }

    // SUPERVISOR
    return [
      {
        id: "dashboard",
        label: "Overview",
        icon: <LayoutDashboard className="w-4 h-4" />,
      },
      {
        id: "history",
        label: "Query Monitoring",
        icon: <History className="w-4 h-4" />,
      },
      {
        id: "manual_status",
        label: "Manual Status",
        icon: <FileText className="w-4 h-4" />,
      },
    ];
  };

  const visibleNavItems = getRoleNavItems(user.role);
  const activeNavLabel =
    visibleNavItems.find((i) => i.id === activeView)?.label ||
    (activeView === "assistant" ? "AI Assistant" : "Overview");

  return (
    <div className="min-h-screen flex flex-col md:flex-row text-slate-900">
      {/* Deep Navy 3D Enterprise Sidebar */}
      <aside className="w-full md:w-64 sidebar-3d text-slate-100 flex flex-col justify-between shrink-0 z-10">
        <div>
          <div className="px-5 py-4 border-b border-slate-800/80 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl icon-3d-blue flex items-center justify-center shrink-0">
              <Wrench className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold tracking-tight text-white truncate">
                Manual Assistant
              </div>
              <div className="text-xs text-slate-400 truncate">
                {user.username} · {user.role}
              </div>
            </div>
          </div>

          <nav aria-label="Main Navigation" className="p-3.5 space-y-1.5">
            {visibleNavItems.map((item) => {
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveView(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? "nav-item-3d-active font-semibold"
                      : "text-slate-300 hover:bg-white/8 hover:text-white"
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-3.5 border-t border-slate-800/80">
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-300 hover:bg-white/8 hover:text-white transition-all cursor-pointer whitespace-nowrap"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="header-3d px-6 py-3.5 flex items-center justify-between gap-8">
          <div className="text-xs font-medium text-slate-500 truncate whitespace-nowrap">
            Manufacturing Manual Assistant <span className="mx-1.5">/</span>{" "}
            <span className="text-slate-900 font-semibold">
              {activeNavLabel}
            </span>
          </div>

          {activeView !== "assistant" && (
            <button
              type="button"
              onClick={() => setActiveView("assistant")}
              className="px-3.5 py-2 btn-3d-primary text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>AI Assistant</span>
            </button>
          )}
        </header>

        <main className="p-6 max-w-7xl w-full mx-auto flex-1">
          {activeView === "dashboard" && user.role === "ADMIN" && (
            <AdminDashboardView
              token={token}
              machines={machines}
              onNavigate={handleNavigate}
            />
          )}
          {activeView === "dashboard" && user.role === "ENGINEER" && (
            <EngineerDashboardView
              user={user}
              token={token}
              machines={machines}
              manuals={manuals}
              onOpenAssistantForMachine={(code) =>
                handleNavigate("assistant", code)
              }
            />
          )}
          {activeView === "dashboard" && user.role === "SUPERVISOR" && (
            <SupervisorDashboardView token={token} />
          )}

          {activeView === "assistant" && (
            <AssistantView
              user={user}
              token={token}
              machines={machines}
              manuals={manuals}
              selectedMachineCode={selectedMachineCode}
              onSelectMachineCode={setSelectedMachineCode}
              onNavigateToUpload={() => setActiveView("manuals")}
            />
          )}

          {activeView === "manuals" && user.role === "ADMIN" && (
            <ManualManagementView
              token={token}
              machines={machines}
              manuals={manuals}
              onManualsChanged={() => refreshMachinesAndManuals(token)}
            />
          )}

          {activeView === "manual_status" && user.role === "SUPERVISOR" && (
            <ManualManagementView
              token={token}
              machines={machines}
              manuals={manuals}
              onManualsChanged={() => refreshMachinesAndManuals(token)}
              readOnly
            />
          )}

          {activeView === "machines" && user.role === "ADMIN" && (
            <MachineManagementView
              token={token}
              machines={machines}
              onMachinesChanged={() => refreshMachinesAndManuals(token)}
            />
          )}

          {activeView === "users" && user.role === "ADMIN" && (
            <UserManagementView token={token} currentUser={user} />
          )}

          {activeView === "history" && (
            <QueryHistoryView
              token={token}
              machines={machines}
              title={
                user.role === "ENGINEER" ? "Query History" : "Query Monitoring"
              }
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;

/**
 * PDF Validation & Page-by-Page Text Extraction Service (Node.js runtime).
 * Preserves exact 1-indexed page numbers, validates %PDF- signature,
 * and detects scanned PDFs with zero extractable text.
 */
import path from "node:path";
import zlib from "node:zlib";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";
import type { ExtractedPageInput } from "./ragEngine.ts";

export interface ExtractedPdfResult {
  total_pages: number;
  pages: ExtractedPageInput[];
}

const STANDARD_FONTS_DIR =
  path.resolve(process.cwd(), "node_modules/pdfjs-dist/standard_fonts") + "/";
const CMAPS_DIR =
  path.resolve(process.cwd(), "node_modules/pdfjs-dist/cmaps") + "/";

export function validatePdfBuffer(buffer: Buffer, maxBytes = 52428800): void {
  if (!buffer || buffer.length === 0) {
    throw new Error("Uploaded PDF file is empty.");
  }
  if (buffer.length > maxBytes) {
    throw new Error(`PDF file size (${buffer.length} bytes) exceeds 50 MB limit.`);
  }
  const header = buffer.subarray(0, 8).toString("latin1");
  if (!header.startsWith("%PDF-")) {
    throw new Error("Invalid file signature: File is not a valid PDF document.");
  }
}

function extractTextFromPdfOperators(streamText: string): string {
  const pieces: string[] = [];
  // Match (text) Tj and [(text) -10 (more)] TJ
  const tjRegex = /\(([^()\\]*(?:\\.[^()\\]*)*)\)\s*Tj/g;
  let match: RegExpExecArray | null;
  while ((match = tjRegex.exec(streamText)) !== null) {
    pieces.push(match[1].replace(/\\([()\\])/g, "$1"));
  }

  const tjArrayRegex = /\[([^\]]+)\]\s*TJ/g;
  while ((match = tjArrayRegex.exec(streamText)) !== null) {
    const inner = match[1];
    const innerStrRegex = /\(([^()\\]*(?:\\.[^()\\]*)*)\)/g;
    let innerMatch: RegExpExecArray | null;
    const lineParts: string[] = [];
    while ((innerMatch = innerStrRegex.exec(inner)) !== null) {
      lineParts.push(innerMatch[1].replace(/\\([()\\])/g, "$1"));
    }
    if (lineParts.length > 0) {
      pieces.push(lineParts.join(""));
    }
  }

  return pieces.join(" ").replace(/\s+/g, " ").trim();
}

export async function extractPdfPagesFromBuffer(
  buffer: Buffer
): Promise<ExtractedPdfResult> {
  validatePdfBuffer(buffer);

  try {
    const uint8 = new Uint8Array(buffer);
    const loadingTask = pdfjsLib.getDocument({
      data: uint8,
      useSystemFonts: true,
      disableFontFace: true,
      standardFontDataUrl: STANDARD_FONTS_DIR,
      cMapUrl: CMAPS_DIR,
      cMapPacked: true,
      verbosity: 0,
    });
    const pdfDoc = await loadingTask.promise;
    const totalPages = pdfDoc.numPages;

    if (totalPages === 0) {
      throw new Error("PDF document contains 0 pages.");
    }

    const pages: ExtractedPageInput[] = [];
    let nonEmptyCount = 0;

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      let lastY: number | null = null;
      const parts: string[] = [];

      for (const item of textContent.items as Array<{
        str?: string;
        transform?: number[];
      }>) {
        const str = item.str ?? "";
        const y = Array.isArray(item.transform) ? item.transform[5] : null;
        if (lastY !== null && y !== null) {
          const dy = Math.abs(y - lastY);
          if (dy > 14) {
            parts.push("\n\n");
          } else if (dy > 5) {
            parts.push("\n");
          } else if (parts.length > 0 && !parts[parts.length - 1].endsWith("\n")) {
            parts.push(" ");
          }
        } else if (parts.length > 0 && !parts[parts.length - 1].endsWith("\n")) {
          parts.push(" ");
        }
        parts.push(str);
        if (y !== null) lastY = y;
      }

      const cleanedPageText = parts
        .join("")
        .replace(/\0/g, "")
        .replace(/([a-zA-Z])-\s*\n\s*([a-zA-Z])/g, "$1-$2")
        .replace(/[ \t]+/g, " ")
        .replace(/\n +/g, "\n")
        .replace(/([^\n.!?])\n(?=[a-z(])/g, "$1 ")
        .replace(/\b(the|a|an|to|of|in|on|for|with|and|or|as|that|by|from|under|after|before)\n(?=[A-Za-z])/gi, "$1 ")
        .replace(/\n{3,}/g, "\n\n")
        .trim();

      if (cleanedPageText.length > 0) {
        nonEmptyCount += 1;
      }
      pages.push({
        page_number: pageNum,
        text: cleanedPageText,
      });
    }

    if (nonEmptyCount === 0) {
      throw new Error(
        "No extractable text found in any page of this PDF. This document appears to be a scanned image PDF; OCR preprocessing is required before indexing."
      );
    }

    return {
      total_pages: totalPages,
      pages,
    };
  } catch (err: any) {
    if (err?.message?.includes("OCR preprocessing is required")) {
      throw err;
    }

    // Fallback parser for uncompressed and FlateDecode PDF streams
    const rawLatin1 = buffer.toString("latin1");
    const pageMatches = rawLatin1.match(/\/Type\s*\/Page\b/g);
    const totalPages = pageMatches ? pageMatches.length : 1;

    const extractedSegments: string[] = [];
    const directText = extractTextFromPdfOperators(rawLatin1);
    if (directText) {
      extractedSegments.push(directText);
    }

    // Also attempt to inflate any compressed stream blocks
    const streamRegex = /stream\r?\n([\s\S]*?)\r?\nendstream/g;
    let sMatch: RegExpExecArray | null;
    while ((sMatch = streamRegex.exec(rawLatin1)) !== null) {
      try {
        const rawStreamBuf = Buffer.from(sMatch[1], "latin1");
        const inflated = zlib.inflateSync(rawStreamBuf).toString("latin1");
        const opsText = extractTextFromPdfOperators(inflated);
        if (opsText) {
          extractedSegments.push(opsText);
        }
      } catch {
        // Ignore non-deflate streams
      }
    }

    const combinedText = extractedSegments.join("\n\n").trim();
    if (!combinedText) {
      throw new Error(
        err?.message ||
          "No extractable text found in this PDF. If the document is scanned, OCR is required."
      );
    }

    return {
      total_pages: Math.max(1, totalPages),
      pages: [
        {
          page_number: 1,
          text: combinedText,
        },
      ],
    };
  }
}

import React, { useEffect, useState } from "react";
import {
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
} from "lucide-react";
import type {
  MachineRecord,
  QueryHistoryRecord,
  UserRecord,
  UserRole,
} from "../types.ts";

interface MachineManagementProps {
  token: string;
  machines: MachineRecord[];
  onMachinesChanged: () => void;
}

export const MachineManagementView: React.FC<MachineManagementProps> = ({
  token,
  machines,
  onMachinesChanged,
}) => {
  const [machineCode, setMachineCode] = useState("");
  const [machineName, setMachineName] = useState("");
  const [manufacturer, setManufacturer] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    if (!machineCode.trim() || !machineName.trim()) {
      setError("Machine Code and Machine Name are required.");
      return;
    }

    try {
      const res = await fetch("/api/machines/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          machine_code: machineCode.trim().toUpperCase(),
          machine_name: machineName.trim(),
          manufacturer: manufacturer.trim(),
          description: description.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Unable to register machine.");
      } else {
        setSuccess(
          `Added machine '${data.machine_code} — ${data.machine_name}'.`
        );
        setMachineCode("");
        setMachineName("");
        setManufacturer("");
        setDescription("");
        onMachinesChanged();
      }
    } catch (err: any) {
      setError(err?.message || "Failed to register machine.");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Machines</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Manage industrial equipment and documentation scope
        </p>
      </div>

      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Add Machine
        </h2>
        {error && (
          <div className="mb-3 p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-3 p-2.5 stat-3d-emerald rounded-xl text-xs text-emerald-900">
            {success}
          </div>
        )}
        <form
          onSubmit={handleCreate}
          className="grid grid-cols-1 md:grid-cols-4 gap-3.5 items-end"
        >
          <div>
            <label
              htmlFor="new-machine-code"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Machine Code
            </label>
            <input
              id="new-machine-code"
              type="text"
              value={machineCode}
              onChange={(e) => setMachineCode(e.target.value)}
              placeholder="e.g. CNC500"
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            />
          </div>
          <div>
            <label
              htmlFor="new-machine-name"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Machine Name
            </label>
            <input
              id="new-machine-name"
              type="text"
              value={machineName}
              onChange={(e) => setMachineName(e.target.value)}
              placeholder="e.g. CNC-500 Milling Center"
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            />
          </div>
          <div>
            <label
              htmlFor="new-machine-mfg"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Manufacturer
            </label>
            <input
              id="new-machine-mfg"
              type="text"
              value={manufacturer}
              onChange={(e) => setManufacturer(e.target.value)}
              placeholder="Manufacturer name"
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            />
          </div>
          <div>
            <button
              type="submit"
              className="w-full py-2.5 px-4 btn-3d-primary text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Add Machine</span>
            </button>
          </div>
          <div className="md:col-span-4">
            <label
              htmlFor="new-machine-desc"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Description
            </label>
            <input
              id="new-machine-desc"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Equipment summary..."
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            />
          </div>
        </form>
      </div>

      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Registered Machines ({machines.length})
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2.5 pr-3 font-medium">Code</th>
                <th className="py-2.5 px-3 font-medium">Machine Name</th>
                <th className="py-2.5 px-3 font-medium">Manufacturer</th>
                <th className="py-2.5 px-3 font-medium">Description</th>
                <th className="py-2.5 pl-3 font-medium text-right">
                  Indexed Manuals
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {machines.map((m) => (
                <tr key={m.id} className="hover:bg-blue-50/40 transition-colors">
                  <td className="py-3 pr-3 font-mono font-bold text-blue-700">
                    {m.machine_code}
                  </td>
                  <td className="py-3 px-3 font-semibold text-slate-900">
                    {m.machine_name}
                  </td>
                  <td className="py-3 px-3 text-slate-600">
                    {m.manufacturer || "—"}
                  </td>
                  <td className="py-3 px-3 text-slate-600">{m.description}</td>
                  <td className="py-3 pl-3 text-right font-bold text-slate-900 tabular-nums">
                    {m.completed_manual_count ?? 0}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

interface UserManagementProps {
  token: string;
  currentUser: UserRecord;
}

export const UserManagementView: React.FC<UserManagementProps> = ({
  token,
  currentUser,
}) => {
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<UserRole>("ENGINEER");
  const [feedback, setFeedback] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const loadUsers = () => {
    fetch("/api/users/", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : []))
      .then((d) => {
        if (Array.isArray(d)) setUsers(d);
      })
      .catch(() => {});
  };

  useEffect(() => {
    loadUsers();
  }, [token]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!username.trim() || !email.trim() || password.length < 8) {
      setFeedback({
        type: "error",
        text: "Username, email, and a password of at least 8 characters are required.",
      });
      return;
    }

    try {
      const res = await fetch("/api/users/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          username: username.trim(),
          email: email.trim(),
          password,
          role,
          is_active: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFeedback({
          type: "error",
          text: data.error || "Unable to create user.",
        });
      } else {
        setFeedback({
          type: "success",
          text: `Created user '${data.username}' (${data.role}).`,
        });
        setUsername("");
        setEmail("");
        setPassword("");
        setRole("ENGINEER");
        loadUsers();
      }
    } catch (err: any) {
      setFeedback({ type: "error", text: err?.message || "Error creating user." });
    }
  };

  const handleRoleChange = async (userId: number, newRole: UserRole) => {
    setFeedback(null);
    const res = await fetch(`/api/users/${userId}/`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ role: newRole }),
    });
    if (res.ok) {
      loadUsers();
    } else {
      const err = await res.json();
      setFeedback({ type: "error", text: err.error || "Failed to update role." });
    }
  };

  const handleToggleActive = async (u: UserRecord) => {
    setFeedback(null);
    const res = await fetch(`/api/users/${u.id}/`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ is_active: !u.is_active }),
    });
    if (res.ok) {
      loadUsers();
    } else {
      const err = await res.json();
      setFeedback({
        type: "error",
        text: err.error || "Failed to update user status.",
      });
    }
  };

  const handleDeleteUser = async (u: UserRecord) => {
    setFeedback(null);
    const res = await fetch(`/api/users/${u.id}/`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      loadUsers();
    } else {
      const err = await res.json();
      setFeedback({ type: "error", text: err.error || "Failed to delete user." });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Users</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Manage user accounts and role assignments
        </p>
      </div>

      {/* Create User Form */}
      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Add User
        </h2>
        {feedback && (
          <div
            role="alert"
            className={`mb-4 p-3 rounded-xl text-xs flex items-center gap-2 ${
              feedback.type === "success"
                ? "stat-3d-emerald text-emerald-900"
                : "bg-red-50 border border-red-200 text-red-800"
            }`}
          >
            {feedback.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{feedback.text}</span>
          </div>
        )}

        <form
          onSubmit={handleCreateUser}
          className="grid grid-cols-1 md:grid-cols-5 gap-3.5 items-end"
        >
          <div>
            <label
              htmlFor="new-user-username"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Username
            </label>
            <input
              id="new-user-username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="jdoe"
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            />
          </div>
          <div>
            <label
              htmlFor="new-user-email"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Email
            </label>
            <input
              id="new-user-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jdoe@company.com"
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            />
          </div>
          <div>
            <label
              htmlFor="new-user-password"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Password
            </label>
            <div className="relative">
              <input
                id="new-user-password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min. 8 characters"
                className="w-full pl-3 pr-9 py-2 text-sm input-3d rounded-xl"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="absolute right-2.5 top-2 p-0.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
          <div>
            <label
              htmlFor="new-user-role"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Role
            </label>
            <select
              id="new-user-role"
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full px-3 py-2 text-sm input-3d rounded-xl"
            >
              <option value="ENGINEER">ENGINEER</option>
              <option value="SUPERVISOR">SUPERVISOR</option>
              <option value="ADMIN">ADMIN</option>
            </select>
          </div>
          <div>
            <button
              type="submit"
              className="w-full py-2.5 px-4 btn-3d-primary text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Add User</span>
            </button>
          </div>
        </form>
      </div>

      {/* Users Table */}
      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Accounts ({users.length})
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2.5 pr-3 font-medium">Username</th>
                <th className="py-2.5 px-3 font-medium">Email</th>
                <th className="py-2.5 px-3 font-medium">Role</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 pl-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-blue-50/40 transition-colors">
                  <td className="py-3 pr-3 font-semibold text-slate-900">
                    {u.username}
                  </td>
                  <td className="py-3 px-3 text-slate-600">{u.email}</td>
                  <td className="py-3 px-3">
                    <select
                      aria-label={`Role for ${u.username}`}
                      value={u.role}
                      onChange={(e) =>
                        handleRoleChange(u.id, e.target.value as UserRole)
                      }
                      className="px-2.5 py-1 text-xs input-3d rounded-lg font-medium"
                    >
                      <option value="ADMIN">ADMIN</option>
                      <option value="ENGINEER">ENGINEER</option>
                      <option value="SUPERVISOR">SUPERVISOR</option>
                    </select>
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={
                        u.is_active
                          ? "text-emerald-700 font-semibold"
                          : "text-red-700 font-semibold"
                      }
                    >
                      {u.is_active ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="py-3 pl-3 text-right">
                    {u.id !== currentUser.id && (
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleActive(u)}
                          className="px-2.5 py-1 btn-3d-secondary rounded-lg cursor-pointer whitespace-nowrap"
                        >
                          {u.is_active ? "Deactivate" : "Activate"}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteUser(u)}
                          aria-label={`Delete user ${u.username}`}
                          className="px-2.5 py-1 btn-3d-danger rounded-lg inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

interface QueryHistoryViewProps {
  token: string;
  machines: MachineRecord[];
  title?: string;
}

export const QueryHistoryView: React.FC<QueryHistoryViewProps> = ({
  token,
  machines,
  title = "Query Monitoring",
}) => {
  const [items, setItems] = useState<QueryHistoryRecord[]>([]);
  const [machineFilter, setMachineFilter] = useState("");
  const [confidenceFilter, setConfidenceFilter] = useState("");

  useEffect(() => {
    const params = new URLSearchParams();
    if (machineFilter) params.set("machine_id", machineFilter);
    if (confidenceFilter) params.set("confidence_status", confidenceFilter);

    fetch(`/api/assistant/history/?${params.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : []))
      .then((d) => {
        if (Array.isArray(d)) setItems(d);
      })
      .catch(() => {});
  }, [token, machineFilter, confidenceFilter]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{title}</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Review technical questions, responses, and cited manual pages
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <select
            aria-label="Filter by machine"
            value={machineFilter}
            onChange={(e) => setMachineFilter(e.target.value)}
            className="px-3 py-1.5 text-xs input-3d rounded-xl font-medium"
          >
            <option value="">All Machines</option>
            {machines.map((m) => (
              <option key={m.id} value={m.machine_code}>
                {m.machine_code} — {m.machine_name}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by confidence status"
            value={confidenceFilter}
            onChange={(e) => setConfidenceFilter(e.target.value)}
            className="px-3 py-1.5 text-xs input-3d rounded-xl font-medium"
          >
            <option value="">All Statuses</option>
            <option value="SUPPORTED">Grounded</option>
            <option value="INSUFFICIENT_EVIDENCE">Insufficient Evidence</option>
          </select>
        </div>
      </div>

      <div className="space-y-3">
        {items.length === 0 ? (
          <div className="card-3d rounded-2xl p-8 text-center text-xs text-slate-500">
            No query records found.
          </div>
        ) : (
          items.map((q) => (
            <div
              key={q.id}
              className="card-3d rounded-2xl p-4 space-y-2.5"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                <div>
                  <span className="font-semibold text-slate-800">
                    {q.username}
                  </span>{" "}
                  ·{" "}
                  <span className="font-mono font-bold text-blue-700">
                    {q.machine_code}
                  </span>{" "}
                  ({q.machine_name})
                </div>
                <div className="tabular-nums">
                  <span
                    className={
                      q.confidence_status === "SUPPORTED"
                        ? "text-emerald-700 font-semibold"
                        : "text-amber-700 font-semibold"
                    }
                  >
                    {q.confidence_status === "SUPPORTED"
                      ? "Grounded"
                      : "Insufficient Evidence"}
                  </span>{" "}
                  · {new Date(q.created_at).toLocaleString()}
                </div>
              </div>

              <div className="text-sm font-semibold text-slate-900">
                {q.question}
              </div>
              <div className="text-xs text-slate-700 whitespace-pre-wrap leading-relaxed well-3d rounded-xl p-3">
                {q.generated_answer}
              </div>

              {q.citations && q.citations.length > 0 && (
                <div className="text-xs text-slate-600 pt-1">
                  <span className="font-semibold text-slate-700">Sources: </span>
                  {q.citations
                    .map(
                      (c) =>
                        `${c.document_name} (Revision ${c.revision}, Page ${c.page_number})`
                    )
                    .join(" · ")}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

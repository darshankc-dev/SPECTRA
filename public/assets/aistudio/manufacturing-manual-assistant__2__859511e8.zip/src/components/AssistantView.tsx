import React, { useState, useEffect } from "react";
import {
  Send,
  Plus,
  FileText,
  ExternalLink,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  X,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  MessageSquare,
} from "lucide-react";
import type {
  CitationItem,
  MachineRecord,
  ManualRecord,
  QueryHistoryRecord,
  UserRecord,
} from "../types.ts";

interface AssistantViewProps {
  user: UserRecord;
  token: string;
  machines: MachineRecord[];
  manuals: ManualRecord[];
  selectedMachineCode: string;
  onSelectMachineCode: (code: string) => void;
  onNavigateToUpload?: () => void;
}

interface PageModalState {
  manualId: number;
  documentName: string;
  revision: string;
  machineCode: string;
  pageNumber: number;
  supportingText: string;
  pdfUrl: string;
}

function extractSafetyHighlight(answerText: string): string | null {
  const lines = answerText
    .split("\n")
    .map((l) =>
      l
        .replace(/^[•\-*]\s*/, "")
        .replace(/\s*\[[^\]]+\]\s*$/, "")
        .replace(/\s*\([^)]*Page\s+\d+\)\s*$/, "")
        .trim()
    )
    .filter((l) => l.length > 20 && !/^\d+\.\s+/.test(l));

  const prioritySafety = lines.filter((line) =>
    /\b(isolation|stored-energy|lockout|tagout|loto|depressurize|pressurized lines|remove guards|authorized person|return-to-service|hold status|ppe|personal protective|interlock)\b/i.test(
      line
    )
  );
  const chosen =
    prioritySafety.length > 0
      ? prioritySafety
      : lines.filter((line) => /\b(warning|caution|danger|hazard)\b/i.test(line));

  if (chosen.length === 0) return null;
  const unique: string[] = [];
  for (const item of chosen) {
    if (!unique.some((u) => u.toLowerCase() === item.toLowerCase())) {
      unique.push(item);
    }
  }
  return unique[0];
}

async function parseJsonSafe(res: Response): Promise<any> {
  const text = await res.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`Unexpected server response (HTTP ${res.status}).`);
  }
}

export const AssistantView: React.FC<AssistantViewProps> = ({
  user,
  token,
  machines,
  manuals,
  selectedMachineCode,
  onSelectMachineCode,
  onNavigateToUpload,
}) => {
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [historyList, setHistoryList] = useState<QueryHistoryRecord[]>([]);
  const [activeMessages, setActiveMessages] = useState<QueryHistoryRecord[]>([]);
  const [selectedHistoryId, setSelectedHistoryId] = useState<number | null>(null);
  const [expandedPassages, setExpandedPassages] = useState<Record<string, boolean>>({});
  const [pageModal, setPageModal] = useState<PageModalState | null>(null);
  const [modalPageText, setModalPageText] = useState<string>("");
  const [modalLoading, setModalLoading] = useState(false);

  const activeMachine =
    machines.find(
      (m) => m.machine_code.toUpperCase() === selectedMachineCode.toUpperCase()
    ) || machines[0];

  const activeMachineManuals = manuals.filter(
    (m) =>
      activeMachine &&
      m.machine_code.toUpperCase() === activeMachine.machine_code.toUpperCase() &&
      m.processing_status === "COMPLETED"
  );

  useEffect(() => {
    if (!activeMachine) return;
    fetch(`/api/assistant/history?machine_id=${activeMachine.machine_code}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        if (Array.isArray(data)) {
          setHistoryList(data);
          setActiveMessages(data.slice().reverse());
          setSelectedHistoryId(null);
        }
      })
      .catch(() => {});
  }, [activeMachine?.machine_code, token]);

  const handleMachineChange = (newCode: string) => {
    setError(null);
    setSelectedHistoryId(null);
    onSelectMachineCode(newCode);
  };

  const handleNewConversation = () => {
    setSelectedHistoryId(null);
    setActiveMessages([]);
    setQuestion("");
    setError(null);
  };

  const handleSelectHistoryItem = (item: QueryHistoryRecord) => {
    setSelectedHistoryId(item.id);
    setActiveMessages([item]);
    setError(null);
  };

  const submitQuestionText = async (rawQuestion: string) => {
    if (!activeMachine || loading) return;
    const trimmed = rawQuestion.trim();
    if (trimmed.length < 3) {
      setError("Please enter a question of at least 3 characters.");
      return;
    }

    setLoading(true);
    setError(null);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
      const res = await fetch("/api/assistant/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          machine_id: activeMachine.machine_code,
          question: trimmed,
        }),
        signal: controller.signal,
      });
      const data = await parseJsonSafe(res);
      if (!res.ok) {
        setError(data.error || data.detail || "Unable to process question.");
      } else {
        setHistoryList((prev) => [data, ...prev]);
        if (selectedHistoryId !== null) {
          setSelectedHistoryId(null);
          setActiveMessages([data]);
        } else {
          setActiveMessages((prev) => [...prev, data]);
        }
        setQuestion("");
      }
    } catch (err: any) {
      if (err?.name === "AbortError") {
        setError("Request timed out. Please try asking again.");
      } else {
        setError(err?.message || "Unable to reach the assistant service.");
      }
    } finally {
      clearTimeout(timeoutId);
      setLoading(false);
    }
  };

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    await submitQuestionText(question);
  };

  const togglePassage = (key: string) => {
    setExpandedPassages((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const openCitationViewer = async (citation: CitationItem) => {
    setPageModal({
      manualId: citation.manual_id,
      documentName: citation.document_name,
      revision: citation.revision,
      machineCode: citation.machine_id,
      pageNumber: citation.page_number,
      supportingText: citation.supporting_text,
      pdfUrl: `${citation.pdf_url.split("#")[0]}&token=${encodeURIComponent(token)}#page=${citation.page_number}`,
    });
    setModalLoading(true);
    setModalPageText("");
    try {
      const res = await fetch(
        `/api/manuals/${citation.manual_id}/pages?machine_id=${citation.machine_id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.ok) {
        const data = await parseJsonSafe(res);
        const found = (data.pages || []).find(
          (p: { page_number: number; text: string }) =>
            p.page_number === citation.page_number
        );
        setModalPageText(found?.text || citation.supporting_text);
      } else {
        setModalPageText(citation.supporting_text);
      }
    } catch {
      setModalPageText(citation.supporting_text);
    } finally {
      setModalLoading(false);
    }
  };

  const suggestedQuestions =
    activeMachine?.machine_code === "HP200"
      ? [
          "What is the preventive maintenance schedule and hydraulic fluid specification for the HP-200?",
          "What are the standard operating procedures and nominal pressure settings for the HP-200?",
          "How should low hydraulic pressure (E17) or return-filter restriction (E42) be inspected on the HP-200?",
        ]
      : [
          "What are the rated operating parameters and discharge pressure for the AC-90 compressor?",
          "What is the maintenance interval for AC-90 air filters, separator elements, and lubricant?",
          "How should high discharge air temperature on the AC-90 be diagnosed?",
        ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
      {/* Left Column: Selected Machine, New Conversation & Conversation History */}
      <div className="lg:col-span-4 xl:col-span-3 card-3d rounded-2xl p-4 flex flex-col gap-4">
        <div>
          <label
            htmlFor="assistant-machine-selector"
            className="block text-xs font-semibold text-slate-700 mb-1.5"
          >
            Selected Machine
          </label>
          <select
            id="assistant-machine-selector"
            value={activeMachine?.machine_code || ""}
            onChange={(e) => handleMachineChange(e.target.value)}
            className="w-full px-3 py-2 text-sm font-medium input-3d rounded-xl text-slate-900"
          >
            {machines.map((m) => (
              <option key={m.id} value={m.machine_code}>
                {m.machine_code} — {m.machine_name}
              </option>
            ))}
          </select>

          <div className="mt-2.5 flex items-center justify-between text-xs text-slate-500">
            <span>Available Manuals</span>
            <span
              className={`font-semibold ${
                activeMachineManuals.length > 0
                  ? "text-emerald-700"
                  : "text-amber-700"
              }`}
            >
              {activeMachineManuals.length > 0
                ? `${activeMachineManuals.length} Indexed`
                : "None Uploaded"}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleNewConversation}
          className="w-full py-2.5 px-3 btn-3d-primary text-xs font-semibold rounded-xl flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>New Conversation</span>
        </button>

        <div className="pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-600">
              Conversation History ({historyList.length})
            </span>
            {selectedHistoryId !== null && (
              <button
                type="button"
                onClick={() => {
                  setSelectedHistoryId(null);
                  setActiveMessages(historyList.slice().reverse());
                }}
                className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Show All
              </button>
            )}
          </div>

          <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-0.5">
            {historyList.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">
                No recent questions for {activeMachine?.machine_code}.
              </p>
            ) : (
              historyList.map((h) => {
                const isSelected = selectedHistoryId === h.id;
                return (
                  <button
                    key={h.id}
                    type="button"
                    onClick={() => handleSelectHistoryItem(h)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs transition-all cursor-pointer flex items-start gap-2 ${
                      isSelected
                        ? "stat-3d-blue text-blue-950"
                        : "hover:bg-slate-50 text-slate-700 border border-transparent"
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold truncate">{h.question}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center justify-between">
                        <span>{new Date(h.created_at).toLocaleDateString()}</span>
                        <span className="font-medium">
                          {h.confidence_status === "SUPPORTED"
                            ? "Grounded"
                            : "Refused"}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Main Column: Prominent Machine Header, Conversation, Citations & Input */}
      <div className="lg:col-span-8 xl:col-span-9 card-3d rounded-2xl flex flex-col min-h-[640px] overflow-hidden">
        {/* Prominent Machine Context Header */}
        <div className="px-6 py-4 border-b border-slate-200/80 bg-gradient-to-r from-slate-50/90 via-blue-50/40 to-indigo-50/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-xs font-mono font-bold text-blue-700">
                {activeMachine?.machine_code}
              </span>
              <span className="text-slate-300">·</span>
              <h1 className="text-base font-bold text-slate-900">
                {activeMachine?.machine_name || "Select a Machine"}
              </h1>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {activeMachineManuals.length > 0
                ? `Active Sources: ${activeMachineManuals
                    .map((m) => `${m.document_name} (${m.revision})`)
                    .join(" · ")}`
                : "No indexed manuals available for this machine."}
            </p>
          </div>

          {activeMachineManuals.length === 0 &&
            user.role === "ADMIN" &&
            onNavigateToUpload && (
              <button
                type="button"
                onClick={onNavigateToUpload}
                className="px-3.5 py-2 btn-3d-primary text-xs font-semibold rounded-xl shrink-0 cursor-pointer whitespace-nowrap"
              >
                Upload Manuals
              </button>
            )}
        </div>

        {/* Manual Availability Notice when 0 manuals are indexed */}
        {activeMachineManuals.length === 0 && (
          <div className="mx-6 mt-4 p-3.5 stat-3d-amber rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900 leading-relaxed">
              <span className="font-semibold">Manuals awaiting upload:</span>{" "}
              Official PDF manuals for{" "}
              <span className="font-semibold">{activeMachine?.machine_name}</span>{" "}
              have not been uploaded yet. The assistant will decline to answer
              until official documentation is indexed.
            </div>
          </div>
        )}

        {/* Conversation Feed */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6 max-h-[540px]">
          {activeMessages.length === 0 ? (
            <div className="py-10 max-w-lg mx-auto text-center space-y-5">
              <div className="w-12 h-12 rounded-2xl icon-3d-blue flex items-center justify-center mx-auto">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900">
                  Ask a Question About {activeMachine?.machine_name}
                </h2>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Answers are generated exclusively from indexed{" "}
                  {activeMachine?.machine_code} manuals and include verifiable
                  document citations.
                </p>
              </div>
              <div className="space-y-2 text-left">
                <div className="text-xs font-semibold text-slate-600">
                  Suggested questions:
                </div>
                {suggestedQuestions.map((promptText, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setQuestion(promptText)}
                    className="w-full text-left p-3 text-xs text-slate-700 btn-3d-secondary rounded-xl cursor-pointer"
                  >
                    {promptText}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            activeMessages.map((item) => {
              const safetyNote =
                item.confidence_status === "SUPPORTED"
                  ? extractSafetyHighlight(item.generated_answer)
                  : null;

              return (
                <div
                  key={item.id}
                  className="space-y-3 pb-6 border-b border-slate-100 last:border-b-0 last:pb-0"
                >
                  {/* User Question */}
                  <div className="well-3d rounded-xl p-3.5">
                    <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                      <span className="font-semibold text-slate-700">
                        {item.username}
                      </span>
                      <span className="tabular-nums">
                        {item.machine_code} ·{" "}
                        {new Date(item.created_at).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                    <div className="text-sm font-semibold text-slate-900">
                      {item.question}
                    </div>
                  </div>

                  {/* Grounded Technical Answer */}
                  <div className="card-3d rounded-xl p-4 space-y-4">
                    <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                      <span className="text-xs font-bold text-slate-700">
                        Technical Response ({item.machine_code})
                      </span>
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                          item.confidence_status === "SUPPORTED"
                            ? "text-emerald-700"
                            : "text-amber-700"
                        }`}
                      >
                        {item.confidence_status === "SUPPORTED" ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                        )}
                        <span>
                          {item.confidence_status === "SUPPORTED"
                            ? "Verified in Manual"
                            : "Insufficient Manual Evidence"}
                        </span>
                      </span>
                    </div>

                    {/* Safety Callout when supported */}
                    {safetyNote && (
                      <div className="p-3 stat-3d-amber rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
                        <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold">Safety Precaution: </span>
                          <span>{safetyNote}</span>
                        </div>
                      </div>
                    )}

                    <div className="text-sm text-slate-800 whitespace-pre-wrap leading-relaxed">
                      {item.generated_answer}
                    </div>

                    {/* Document Citations & Expandable Evidence */}
                    {item.citations && item.citations.length > 0 && (
                      <div className="pt-3 border-t border-slate-100 space-y-2.5">
                        <div className="text-xs font-bold text-slate-600">
                          Document Citations ({item.citations.length})
                        </div>
                        <div className="space-y-2">
                          {item.citations.map((cit, cIdx) => {
                            const passageKey = `${item.id}_${cIdx}`;
                            const isExpanded = !!expandedPassages[passageKey];
                            return (
                              <div
                                key={passageKey}
                                className="well-3d rounded-xl p-3 text-xs space-y-2"
                              >
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div className="text-slate-800 flex flex-wrap items-center gap-x-2 gap-y-1">
                                    <span className="font-semibold text-slate-900">
                                      {cit.document_name}
                                    </span>
                                    <span className="text-slate-400">·</span>
                                    <span className="text-slate-600">
                                      Revision {cit.revision}
                                    </span>
                                    <span className="text-slate-400">·</span>
                                    <span className="font-bold text-blue-700 tabular-nums">
                                      Page {cit.page_number}
                                    </span>
                                  </div>

                                  <div className="flex items-center gap-2">
                                    <button
                                      type="button"
                                      onClick={() => togglePassage(passageKey)}
                                      className="px-2.5 py-1 btn-3d-secondary rounded-lg flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                    >
                                      {isExpanded ? (
                                        <ChevronDown className="w-3 h-3" />
                                      ) : (
                                        <ChevronRight className="w-3 h-3" />
                                      )}
                                      <span>
                                        {isExpanded
                                          ? "Hide Evidence"
                                          : "Show Evidence"}
                                      </span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => openCitationViewer(cit)}
                                      className="px-2.5 py-1 btn-3d-primary font-semibold rounded-lg flex items-center gap-1 cursor-pointer whitespace-nowrap"
                                    >
                                      <FileText className="w-3 h-3" />
                                      <span>Open Page {cit.page_number}</span>
                                    </button>
                                  </div>
                                </div>

                                {isExpanded && (
                                  <div className="p-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-700 whitespace-pre-wrap leading-relaxed">
                                    {cit.supporting_text}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Question Input Bar */}
        <div className="p-4 border-t border-slate-200/80 bg-slate-50/70">
          {error && (
            <div
              role="alert"
              className="mb-3 p-2.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700"
            >
              {error}
            </div>
          )}

          <form onSubmit={handleAsk} className="flex gap-2.5">
            <input
              type="text"
              aria-label="Technical Question Input"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              disabled={loading}
              placeholder={`Ask a question about ${activeMachine?.machine_name || "the selected machine"}...`}
              className="flex-1 px-4 py-2.5 text-sm input-3d rounded-xl text-slate-900"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 btn-3d-primary text-sm font-semibold rounded-xl flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>{loading ? "Analyzing Manual..." : "Ask Assistant"}</span>
            </button>
          </form>
        </div>
      </div>

      {/* Cited Manual Page Modal Viewer */}
      {pageModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Manual Page Viewer"
          className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4"
        >
          <div className="card-3d rounded-2xl max-w-4xl w-full max-h-[88vh] flex flex-col overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {pageModal.documentName} · Revision {pageModal.revision} · Page{" "}
                  {pageModal.pageNumber}
                </h3>
                <p className="text-xs text-slate-500">
                  Machine: {pageModal.machineCode}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={pageModal.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 btn-3d-secondary text-xs font-semibold rounded-lg flex items-center gap-1.5 whitespace-nowrap"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Original PDF</span>
                </a>
                <button
                  type="button"
                  aria-label="Close modal"
                  onClick={() => setPageModal(null)}
                  className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              <div className="p-3.5 stat-3d-blue rounded-xl">
                <div className="text-xs font-bold text-blue-900 mb-1">
                  Cited Passage (Page {pageModal.pageNumber})
                </div>
                <div className="text-xs text-blue-950 whitespace-pre-wrap leading-relaxed">
                  {pageModal.supportingText}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-slate-700 mb-1.5">
                  Page {pageModal.pageNumber} Full Text
                </div>
                {modalLoading ? (
                  <div className="text-xs text-slate-500 py-4">
                    Loading page {pageModal.pageNumber}...
                  </div>
                ) : (
                  <div className="p-4 well-3d rounded-xl text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                    {modalPageText}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

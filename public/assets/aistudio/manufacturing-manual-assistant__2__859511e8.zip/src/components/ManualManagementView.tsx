import React, { useState } from "react";
import {
  Upload,
  RefreshCw,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Clock,
  FileText,
} from "lucide-react";
import type { MachineRecord, ManualRecord } from "../types.ts";

interface ManualManagementViewProps {
  token: string;
  machines: MachineRecord[];
  manuals: ManualRecord[];
  onManualsChanged: () => void;
  readOnly?: boolean;
}

const OFFICIAL_EXPECTED_MANUALS = [
  {
    machineCode: "HP200",
    machineName: "HP-200 Hydraulic Press",
    documentName: "HP200_Operations_Rev1_0.pdf",
    revision: "Rev1.0",
    purpose: "Operations and safety interlock specifications",
  },
  {
    machineCode: "HP200",
    machineName: "HP-200 Hydraulic Press",
    documentName: "HP200_Maintenance_Rev1_0.pdf",
    revision: "Rev1.0",
    purpose: "Preventive maintenance and hydraulic servicing",
  },
  {
    machineCode: "AC90",
    machineName: "AC-90 Air Compressor",
    documentName: "AC90_Operations_Maintenance_Rev1_0.pdf",
    revision: "Rev1.0",
    purpose: "Operations, maintenance, and troubleshooting",
  },
];

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, Array.from(slice));
  }
  return btoa(binary);
}

async function parseJsonSafe(res: Response): Promise<any> {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(
      `Server returned an unexpected response (HTTP ${res.status}). Please retry.`
    );
  }
}

export const ManualManagementView: React.FC<ManualManagementViewProps> = ({
  token,
  machines,
  manuals,
  onManualsChanged,
  readOnly = false,
}) => {
  const [selectedMachineCode, setSelectedMachineCode] = useState("HP200");
  const [revision, setRevision] = useState("Rev1.0");
  const [documentName, setDocumentName] = useState("");
  const [replaceExisting, setReplaceExisting] = useState(true);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: "success" | "error" | "info";
    text: string;
  } | null>(null);
  const [reprocessingId, setReprocessingId] = useState<number | null>(null);

  const selectOfficialSlot = (slot: (typeof OFFICIAL_EXPECTED_MANUALS)[0]) => {
    setSelectedMachineCode(slot.machineCode);
    setRevision(slot.revision);
    setDocumentName(slot.documentName);
    setReplaceExisting(true);
    setStatusMessage({
      type: "info",
      text: `Selected ${slot.documentName} (${slot.machineCode} · ${slot.revision}). Choose the PDF file below and click Upload PDF.`,
    });
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setStatusMessage({
        type: "error",
        text: "Please select a PDF file before uploading.",
      });
      return;
    }

    setUploading(true);
    setStatusMessage({
      type: "info",
      text: "Uploading and indexing PDF manual...",
    });

    try {
      const arrayBuf = await file.arrayBuffer();
      const fileBase64 = arrayBufferToBase64(arrayBuf);
      const resolvedDocName = documentName.trim()
        ? documentName.trim().toLowerCase().endsWith(".pdf")
          ? documentName.trim()
          : `${documentName.trim()}.pdf`
        : file.name;

      const res = await fetch("/api/manuals/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          machine_id: selectedMachineCode,
          revision: revision.trim() || "Rev1.0",
          document_name: resolvedDocName,
          replace_existing: replaceExisting,
          original_filename: file.name,
          file_base64: fileBase64,
        }),
      });
      const data = await parseJsonSafe(res);
      if (!res.ok) {
        setStatusMessage({
          type: "error",
          text:
            data.error ||
            data.error_message ||
            data.detail ||
            "PDF upload failed.",
        });
      } else {
        setStatusMessage({
          type: "success",
          text: `Indexed '${data.document_name}' (${data.revision}) for ${data.machine_code}: ${data.total_pages} pages, ${data.chunk_count} chunks.`,
        });
        setFile(null);
        const fileInput = document.getElementById(
          "manual-pdf-file-input"
        ) as HTMLInputElement | null;
        if (fileInput) fileInput.value = "";
        onManualsChanged();
      }
    } catch (err: any) {
      setStatusMessage({
        type: "error",
        text: err?.message || "Network error during upload.",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleReprocess = async (manualId: number) => {
    setReprocessingId(manualId);
    setStatusMessage(null);
    try {
      const res = await fetch(`/api/manuals/${manualId}/reprocess`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await parseJsonSafe(res);
      if (!res.ok) {
        setStatusMessage({
          type: "error",
          text: data.error || data.error_message || "Re-indexing failed.",
        });
      } else {
        setStatusMessage({
          type: "success",
          text: `Re-indexed '${data.document_name}' (${data.chunk_count} chunks, ${data.total_pages} pages).`,
        });
        onManualsChanged();
      }
    } catch (err: any) {
      setStatusMessage({
        type: "error",
        text: err?.message || "Re-index error.",
      });
    } finally {
      setReprocessingId(null);
    }
  };

  const handleDelete = async (manual: ManualRecord) => {
    try {
      const res = await fetch(`/api/manuals/${manual.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setStatusMessage({
          type: "info",
          text: `Removed '${manual.document_name}'.`,
        });
        onManualsChanged();
      }
    } catch (err: any) {
      setStatusMessage({ type: "error", text: err?.message || "Delete failed." });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">
          {readOnly ? "Manual Status" : "Manuals"}
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          {readOnly
            ? "Review available machine documentation and indexing status"
            : "Upload and manage official machine PDF manuals"}
        </p>
      </div>

      {/* Three Official PDF Document Slots in 3D Colored Surfaces */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {OFFICIAL_EXPECTED_MANUALS.map((slot, idx) => {
          const uploadedMatch = manuals.find(
            (m) =>
              m.machine_code.toUpperCase() === slot.machineCode &&
              (m.document_name.toLowerCase() ===
                slot.documentName.toLowerCase() ||
                m.original_filename.toLowerCase() ===
                  slot.documentName.toLowerCase())
          );
          const isCompleted = uploadedMatch?.processing_status === "COMPLETED";
          const slotSurface = isCompleted
            ? "stat-3d-emerald"
            : idx === 2
            ? "stat-3d-indigo"
            : "stat-3d-blue";

          return (
            <div
              key={slot.documentName}
              className={`p-4 ${slotSurface} rounded-2xl flex flex-col justify-between gap-3`}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs font-bold text-slate-800">
                    {slot.machineCode} · {slot.revision}
                  </span>
                  <span className="text-xs flex items-center gap-1 font-semibold">
                    {isCompleted ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-800 tabular-nums">
                          Indexed ({uploadedMatch.total_pages}p)
                        </span>
                      </>
                    ) : (
                      <>
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        <span className="text-amber-700">Awaiting Upload</span>
                      </>
                    )}
                  </span>
                </div>
                <div className="text-sm font-bold text-slate-900 mt-1.5 break-all">
                  {slot.documentName}
                </div>
                <div className="text-xs text-slate-600 mt-1">{slot.purpose}</div>
              </div>

              {!readOnly && (
                <button
                  type="button"
                  onClick={() => selectOfficialSlot(slot)}
                  className="w-full py-1.5 px-3 text-xs font-semibold text-blue-700 btn-3d-secondary rounded-xl cursor-pointer whitespace-nowrap"
                >
                  Select Slot
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Upload PDF Form (Admin Only) */}
      {!readOnly && (
        <div className="card-3d rounded-2xl p-5">
          <h2 className="text-sm font-bold text-slate-900 mb-4">
            Upload PDF
          </h2>

          {statusMessage && (
            <div
              role="alert"
              className={`mb-4 p-3 rounded-xl text-xs flex items-start gap-2.5 ${
                statusMessage.type === "success"
                  ? "stat-3d-emerald text-emerald-900"
                  : statusMessage.type === "error"
                  ? "bg-red-50 border border-red-200 text-red-800"
                  : "stat-3d-blue text-blue-900"
              }`}
            >
              {statusMessage.type === "success" ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          <form onSubmit={handleUpload} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label
                  htmlFor="manual-machine-select"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Machine
                </label>
                <select
                  id="manual-machine-select"
                  value={selectedMachineCode}
                  onChange={(e) => setSelectedMachineCode(e.target.value)}
                  className="w-full px-3 py-2 text-sm input-3d rounded-xl text-slate-900"
                >
                  {machines.map((m) => (
                    <option key={m.id} value={m.machine_code}>
                      {m.machine_code} — {m.machine_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="manual-revision-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Revision
                </label>
                <input
                  id="manual-revision-input"
                  type="text"
                  value={revision}
                  onChange={(e) => setRevision(e.target.value)}
                  placeholder="Rev1.0"
                  required
                  className="w-full px-3 py-2 text-sm input-3d rounded-xl text-slate-900"
                />
              </div>

              <div>
                <label
                  htmlFor="manual-docname-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Document Name
                </label>
                <input
                  id="manual-docname-input"
                  type="text"
                  value={documentName}
                  onChange={(e) => setDocumentName(e.target.value)}
                  placeholder="e.g. HP200_Operations_Rev1_0.pdf"
                  className="w-full px-3 py-2 text-sm input-3d rounded-xl text-slate-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
              <div>
                <label
                  htmlFor="manual-pdf-file-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  PDF File
                </label>
                <input
                  id="manual-pdf-file-input"
                  type="file"
                  accept=".pdf,application/pdf"
                  onChange={(e) => {
                    const chosen = e.target.files?.[0] || null;
                    setFile(chosen);
                    if (chosen && !documentName.trim()) {
                      setDocumentName(chosen.name);
                    }
                  }}
                  className="w-full text-xs text-slate-700 file:mr-3 file:py-2 file:px-3.5 file:rounded-xl file:border file:border-slate-300 file:text-xs file:font-semibold file:bg-slate-50 file:text-slate-800 hover:file:bg-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-4">
                <button
                  type="submit"
                  disabled={uploading}
                  className="px-4 py-2.5 btn-3d-primary text-xs font-semibold rounded-xl flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Upload className="w-4 h-4" />
                  <span>{uploading ? "Processing..." : "Upload PDF"}</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Manuals Processing Status Table */}
      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Uploaded Manuals ({manuals.length})
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-medium text-slate-500">
                <th className="py-2.5 pr-4">Document</th>
                <th className="py-2.5 px-3">Machine</th>
                <th className="py-2.5 px-3">Revision</th>
                <th className="py-2.5 px-3 text-right">Pages</th>
                <th className="py-2.5 px-3 text-right">Chunks</th>
                <th className="py-2.5 px-3">Processing Status</th>
                <th className="py-2.5 pl-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {manuals.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No manuals have been uploaded yet.
                  </td>
                </tr>
              ) : (
                manuals.map((m) => (
                  <tr key={m.id} className="hover:bg-blue-50/40 transition-colors">
                    <td className="py-3 pr-4 font-semibold text-slate-900">
                      {m.document_name}
                    </td>
                    <td className="py-3 px-3 font-mono font-semibold text-slate-700">
                      {m.machine_code}
                    </td>
                    <td className="py-3 px-3 text-slate-700">{m.revision}</td>
                    <td className="py-3 px-3 text-right text-slate-800 tabular-nums">
                      {m.total_pages}
                    </td>
                    <td className="py-3 px-3 text-right text-slate-800 tabular-nums">
                      {m.chunk_count}
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        {m.processing_status === "COMPLETED" ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        ) : m.processing_status === "FAILED" ? (
                          <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        )}
                        <span
                          className={
                            m.processing_status === "COMPLETED"
                              ? "text-emerald-700 font-semibold"
                              : m.processing_status === "FAILED"
                              ? "text-red-700 font-semibold"
                              : "text-amber-700"
                          }
                        >
                          {m.processing_status === "COMPLETED"
                            ? "Indexed"
                            : m.processing_status}
                        </span>
                      </div>
                      {m.error_message && (
                        <div className="text-red-600 mt-1 max-w-xs">
                          {m.error_message}
                        </div>
                      )}
                    </td>
                    <td className="py-3 pl-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <a
                          href={`/api/manuals/${m.id}/file?machine_id=${m.machine_code}&token=${encodeURIComponent(token)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label={`View ${m.document_name}`}
                          className="px-2.5 py-1 btn-3d-secondary rounded-lg inline-flex items-center gap-1 whitespace-nowrap"
                        >
                          <FileText className="w-3 h-3" />
                          <span>View PDF</span>
                        </a>
                        {!readOnly && (
                          <>
                            <button
                              type="button"
                              disabled={reprocessingId === m.id}
                              onClick={() => handleReprocess(m.id)}
                              aria-label={`Re-index ${m.document_name}`}
                              className="px-2.5 py-1 btn-3d-secondary rounded-lg inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>
                                {reprocessingId === m.id
                                  ? "Re-indexing..."
                                  : "Re-index"}
                              </span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDelete(m)}
                              aria-label={`Delete ${m.document_name}`}
                              className="px-2.5 py-1 btn-3d-danger rounded-lg inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Delete</span>
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useState } from "react";
import {
  Upload,
  MessageSquare,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Cpu,
  Clock,
  FileText,
} from "lucide-react";
import type {
  MachineRecord,
  ManualRecord,
  QueryHistoryRecord,
  UserRecord,
} from "../types.ts";

interface AdminDashboardProps {
  token: string;
  machines: MachineRecord[];
  onNavigate: (view: string, machineCode?: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardProps> = ({
  token,
  machines,
  onNavigate,
}) => {
  const [stats, setStats] = useState<{
    total_users: number;
    total_machines: number;
    total_manuals: number;
    indexed_manuals: number;
    failed_processing_jobs: number;
    pending_processing_jobs: number;
    total_chunks: number;
    total_queries: number;
    recent_uploads: ManualRecord[];
    recent_activities: QueryHistoryRecord[];
  } | null>(null);

  useEffect(() => {
    fetch("/api/dashboard/admin/", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setStats(d))
      .catch(() => {});
  }, [token]);

  if (!stats) {
    return (
      <div className="p-6 card-3d rounded-2xl text-xs text-slate-500">
        Loading overview...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">
            System Overview
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Equipment readiness and manual processing status
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate("manuals")}
          className="px-4 py-2 btn-3d-primary text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer whitespace-nowrap self-start sm:self-auto"
        >
          <Upload className="w-4 h-4" />
          <span>Manage Manuals</span>
        </button>
      </div>

      {/* Compact 3D Colored Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="stat-3d-blue rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-blue-900/80">Registered Machines</div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums mt-1">
              {stats.total_machines}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-blue flex items-center justify-center shrink-0">
            <Cpu className="w-5 h-5" />
          </div>
        </div>
        <div className="stat-3d-indigo rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-indigo-900/80">Uploaded Manuals</div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums mt-1">
              {stats.total_manuals}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-indigo flex items-center justify-center shrink-0">
            <FileText className="w-5 h-5" />
          </div>
        </div>
        <div className="stat-3d-emerald rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-emerald-900/80">Indexed Manuals</div>
            <div className="text-2xl font-bold text-emerald-800 tabular-nums mt-1">
              {stats.indexed_manuals}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-emerald flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
        <div className="stat-3d-amber rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-amber-900/80">Total Queries</div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums mt-1">
              {stats.total_queries}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-amber flex items-center justify-center shrink-0">
            <MessageSquare className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Machine Readiness */}
      <div className="card-3d rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-900">
            Machine Readiness
          </h2>
          <button
            type="button"
            onClick={() => onNavigate("machines")}
            className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
          >
            View Machines
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {machines.map((m) => {
            const indexedCount = m.completed_manual_count ?? 0;
            const isReady = indexedCount > 0;
            return (
              <div
                key={m.id}
                className={`p-4 rounded-xl flex items-center justify-between gap-4 ${
                  isReady ? "stat-3d-emerald" : "well-3d"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      m.machine_code === "HP200"
                        ? "icon-3d-blue"
                        : "icon-3d-indigo"
                    }`}
                  >
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-800">
                        {m.machine_code}
                      </span>
                      <span className="text-sm font-semibold text-slate-900">
                        {m.machine_name}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5 tabular-nums">
                      {indexedCount} indexed manual{indexedCount === 1 ? "" : "s"}
                    </div>
                  </div>
                </div>
                <span
                  className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                    isReady ? "text-emerald-800" : "text-amber-700"
                  }`}
                >
                  {isReady ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Clock className="w-4 h-4 text-amber-600" />
                  )}
                  <span>{isReady ? "Ready" : "Awaiting Manuals"}</span>
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Document Activity & Manual Processing Status */}
      <div className="card-3d rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-slate-900">
            Recent Document Activity &amp; Processing Status
          </h2>
          <button
            type="button"
            onClick={() => onNavigate("manuals")}
            className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
          >
            Open Manuals
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2.5 pr-3 font-medium">Document</th>
                <th className="py-2.5 px-3 font-medium">Machine</th>
                <th className="py-2.5 px-3 font-medium">Revision</th>
                <th className="py-2.5 px-3 font-medium text-right">Pages</th>
                <th className="py-2.5 pl-3 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stats.recent_uploads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    No manuals uploaded yet. Go to Manuals to upload the official
                    PDF documents.
                  </td>
                </tr>
              ) : (
                stats.recent_uploads.map((m) => (
                  <tr key={m.id} className="hover:bg-blue-50/40 transition-colors">
                    <td className="py-3 pr-3 font-semibold text-slate-900">
                      {m.document_name}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-700">
                      {m.machine_code}
                    </td>
                    <td className="py-3 px-3 text-slate-600">{m.revision}</td>
                    <td className="py-3 px-3 text-right text-slate-700 tabular-nums">
                      {m.total_pages}
                    </td>
                    <td className="py-3 pl-3 text-right">
                      <span
                        className={`font-semibold ${
                          m.processing_status === "COMPLETED"
                            ? "text-emerald-700"
                            : m.processing_status === "FAILED"
                            ? "text-red-700"
                            : "text-amber-700"
                        }`}
                      >
                        {m.processing_status === "COMPLETED"
                          ? "Indexed"
                          : m.processing_status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

interface EngineerDashboardProps {
  user: UserRecord;
  token: string;
  machines: MachineRecord[];
  manuals: ManualRecord[];
  onOpenAssistantForMachine: (machineCode: string) => void;
}

export const EngineerDashboardView: React.FC<EngineerDashboardProps> = ({
  user,
  token,
  machines,
  manuals,
  onOpenAssistantForMachine,
}) => {
  const [recentQueries, setRecentQueries] = useState<QueryHistoryRecord[]>([]);

  useEffect(() => {
    fetch("/api/dashboard/engineer/", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d && Array.isArray(d.recent_questions)) {
          setRecentQueries(d.recent_questions);
        }
      })
      .catch(() => {});
  }, [token]);

  return (
    <div className="space-y-6">
      {/* Welcome Message */}
      <div>
        <h1 className="text-xl font-bold text-slate-900">
          Welcome, {user.username}
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Select a machine below to ask technical questions grounded in its
          official manuals.
        </p>
      </div>

      {/* Two 3D Interactive Machine Cards with Manual Availability */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {machines.map((m) => {
          const machineManuals = manuals.filter(
            (doc) =>
              doc.machine_code.toUpperCase() === m.machine_code.toUpperCase() &&
              doc.processing_status === "COMPLETED"
          );
          const isReady = machineManuals.length > 0;
          const isHP200 = m.machine_code.toUpperCase() === "HP200";

          return (
            <div
              key={m.id}
              className="card-3d-interactive rounded-2xl p-5 flex flex-col justify-between gap-5"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isHP200 ? "icon-3d-blue" : "icon-3d-indigo"
                      }`}
                    >
                      <Cpu className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-base font-bold text-slate-900">
                        {m.machine_name}
                      </h2>
                      <div className="text-xs font-mono font-semibold text-blue-700">
                        {m.machine_code}
                      </div>
                    </div>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-semibold ${
                      isReady ? "text-emerald-700" : "text-amber-700"
                    }`}
                  >
                    {isReady ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                    )}
                    <span>
                      {isReady
                        ? `${machineManuals.length} Manual${
                            machineManuals.length === 1 ? "" : "s"
                          } Available`
                        : "Awaiting Manuals"}
                    </span>
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {m.description}
                </p>

                <div className="p-3 well-3d rounded-xl text-xs text-slate-600">
                  {machineManuals.length > 0 ? (
                    <div className="space-y-1">
                      <div className="font-semibold text-slate-700">
                        Indexed Manuals:
                      </div>
                      {machineManuals.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center gap-1.5 text-slate-700"
                        >
                          <FileText className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          <span>
                            {doc.document_name} ({doc.revision})
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <span>No manuals indexed for {m.machine_code} yet.</span>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => onOpenAssistantForMachine(m.machine_code)}
                className="w-full py-2.5 px-4 btn-3d-primary text-xs font-semibold rounded-xl flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open {m.machine_code} Assistant</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Recent Questions */}
      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Recent Questions
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2.5 pr-3 font-medium">Machine</th>
                <th className="py-2.5 px-3 font-medium">Question</th>
                <th className="py-2.5 px-3 font-medium">Citations</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 pl-3 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentQueries.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    No recent questions yet. Choose a machine above to ask your
                    first question.
                  </td>
                </tr>
              ) : (
                recentQueries.map((q) => (
                  <tr key={q.id} className="hover:bg-blue-50/40 transition-colors">
                    <td className="py-3 pr-3 font-mono font-semibold text-slate-900">
                      {q.machine_code}
                    </td>
                    <td className="py-3 px-3 text-slate-800">{q.question}</td>
                    <td className="py-3 px-3 text-slate-600 tabular-nums">
                      {q.citations?.length || 0} source(s)
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`font-semibold ${
                          q.confidence_status === "SUPPORTED"
                            ? "text-emerald-700"
                            : "text-amber-700"
                        }`}
                      >
                        {q.confidence_status === "SUPPORTED"
                          ? "Grounded"
                          : "Insufficient Evidence"}
                      </span>
                    </td>
                    <td className="py-3 pl-3 text-right">
                      <button
                        type="button"
                        onClick={() => onOpenAssistantForMachine(q.machine_code)}
                        className="text-blue-600 hover:underline font-semibold cursor-pointer"
                      >
                        Open Assistant
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

interface SupervisorDashboardProps {
  token: string;
}

export const SupervisorDashboardView: React.FC<SupervisorDashboardProps> = ({
  token,
}) => {
  const [data, setData] = useState<{
    total_queries: number;
    supported_queries: number;
    unsupported_queries_count: number;
    machine_distribution: Array<{
      id: number;
      machine_code: string;
      machine_name: string;
      query_count: number;
      supported_count: number;
      unsupported_count: number;
    }>;
    recent_queries: QueryHistoryRecord[];
  } | null>(null);

  useEffect(() => {
    fetch("/api/dashboard/supervisor/", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setData(d))
      .catch(() => {});
  }, [token]);

  if (!data) {
    return (
      <div className="p-6 card-3d rounded-2xl text-xs text-slate-500">
        Loading supervisor overview...
      </div>
    );
  }

  const groundedPct =
    data.total_queries > 0
      ? Math.round((data.supported_queries / data.total_queries) * 100)
      : 0;
  const refusedPct =
    data.total_queries > 0 ? 100 - groundedPct : 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900">
          Supervisor Overview
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Query volume, grounded response rate, and machine activity
        </p>
      </div>

      {/* Total Queries, Grounded vs Refused in 3D Colored Surfaces */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="stat-3d-blue rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-blue-900/80">Total Queries</div>
            <div className="text-2xl font-bold text-slate-900 tabular-nums mt-1">
              {data.total_queries}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-blue flex items-center justify-center shrink-0">
            <MessageSquare className="w-5 h-5" />
          </div>
        </div>
        <div className="stat-3d-emerald rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-emerald-900/80">Grounded Answers</div>
            <div className="text-2xl font-bold text-emerald-800 tabular-nums mt-1">
              {data.supported_queries}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-emerald flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
        <div className="stat-3d-amber rounded-2xl p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-medium text-amber-900/80">Refused Answers</div>
            <div className="text-2xl font-bold text-amber-800 tabular-nums mt-1">
              {data.unsupported_queries_count}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl icon-3d-amber flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Confidence Distribution */}
        <div className="card-3d rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 mb-1">
              Confidence Distribution
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Proportion of engineer queries supported by indexed manual evidence
            </p>

            <div className="w-full h-3.5 well-3d rounded-full overflow-hidden flex">
              <div
                className="bg-emerald-600 h-full transition-all"
                style={{ width: `${groundedPct}%` }}
              />
              <div
                className="bg-amber-500 h-full transition-all"
                style={{ width: `${refusedPct}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 mt-4 border-t border-slate-100 text-xs">
            <div>
              <div className="text-slate-500">Supported (Grounded)</div>
              <div className="text-sm font-bold text-emerald-700 tabular-nums mt-0.5">
                {data.supported_queries} ({groundedPct}%)
              </div>
            </div>
            <div>
              <div className="text-slate-500">Insufficient Evidence</div>
              <div className="text-sm font-bold text-amber-700 tabular-nums mt-0.5">
                {data.unsupported_queries_count} ({refusedPct}%)
              </div>
            </div>
          </div>
        </div>

        {/* Machine-Wise Activity */}
        <div className="card-3d rounded-2xl p-5">
          <h2 className="text-sm font-bold text-slate-900 mb-3">
            Machine-Wise Activity
          </h2>
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2 pr-3 font-medium">Machine</th>
                <th className="py-2 px-2 font-medium text-right">Grounded</th>
                <th className="py-2 px-2 font-medium text-right">Refused</th>
                <th className="py-2 pl-2 font-medium text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.machine_distribution.map((m) => (
                <tr key={m.id}>
                  <td className="py-2.5 pr-3">
                    <span className="font-mono font-bold text-slate-900">
                      {m.machine_code}
                    </span>{" "}
                    <span className="text-slate-600">— {m.machine_name}</span>
                  </td>
                  <td className="py-2.5 px-2 text-right text-emerald-700 font-semibold tabular-nums">
                    {m.supported_count}
                  </td>
                  <td className="py-2.5 px-2 text-right text-amber-700 font-semibold tabular-nums">
                    {m.unsupported_count}
                  </td>
                  <td className="py-2.5 pl-2 text-right font-bold text-slate-900 tabular-nums">
                    {m.query_count}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Engineer Queries */}
      <div className="card-3d rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Recent Engineer Queries
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-2.5 pr-3 font-medium">User</th>
                <th className="py-2.5 px-3 font-medium">Machine</th>
                <th className="py-2.5 px-3 font-medium">Question</th>
                <th className="py-2.5 px-3 font-medium">Status</th>
                <th className="py-2.5 pl-3 font-medium text-right">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.recent_queries.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    No queries logged yet.
                  </td>
                </tr>
              ) : (
                data.recent_queries.map((q) => (
                  <tr key={q.id} className="hover:bg-blue-50/40 transition-colors">
                    <td className="py-3 pr-3 font-semibold text-slate-900">
                      {q.username}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-700">
                      {q.machine_code}
                    </td>
                    <td className="py-3 px-3 text-slate-800">{q.question}</td>
                    <td className="py-3 px-3">
                      <span
                        className={`font-semibold ${
                          q.confidence_status === "SUPPORTED"
                            ? "text-emerald-700"
                            : "text-amber-700"
                        }`}
                      >
                        {q.confidence_status === "SUPPORTED"
                          ? "Grounded"
                          : "Refused"}
                      </span>
                    </td>
                    <td className="py-3 pl-3 text-right text-slate-500 tabular-nums">
                      {new Date(q.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

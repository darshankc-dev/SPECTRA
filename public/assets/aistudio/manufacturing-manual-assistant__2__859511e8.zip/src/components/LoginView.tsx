import React, { useState } from "react";
import {
  Lock,
  User,
  Mail,
  AlertCircle,
  CheckCircle2,
  Wrench,
  Eye,
  EyeOff,
} from "lucide-react";
import type { UserRecord, UserRole } from "../types.ts";

interface LoginViewProps {
  onLoginSuccess: (user: UserRecord, token: string) => void;
}

const ROLES: Array<{ value: UserRole; label: string }> = [
  { value: "ENGINEER", label: "Engineer" },
  { value: "SUPERVISOR", label: "Supervisor" },
  { value: "ADMIN", label: "Admin" },
];

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [role, setRole] = useState<UserRole>("ENGINEER");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const switchMode = (newMode: "login" | "register") => {
    setMode(newMode);
    setError(null);
    setSuccessMessage(null);
    setShowPassword(false);
    setShowConfirmPassword(false);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!username.trim() || !password) {
      setError("Please enter your username and password.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/login/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          password,
          role,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || data.detail || "Invalid credentials.");
      } else {
        onLoginSuccess(data.user, data.token);
      }
    } catch (err: any) {
      setError(err?.message || "Unable to reach the authentication service.");
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!username.trim() || !email.trim() || !password) {
      setError("Please fill in username, email, and password.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/register/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          email: email.trim(),
          password,
          role,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || data.detail || "Registration failed.");
      } else {
        setMode("login");
        setPassword("");
        setConfirmPassword("");
        setShowPassword(false);
        setShowConfirmPassword(false);
        setSuccessMessage(
          `Registered '${data.user.username}' as ${data.user.role}. Please sign in with your password.`
        );
      }
    } catch (err: any) {
      setError(err?.message || "Unable to reach the registration service.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen canvas-3d-auth flex flex-col justify-center items-center px-4 py-12">
      <div className="w-full max-w-md card-3d rounded-2xl p-8">
        {/* Brand Header */}
        <div className="flex items-center gap-3.5 pb-5 mb-5 border-b border-slate-200/80">
          <div className="w-11 h-11 rounded-xl icon-3d-blue flex items-center justify-center shrink-0">
            <Wrench className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-900 tracking-tight">
              Manufacturing Manual Assistant
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Enterprise Equipment Documentation &amp; Technical Intelligence
            </p>
          </div>
        </div>

        {/* Sign In / Register Mode Switch */}
        <div className="grid grid-cols-2 gap-1.5 p-1.5 well-3d rounded-xl mb-5">
          <button
            type="button"
            onClick={() => switchMode("login")}
            className={`py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              mode === "login"
                ? "btn-3d-primary"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => switchMode("register")}
            className={`py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              mode === "register"
                ? "btn-3d-primary"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Register Account
          </button>
        </div>

        {/* Role Selector (Admin / Supervisor / Engineer) */}
        <div className="mb-5">
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            {mode === "login" ? "Sign In Role" : "Register Role"}
          </label>
          <div className="grid grid-cols-3 gap-2">
            {ROLES.map((r) => {
              const isSelected = role === r.value;
              return (
                <button
                  key={r.value}
                  type="button"
                  onClick={() => {
                    setRole(r.value);
                    setError(null);
                  }}
                  className={`py-2 px-3 text-xs font-semibold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? "stat-3d-blue text-blue-800"
                      : "btn-3d-secondary text-slate-600"
                  }`}
                >
                  {r.label}
                </button>
              );
            })}
          </div>
        </div>

        {error && (
          <div
            role="alert"
            className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 flex items-start gap-2.5 text-xs text-red-700 shadow-xs"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div
            role="status"
            className="mb-5 p-3 rounded-xl stat-3d-emerald flex items-start gap-2.5 text-xs text-emerald-900"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}

        {mode === "login" ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label
                htmlFor="login-username"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Username or Email
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  id="login-username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username or email"
                  className="w-full pl-9 pr-3 py-2 text-sm input-3d rounded-xl text-slate-900"
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="login-password"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  id="login-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-9 pr-10 py-2 text-sm input-3d rounded-xl text-slate-900"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-2.5 top-2 p-0.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 btn-3d-primary text-sm font-semibold rounded-xl cursor-pointer whitespace-nowrap mt-2"
            >
              {loading
                ? "Signing in..."
                : `Sign In as ${
                    ROLES.find((r) => r.value === role)?.label || "User"
                  }`}
            </button>

            <div className="text-center pt-2">
              <span className="text-xs text-slate-500">
                Don&apos;t have an account yet?{" "}
              </span>
              <button
                type="button"
                onClick={() => switchMode("register")}
                className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Register here
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label
                htmlFor="register-username"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  id="register-username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Choose a username"
                  className="w-full pl-9 pr-3 py-2 text-sm input-3d rounded-xl text-slate-900"
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="register-email"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  id="register-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full pl-9 pr-3 py-2 text-sm input-3d rounded-xl text-slate-900"
                  autoComplete="email"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="register-password"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  id="register-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full pl-9 pr-10 py-2 text-sm input-3d rounded-xl text-slate-900"
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-2.5 top-2 p-0.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <label
                htmlFor="register-confirm-password"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  id="register-confirm-password"
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter your password"
                  className="w-full pl-9 pr-10 py-2 text-sm input-3d rounded-xl text-slate-900"
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  aria-label={
                    showConfirmPassword
                      ? "Hide confirm password"
                      : "Show confirm password"
                  }
                  className="absolute right-2.5 top-2 p-0.5 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 btn-3d-primary text-sm font-semibold rounded-xl cursor-pointer whitespace-nowrap mt-2"
            >
              {loading
                ? "Creating Account..."
                : `Register as ${
                    ROLES.find((r) => r.value === role)?.label || "User"
                  }`}
            </button>

            <div className="text-center pt-2">
              <span className="text-xs text-slate-500">
                Already have an account?{" "}
              </span>
              <button
                type="button"
                onClick={() => switchMode("login")}
                className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Sign in here
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

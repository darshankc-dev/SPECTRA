export type UserRole = "ADMIN" | "ENGINEER" | "SUPERVISOR";

export interface UserRecord {
  id: number;
  username: string;
  email: string;
  role: UserRole;
  is_active: boolean;
  date_joined: string;
  last_login: string | null;
}

export interface MachineRecord {
  id: number;
  machine_code: string;
  machine_name: string;
  description: string;
  manufacturer: string;
  manual_count?: number;
  completed_manual_count?: number;
  created_at: string;
  updated_at: string;
}

export type ProcessingStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";

export interface ManualRecord {
  id: number;
  machine: number;
  machine_code: string;
  machine_name: string;
  document_name: string;
  original_filename: string;
  revision: string;
  file_path: string;
  total_pages: number;
  file_size: number;
  processing_status: ProcessingStatus;
  error_message: string;
  chunk_count: number;
  uploaded_by: number | null;
  uploaded_by_username: string;
  uploaded_at: string;
  updated_at: string;
}

export interface ManualChunkRecord {
  id: number;
  manual_id: number;
  machine_id: number;
  machine_code: string;
  document_name: string;
  revision: string;
  chunk_text: string;
  page_number: number;
  chunk_index: number;
  embedding_reference: string;
  embedding: number[];
  metadata: {
    machine_id: string;
    manual_id: string;
    document_name: string;
    revision: string;
    page_number: number;
    chunk_index: number;
  };
  created_at: string;
}

export interface CitationItem {
  manual_id: number;
  machine_id: string;
  document_name: string;
  revision: string;
  page_number: number;
  chunk_index: number;
  supporting_text: string;
  similarity: number;
  pdf_url: string;
}

export type ConfidenceStatus = "SUPPORTED" | "INSUFFICIENT_EVIDENCE" | "AMBIGUOUS" | "ERROR";

export interface QueryHistoryRecord {
  id: number;
  user: number;
  username: string;
  user_role: UserRole;
  machine: number;
  machine_code: string;
  machine_name: string;
  question: string;
  generated_answer: string;
  citations: CitationItem[];
  confidence_status: ConfidenceStatus;
  created_at: string;
}

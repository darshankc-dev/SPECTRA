"""
Automated tests for Manual Upload & Processing:
- TEST 6: Engineer Upload Restriction
- TEST 7: Admin Upload & Full Pipeline
- TEST 12: Duplicate Ingestion Idempotency
- TEST 15: Citation PDF Access Authorization & Machine Isolation
"""
from unittest.mock import patch
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient

from accounts.models import User
from machines.models import Machine
from .ingestion import ManualIngestionService
from .models import Manual, ManualChunk
from .pdf_processor import ExtractedPDFDocument, ExtractedPage


def build_valid_pdf_bytes() -> bytes:
    """Builds a minimal valid PDF byte sequence for upload validation tests."""
    return (
        b"%PDF-1.4\n"
        b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
        b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n"
        b"3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] >> endobj\n"
        b"xref\n0 4\n0000000000 65535 f \n"
        b"trailer << /Root 1 0 R /Size 4 >>\nstartxref\n0\n%%EOF"
    )


class ManualIngestionAndPermissionTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin, _ = User.objects.update_or_create(
            username="manual_admin",
            defaults={"email": "manual_admin@factory.local", "role": User.Role.ADMIN},
        )
        self.engineer, _ = User.objects.update_or_create(
            username="manual_engineer",
            defaults={"email": "manual_eng@factory.local", "role": User.Role.ENGINEER},
        )
        self.hp200 = Machine.objects.get(machine_code="HP200")
        self.ac90 = Machine.objects.get(machine_code="AC90")

    def test_06_engineer_upload_restriction(self):
        """TEST 6 — Engineer attempting to upload a PDF receives HTTP 403 and no manual/chunks are stored."""
        self.client.force_authenticate(user=self.engineer)
        pdf_file = SimpleUploadedFile(
            "HP200_Operations_Rev1_0.pdf",
            build_valid_pdf_bytes(),
            content_type="application/pdf",
        )
        response = self.client.post(
            "/api/manuals/upload/",
            {"machine_id": "HP200", "revision": "Rev1.0", "file": pdf_file},
            format="multipart",
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(Manual.objects.count(), 0)
        self.assertEqual(ManualChunk.objects.count(), 0)

    @patch("manuals.ingestion.PDFProcessor.extract_from_path")
    @patch("manuals.ingestion.GeminiEmbeddingService.embed_texts")
    @patch("manuals.ingestion.ChromaVectorStore.upsert_chunks")
    @patch("manuals.ingestion.ChromaVectorStore.delete_manual_vectors")
    def test_07_and_12_admin_upload_and_duplicate_reprocessing_idempotency(
        self,
        mock_delete_vectors,
        mock_upsert_chunks,
        mock_embed_texts,
        mock_extract,
    ):
        """TEST 7 & TEST 12 — Admin upload processes PDF into chunks/embeddings, and reprocessing creates no duplicates."""
        mock_extract.return_value = ExtractedPDFDocument(
            total_pages=2,
            pages=[
                ExtractedPage(
                    page_number=1,
                    text="SECTION 1 HYDRAULIC PRESSURE SETTINGS\n\nNominal operating pressure for HP-200 is 210 bar.",
                    char_count=92,
                ),
                ExtractedPage(
                    page_number=2,
                    text="SECTION 2 SAFETY INTERLOCKS\n\nAlways engage dual-palm safety buttons during press stroke.",
                    char_count=89,
                ),
            ],
            pdf_metadata={"title": "HP200_Operations_Rev1_0.pdf"},
        )
        mock_embed_texts.side_effect = lambda texts: [[0.1, 0.2, 0.3, 0.4] for _ in texts]

        self.client.force_authenticate(user=self.admin)
        pdf_file = SimpleUploadedFile(
            "HP200_Operations_Rev1_0.pdf",
            build_valid_pdf_bytes(),
            content_type="application/pdf",
        )
        response = self.client.post(
            "/api/manuals/upload/",
            {"machine_id": "HP200", "revision": "Rev1.0", "file": pdf_file},
            format="multipart",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        manual = Manual.objects.get(document_name="HP200_Operations_Rev1_0.pdf")
        self.assertEqual(manual.processing_status, Manual.ProcessingStatus.COMPLETED)
        self.assertEqual(manual.total_pages, 2)
        initial_chunk_count = ManualChunk.objects.filter(manual=manual).count()
        self.assertEqual(initial_chunk_count, 2)

        # TEST 12 — Reprocess the same manual and verify zero duplicate chunks
        reprocess_res = self.client.post(f"/api/manuals/{manual.id}/reprocess/")
        self.assertEqual(reprocess_res.status_code, status.HTTP_200_OK)
        self.assertEqual(ManualChunk.objects.filter(manual=manual).count(), initial_chunk_count)

    def test_15_citation_access_authorization_and_cross_machine_denial(self):
        """TEST 15 — Unauthenticated access or cross-machine citation access is denied."""
        manual = Manual.objects.create(
            machine=self.hp200,
            document_name="HP200_Operations_Rev1_0.pdf",
            original_filename="HP200_Operations_Rev1_0.pdf",
            revision="Rev1.0",
            file_path=SimpleUploadedFile("HP200_Operations_Rev1_0.pdf", build_valid_pdf_bytes()),
            total_pages=12,
            file_size=240,
            processing_status=Manual.ProcessingStatus.COMPLETED,
            uploaded_by=self.admin,
        )
        # Unauthenticated request denied
        unauth_res = self.client.get(f"/api/manuals/{manual.id}/file/")
        self.assertIn(unauth_res.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN))

        # Authenticated request attempting to open HP200 manual under AC90 context denied
        self.client.force_authenticate(user=self.engineer)
        cross_machine_res = self.client.get(f"/api/manuals/{manual.id}/file/?machine_id=AC90")
        self.assertEqual(cross_machine_res.status_code, status.HTTP_403_FORBIDDEN)

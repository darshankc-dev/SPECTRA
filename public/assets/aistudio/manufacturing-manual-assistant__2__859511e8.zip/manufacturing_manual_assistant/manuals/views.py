"""
REST API Views for Manual Management (/api/manuals/*).
Strictly enforces Admin-only upload, replacement, reprocessing, and deletion.
Allows authenticated users to view manual metadata and open cited PDF pages.
"""
import logging
from django.http import FileResponse
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.permissions import IsAdminRole
from .ingestion import ManualIngestionService
from .models import Manual
from .permissions import ManualAccessPermission
from .serializers import ManualSerializer, ManualUploadSerializer

logger = logging.getLogger(__name__)


class ManualListAPIView(APIView):
    """GET /api/manuals/ — List uploaded manuals (optionally filtered by machine_id)."""

    permission_classes = [ManualAccessPermission]

    def get(self, request):
        queryset = Manual.objects.select_related("machine", "uploaded_by").prefetch_related("chunks").all()
        machine_param = request.query_params.get("machine_id")
        if machine_param:
            if str(machine_param).isdigit():
                queryset = queryset.filter(machine_id=int(machine_param))
            else:
                queryset = queryset.filter(machine__machine_code__iexact=str(machine_param).strip())
        serializer = ManualSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ManualUploadAPIView(APIView):
    """POST /api/manuals/upload/ — Upload and index an official PDF manual (Admin only)."""

    permission_classes = [IsAdminRole]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        serializer = ManualUploadSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        machine = serializer.validated_data["machine_obj"]
        uploaded_file = serializer.validated_data["file"]
        doc_name = serializer.validated_data["resolved_document_name"]
        revision = serializer.validated_data["revision"].strip()
        existing_manual = serializer.validated_data.get("existing_manual")

        ingestion_service = ManualIngestionService()

        if existing_manual is not None:
            # Replace existing manual cleanly without leaving orphaned vectors
            ingestion_service.vector_store.delete_manual_vectors(existing_manual.id)
            if existing_manual.file_path:
                existing_manual.file_path.delete(save=False)
            existing_manual.file_path = uploaded_file
            existing_manual.original_filename = uploaded_file.name
            existing_manual.file_size = uploaded_file.size
            existing_manual.uploaded_by = request.user
            existing_manual.processing_status = Manual.ProcessingStatus.PENDING
            existing_manual.save()
            manual = existing_manual
        else:
            manual = Manual.objects.create(
                machine=machine,
                document_name=doc_name,
                original_filename=uploaded_file.name,
                revision=revision,
                file_path=uploaded_file,
                file_size=uploaded_file.size,
                processing_status=Manual.ProcessingStatus.PENDING,
                uploaded_by=request.user,
            )

        processed_manual = ingestion_service.process_manual(manual)
        http_status = (
            status.HTTP_201_CREATED
            if processed_manual.processing_status == Manual.ProcessingStatus.COMPLETED
            else status.HTTP_422_UNPROCESSABLE_ENTITY
        )
        return Response(ManualSerializer(processed_manual).data, status=http_status)


class ManualDetailAPIView(APIView):
    """
    GET /api/manuals/{id}/ — View manual metadata & chunk summary
    DELETE /api/manuals/{id}/ — Delete manual, chunks, and ChromaDB vectors (Admin only)
    """

    permission_classes = [ManualAccessPermission]

    def get(self, request, pk: int):
        manual = get_object_or_404(Manual.objects.select_related("machine", "uploaded_by"), pk=pk)
        return Response(ManualSerializer(manual).data, status=status.HTTP_200_OK)

    def delete(self, request, pk: int):
        if not request.user.is_admin_role:
            return Response(
                {"detail": "Access denied: Only Administrators can delete manuals."},
                status=status.HTTP_403_FORBIDDEN,
            )
        manual = get_object_or_404(Manual, pk=pk)
        doc_name = manual.document_name
        ingestion_service = ManualIngestionService()
        ingestion_service.delete_manual_completely(manual)
        logger.info("Admin '%s' deleted manual '%s' (id=%d).", request.user.username, doc_name, pk)
        return Response(status=status.HTTP_204_NO_CONTENT)


class ManualReprocessAPIView(APIView):
    """POST /api/manuals/{id}/reprocess/ — Re-extract and re-index manual idempotently (Admin only)."""

    permission_classes = [IsAdminRole]

    def post(self, request, pk: int):
        manual = get_object_or_404(Manual, pk=pk)
        ingestion_service = ManualIngestionService()
        processed = ingestion_service.process_manual(manual)
        http_status = (
            status.HTTP_200_OK
            if processed.processing_status == Manual.ProcessingStatus.COMPLETED
            else status.HTTP_422_UNPROCESSABLE_ENTITY
        )
        return Response(ManualSerializer(processed).data, status=http_status)


class ManualServePDFAPIView(APIView):
    """
    GET /api/manuals/{id}/file/?machine_id=HP200
    Securely serves the official PDF for clickable citation navigation.
    Verifies authentication and optional machine_id isolation check.
    """

    permission_classes = [IsAuthenticated]

    def get(self, request, pk: int):
        manual = get_object_or_404(Manual.objects.select_related("machine"), pk=pk)
        expected_machine = request.query_params.get("machine_id")
        if expected_machine:
            if str(expected_machine).isdigit():
                mismatch = manual.machine_id != int(expected_machine)
            else:
                mismatch = manual.machine.machine_code.upper() != str(expected_machine).strip().upper()
            if mismatch:
                return Response(
                    {"error": "Machine isolation violation: Requested manual does not belong to the selected machine."},
                    status=status.HTTP_403_FORBIDDEN,
                )

        if not manual.file_path:
            return Response({"error": "PDF file is unavailable."}, status=status.HTTP_404_NOT_FOUND)

        response = FileResponse(manual.file_path.open("rb"), content_type="application/pdf")
        response["Content-Disposition"] = f'inline; filename="{manual.document_name}"'
        return response

"""
ChromaDB Persistent Vector Store service.
Responsibilities:
- Store vector embeddings and chunk metadata persistently on disk.
- Enforce strict machine-level metadata filtering during semantic similarity search.
- Provide idempotent deletion by manual_id or machine_id to prevent orphaned vectors.
"""
import logging
import os
from typing import Any, Dict, List

from .chunking import DocumentChunkPayload

logger = logging.getLogger(__name__)


class VectorStoreError(Exception):
    """Raised when ChromaDB operations fail."""


class ChromaVectorStore:
    COLLECTION_NAME = "manufacturing_manual_chunks"

    def __init__(self, persist_directory: str | None = None):
        self.persist_directory = persist_directory or os.environ.get(
            "CHROMA_PERSIST_DIRECTORY", "./vector_store"
        )
        os.makedirs(self.persist_directory, exist_ok=True)
        self._client = None
        self._collection = None

    def _get_collection(self):
        if self._collection is not None:
            return self._collection
        try:
            import chromadb
        except ImportError as exc:
            raise VectorStoreError("chromadb package is required for persistent vector storage.") from exc

        try:
            self._client = chromadb.PersistentClient(path=self.persist_directory)
            self._collection = self._client.get_or_create_collection(
                name=self.COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"},
            )
            return self._collection
        except Exception as exc:
            logger.error("Failed to initialize ChromaDB at '%s': %s", self.persist_directory, exc)
            raise VectorStoreError(f"ChromaDB initialization failed: {exc}") from exc

    def delete_manual_vectors(self, manual_id: int) -> None:
        """Removes all existing vector records for a manual before reprocessing or deletion."""
        collection = self._get_collection()
        try:
            collection.delete(where={"manual_id": str(manual_id)})
            logger.info("Deleted ChromaDB vectors for manual_id=%s.", manual_id)
        except Exception as exc:
            logger.warning("ChromaDB delete_manual_vectors notice for manual_id=%s: %s", manual_id, exc)

    def upsert_chunks(
        self,
        chunks: List[DocumentChunkPayload],
        embeddings: List[List[float]],
    ) -> None:
        if not chunks:
            return
        if len(chunks) != len(embeddings):
            raise VectorStoreError("Chunk count and embedding count must match for ChromaDB upsert.")

        collection = self._get_collection()
        try:
            collection.upsert(
                ids=[c.chunk_id for c in chunks],
                embeddings=embeddings,
                documents=[c.chunk_text for c in chunks],
                metadatas=[c.to_chroma_metadata() for c in chunks],
            )
            logger.info("Upserted %d chunk vectors into ChromaDB.", len(chunks))
        except Exception as exc:
            logger.error("ChromaDB upsert failed: %s", exc)
            raise VectorStoreError(f"Failed to index vectors in ChromaDB: {exc}") from exc

    def query_by_machine(
        self,
        *,
        query_embedding: List[float],
        machine_code: str,
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Queries ChromaDB with STRICT metadata filtering: where={"machine_id": machine_code}.
        Returns list of matched chunk dicts with distance and similarity score.
        """
        if not machine_code:
            raise VectorStoreError("machine_code is mandatory for machine-isolated ChromaDB retrieval.")

        collection = self._get_collection()
        try:
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=max(1, top_k),
                where={"machine_id": str(machine_code).strip().upper()},
                include=["documents", "metadatas", "distances"],
            )
        except Exception as exc:
            logger.error("ChromaDB query failed for machine '%s': %s", machine_code, exc)
            raise VectorStoreError(f"Vector search failed: {exc}") from exc

        ids_list = (results.get("ids") or [[]])[0]
        docs_list = (results.get("documents") or [[]])[0]
        metas_list = (results.get("metadatas") or [[]])[0]
        dists_list = (results.get("distances") or [[]])[0]

        matches: List[Dict[str, Any]] = []
        for idx, chunk_id in enumerate(ids_list):
            distance = float(dists_list[idx]) if idx < len(dists_list) else 1.0
            similarity = max(0.0, 1.0 - distance)
            metadata = metas_list[idx] if idx < len(metas_list) and metas_list[idx] else {}
            document_text = docs_list[idx] if idx < len(docs_list) else ""
            matches.append(
                {
                    "chunk_id": chunk_id,
                    "chunk_text": document_text,
                    "metadata": metadata,
                    "distance": distance,
                    "similarity": similarity,
                }
            )
        return matches

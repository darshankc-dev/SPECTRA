from django.urls import path
from .views import (
    ManualDetailAPIView,
    ManualListAPIView,
    ManualReprocessAPIView,
    ManualServePDFAPIView,
    ManualUploadAPIView,
)

urlpatterns = [
    path("", ManualListAPIView.as_view(), name="api_manuals_list"),
    path("upload/", ManualUploadAPIView.as_view(), name="api_manuals_upload"),
    path("<int:pk>/", ManualDetailAPIView.as_view(), name="api_manuals_detail"),
    path("<int:pk>/reprocess/", ManualReprocessAPIView.as_view(), name="api_manuals_reprocess"),
    path("<int:pk>/file/", ManualServePDFAPIView.as_view(), name="api_manuals_serve_pdf"),
]

"""
Google Gemini Embedding Service using the official `google-genai` SDK.
Model is configurable via GEMINI_EMBEDDING_MODEL (default: gemini-embedding-2-preview).
Implements batching, exponential backoff retry logic, and rate-limit handling.
"""
import logging
import os
import time
from typing import List

logger = logging.getLogger(__name__)


class EmbeddingGenerationError(Exception):
    """Raised when Gemini embedding generation fails after retries."""


class GeminiEmbeddingService:
    def __init__(
        self,
        api_key: str | None = None,
        model_name: str | None = None,
        max_retries: int = 3,
        batch_size: int = 25,
    ):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.model_name = model_name or os.environ.get("GEMINI_EMBEDDING_MODEL", "gemini-embedding-2-preview")
        self.max_retries = max_retries
        self.batch_size = batch_size

    def _get_client(self):
        if not self.api_key:
            raise EmbeddingGenerationError("GEMINI_API_KEY environment variable is not configured.")
        try:
            from google import genai
        except ImportError as exc:
            raise EmbeddingGenerationError("google-genai package is required for Gemini embeddings.") from exc
        return genai.Client(api_key=self.api_key)

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        client = self._get_client()
        all_vectors: List[List[float]] = []

        for start_idx in range(0, len(texts), self.batch_size):
            batch = texts[start_idx : start_idx + self.batch_size]
            batch_vectors = self._embed_batch_with_retry(client, batch)
            all_vectors.extend(batch_vectors)

        if len(all_vectors) != len(texts):
            raise EmbeddingGenerationError(
                f"Embedding count mismatch: expected {len(texts)}, received {len(all_vectors)}."
            )
        return all_vectors

    def embed_query(self, query_text: str) -> List[float]:
        cleaned = (query_text or "").strip()
        if not cleaned:
            raise EmbeddingGenerationError("Cannot generate embedding for an empty query.")
        vectors = self.embed_texts([cleaned])
        return vectors[0]

    def _embed_batch_with_retry(self, client, batch: List[str]) -> List[List[float]]:
        last_exc: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                response = client.models.embed_content(
                    model=self.model_name,
                    contents=batch,
                )
                embeddings = getattr(response, "embeddings", None)
                if not embeddings:
                    raise EmbeddingGenerationError("Gemini embed_content returned empty embeddings list.")
                return [list(item.values) for item in embeddings]
            except Exception as exc:
                last_exc = exc
                wait_seconds = min(2**attempt, 8)
                logger.warning(
                    "Gemini embedding attempt %d/%d failed (%s). Retrying in %ds...",
                    attempt,
                    self.max_retries,
                    exc,
                    wait_seconds,
                )
                if attempt < self.max_retries:
                    time.sleep(wait_seconds)

        logger.error("Failed to generate Gemini embeddings after %d attempts: %s", self.max_retries, last_exc)
        raise EmbeddingGenerationError(f"Gemini Embedding API error: {last_exc}") from last_exc

"""Manuals app."""

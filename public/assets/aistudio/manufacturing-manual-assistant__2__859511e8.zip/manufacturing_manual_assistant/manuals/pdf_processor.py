"""
PyMuPDF (fitz) PDF text extraction service.
Preserves exact 1-indexed page numbers, detects scanned/unextractable PDFs,
and sanitizes control characters without inventing text.
"""
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger(__name__)


@dataclass
class ExtractedPage:
    page_number: int  # 1-indexed page number matching official PDF
    text: str
    char_count: int


@dataclass
class ExtractedPDFDocument:
    total_pages: int
    pages: List[ExtractedPage]
    pdf_metadata: Dict[str, str]


class PDFExtractionError(Exception):
    """Raised when a PDF is malformed, encrypted, or contains no extractable text (OCR required)."""


class PDFProcessor:
    @staticmethod
    def validate_pdf_header(file_bytes: bytes, max_size_bytes: int = 52428800) -> None:
        if not file_bytes:
            raise PDFExtractionError("Uploaded PDF file is empty.")
        if len(file_bytes) > max_size_bytes:
            raise PDFExtractionError(
                f"PDF file size ({len(file_bytes)} bytes) exceeds maximum limit ({max_size_bytes} bytes)."
            )
        if not file_bytes.startswith(b"%PDF-"):
            raise PDFExtractionError("Invalid file signature: File is not a valid PDF document.")

    @staticmethod
    def clean_extracted_text(raw_text: str) -> str:
        if not raw_text:
            return ""
        # Remove null bytes and normalize excessive horizontal whitespace while keeping paragraph breaks
        cleaned = raw_text.replace("\x00", "")
        cleaned = re.sub(r"[ \t]+", " ", cleaned)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned.strip()

    @classmethod
    def extract_from_path(cls, file_path: str | Path) -> ExtractedPDFDocument:
        path_obj = Path(file_path)
        if not path_obj.exists():
            raise PDFExtractionError(f"PDF file not found at path: {path_obj.name}")

        raw_bytes = path_obj.read_bytes()
        cls.validate_pdf_header(raw_bytes)

        try:
            import fitz  # PyMuPDF
        except ImportError as exc:
            raise PDFExtractionError("PyMuPDF (fitz) is required for PDF extraction.") from exc

        try:
            doc = fitz.open(stream=raw_bytes, filetype="pdf")
        except Exception as exc:
            logger.error("PyMuPDF failed to open PDF '%s': %s", path_obj.name, exc)
            raise PDFExtractionError(f"Malformed or corrupted PDF file: {exc}") from exc

        if doc.is_encrypted:
            doc.close()
            raise PDFExtractionError("Encrypted or password-protected PDF manuals are not supported.")

        total_pages = len(doc)
        if total_pages == 0:
            doc.close()
            raise PDFExtractionError("PDF document contains 0 pages.")

        pages: List[ExtractedPage] = []
        non_empty_pages = 0

        for idx in range(total_pages):
            page_num = idx + 1  # Strictly 1-indexed
            page = doc.load_page(idx)
            raw_page_text = page.get_text("text") or ""
            cleaned_text = cls.clean_extracted_text(raw_page_text)
            if cleaned_text:
                non_empty_pages += 1
            pages.append(
                ExtractedPage(
                    page_number=page_num,
                    text=cleaned_text,
                    char_count=len(cleaned_text),
                )
            )

        raw_meta = doc.metadata or {}
        pdf_metadata = {str(k): str(v) for k, v in raw_meta.items() if v}
        doc.close()

        if non_empty_pages == 0:
            raise PDFExtractionError(
                "No extractable text found in any page of this PDF. "
                "This document appears to be a scanned image PDF; OCR preprocessing is required before indexing."
            )

        logger.info(
            "Extracted %d/%d non-empty pages from '%s'.",
            non_empty_pages,
            total_pages,
            path_obj.name,
        )
        return ExtractedPDFDocument(
            total_pages=total_pages,
            pages=pages,
            pdf_metadata=pdf_metadata,
        )

"""
Semantic text chunking engine for industrial PDF manuals.
Preserves paragraph boundaries, section headings, original 1-indexed page numbers,
and complete machine + manual + revision metadata.
"""
import re
from dataclasses import dataclass
from typing import Any, Dict, List

from .pdf_processor import ExtractedPage


@dataclass
class DocumentChunkPayload:
    chunk_id: str
    manual_id: int
    machine_id: str  # machine_code e.g. 'HP200' or 'AC90'
    machine_db_id: int
    document_name: str
    revision: str
    page_number: int
    chunk_index: int
    chunk_text: str

    def to_chroma_metadata(self) -> Dict[str, Any]:
        return {
            "machine_id": str(self.machine_id),
            "machine_db_id": int(self.machine_db_id),
            "manual_id": str(self.manual_id),
            "document_name": str(self.document_name),
            "revision": str(self.revision),
            "page_number": int(self.page_number),
            "chunk_index": int(self.chunk_index),
        }


class ChunkingService:
    HEADING_PATTERN = re.compile(
        r"^(?:SECTION\s+\d+|CHAPTER\s+\d+|\d+(?:\.\d+)*\s+[A-Z0-9][A-Z0-9\s\-/()]{2,}|[A-Z][A-Z0-9\s\-/,:]{4,60})$"
    )

    def __init__(self, chunk_size: int = 900, chunk_overlap: int = 180):
        if chunk_size < 150:
            raise ValueError("chunk_size must be at least 150 characters.")
        if chunk_overlap < 0 or chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be >= 0 and strictly less than chunk_size.")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    @classmethod
    def _is_heading(cls, paragraph: str) -> bool:
        line = paragraph.strip()
        if not line or "\n" in line or len(line) > 85:
            return False
        return bool(cls.HEADING_PATTERN.match(line))

    def _split_long_paragraph(self, text: str) -> List[str]:
        """Splits an oversized single paragraph on sentence boundaries with overlap."""
        sentences = re.split(r"(?<=[.!?])\s+", text.strip())
        segments: List[str] = []
        current = ""
        for sentence in sentences:
            if not sentence:
                continue
            candidate = f"{current} {sentence}".strip() if current else sentence
            if len(candidate) <= self.chunk_size:
                current = candidate
            else:
                if current:
                    segments.append(current)
                    overlap_tail = current[-self.chunk_overlap :].strip() if self.chunk_overlap > 0 else ""
                    current = f"{overlap_tail} {sentence}".strip() if overlap_tail else sentence
                else:
                    # Single sentence exceeds chunk_size; slice cleanly
                    step = max(1, self.chunk_size - self.chunk_overlap)
                    for i in range(0, len(sentence), step):
                        segments.append(sentence[i : i + self.chunk_size])
                    current = ""
        if current:
            segments.append(current)
        return segments

    def chunk_pages(
        self,
        *,
        pages: List[ExtractedPage],
        manual_id: int,
        machine_code: str,
        machine_db_id: int,
        document_name: str,
        revision: str,
    ) -> List[DocumentChunkPayload]:
        chunks: List[DocumentChunkPayload] = []
        global_chunk_index = 0
        active_heading = ""

        for page in pages:
            page_text = (page.text or "").strip()
            if not page_text:
                continue

            raw_paragraphs = [p.strip() for p in re.split(r"\n\s*\n", page_text) if p.strip()]
            current_buffer = ""

            for para in raw_paragraphs:
                if self._is_heading(para):
                    active_heading = para

                if len(para) > self.chunk_size:
                    if current_buffer:
                        chunks.append(
                            self._build_payload(
                                manual_id=manual_id,
                                machine_code=machine_code,
                                machine_db_id=machine_db_id,
                                document_name=document_name,
                                revision=revision,
                                page_number=page.page_number,
                                chunk_index=global_chunk_index,
                                chunk_text=current_buffer,
                            )
                        )
                        global_chunk_index += 1
                        current_buffer = ""

                    for sub_segment in self._split_long_paragraph(para):
                        prefixed = (
                            f"[{active_heading}]\n{sub_segment}"
                            if active_heading and not sub_segment.startswith(active_heading)
                            else sub_segment
                        )
                        chunks.append(
                            self._build_payload(
                                manual_id=manual_id,
                                machine_code=machine_code,
                                machine_db_id=machine_db_id,
                                document_name=document_name,
                                revision=revision,
                                page_number=page.page_number,
                                chunk_index=global_chunk_index,
                                chunk_text=prefixed,
                            )
                        )
                        global_chunk_index += 1
                    continue

                candidate = f"{current_buffer}\n\n{para}".strip() if current_buffer else para
                if len(candidate) <= self.chunk_size:
                    current_buffer = candidate
                else:
                    if current_buffer:
                        chunks.append(
                            self._build_payload(
                                manual_id=manual_id,
                                machine_code=machine_code,
                                machine_db_id=machine_db_id,
                                document_name=document_name,
                                revision=revision,
                                page_number=page.page_number,
                                chunk_index=global_chunk_index,
                                chunk_text=current_buffer,
                            )
                        )
                        global_chunk_index += 1

                    overlap_prefix = ""
                    if self.chunk_overlap > 0 and current_buffer:
                        overlap_prefix = current_buffer[-self.chunk_overlap :].strip()

                    heading_prefix = (
                        f"[{active_heading}]\n"
                        if active_heading and active_heading not in para and active_heading not in overlap_prefix
                        else ""
                    )
                    current_buffer = f"{heading_prefix}{overlap_prefix}\n{para}".strip()

            if current_buffer:
                chunks.append(
                    self._build_payload(
                        manual_id=manual_id,
                        machine_code=machine_code,
                        machine_db_id=machine_db_id,
                        document_name=document_name,
                        revision=revision,
                        page_number=page.page_number,
                        chunk_index=global_chunk_index,
                        chunk_text=current_buffer,
                    )
                )
                global_chunk_index += 1

        return chunks

    @staticmethod
    def _build_payload(
        *,
        manual_id: int,
        machine_code: str,
        machine_db_id: int,
        document_name: str,
        revision: str,
        page_number: int,
        chunk_index: int,
        chunk_text: str,
    ) -> DocumentChunkPayload:
        chunk_id = f"manual_{manual_id}_m_{machine_code}_p_{page_number}_c_{chunk_index}"
        return DocumentChunkPayload(
            chunk_id=chunk_id,
            manual_id=manual_id,
            machine_id=machine_code,
            machine_db_id=machine_db_id,
            document_name=document_name,
            revision=revision,
            page_number=page_number,
            chunk_index=chunk_index,
            chunk_text=chunk_text.strip(),
        )

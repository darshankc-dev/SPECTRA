"""
Permissions for Manual management and PDF citation access.
"""
from rest_framework.permissions import BasePermission, SAFE_METHODS


class ManualAccessPermission(BasePermission):
    """
    - Authenticated users (ADMIN, ENGINEER, SUPERVISOR) may view manual metadata and open cited PDFs.
    - Strictly ADMIN users may upload, replace, reprocess, or delete official manuals.
    """

    message = "Access denied: Only Administrators are permitted to upload or modify official manuals."

    def has_permission(self, request, view) -> bool:
        user = request.user
        if not (user and user.is_authenticated and user.is_active):
            return False
        if request.method in SAFE_METHODS:
            return True
        return bool(user.role == "ADMIN" or user.is_superuser)

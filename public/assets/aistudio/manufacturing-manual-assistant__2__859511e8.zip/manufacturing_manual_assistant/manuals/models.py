"""
Database models for official PDF Machine Manuals and extracted ManualChunks.
"""
from django.conf import settings
from django.db import models
from machines.models import Machine


class Manual(models.Model):
    class ProcessingStatus(models.TextChoices):
        PENDING = "PENDING", "Pending"
        PROCESSING = "PROCESSING", "Processing"
        COMPLETED = "COMPLETED", "Completed"
        FAILED = "FAILED", "Failed"

    machine = models.ForeignKey(
        Machine,
        on_delete=models.CASCADE,
        related_name="manuals",
        db_column="machine_id",
    )
    document_name = models.CharField(max_length=255, db_index=True)
    original_filename = models.CharField(max_length=255)
    revision = models.CharField(max_length=64, default="Rev1.0")
    file_path = models.FileField(upload_to="manuals/")
    total_pages = models.PositiveIntegerField(default=0)
    file_size = models.PositiveBigIntegerField(default=0)
    processing_status = models.CharField(
        max_length=20,
        choices=ProcessingStatus.choices,
        default=ProcessingStatus.PENDING,
        db_index=True,
    )
    error_message = models.TextField(blank=True, default="")
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="uploaded_manuals",
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "manuals_manual"
        ordering = ["-uploaded_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["machine", "document_name", "revision"],
                name="unique_machine_document_revision",
            )
        ]
        indexes = [
            models.Index(fields=["machine", "processing_status"]),
            models.Index(fields=["document_name"]),
        ]

    def __str__(self) -> str:
        return f"{self.document_name} ({self.revision}) [{self.machine.machine_code}]"


class ManualChunk(models.Model):
    manual = models.ForeignKey(
        Manual,
        on_delete=models.CASCADE,
        related_name="chunks",
        db_column="manual_id",
    )
    machine = models.ForeignKey(
        Machine,
        on_delete=models.CASCADE,
        related_name="manual_chunks",
        db_column="machine_id",
    )
    chunk_text = models.TextField()
    page_number = models.PositiveIntegerField(db_index=True)
    chunk_index = models.PositiveIntegerField()
    embedding_reference = models.CharField(max_length=160, unique=True, db_index=True)
    metadata = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "manuals_manualchunk"
        ordering = ["manual", "page_number", "chunk_index"]
        constraints = [
            models.UniqueConstraint(
                fields=["manual", "chunk_index"],
                name="unique_manual_chunk_index",
            )
        ]
        indexes = [
            models.Index(fields=["machine", "manual", "page_number"]),
            models.Index(fields=["embedding_reference"]),
        ]

    def __str__(self) -> str:
        return f"Chunk #{self.chunk_index} (Page {self.page_number}) — {self.manual.document_name}"

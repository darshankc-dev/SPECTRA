from django.conf import settings
from rest_framework import serializers
from machines.models import Machine
from .models import Manual, ManualChunk
from .pdf_processor import PDFExtractionError, PDFProcessor


class ManualSerializer(serializers.ModelSerializer):
    machine_code = serializers.CharField(source="machine.machine_code", read_only=True)
    machine_name = serializers.CharField(source="machine.machine_name", read_only=True)
    uploaded_by_username = serializers.CharField(source="uploaded_by.username", read_only=True, default="System")
    chunk_count = serializers.IntegerField(source="chunks.count", read_only=True)

    class Meta:
        model = Manual
        fields = [
            "id",
            "machine",
            "machine_code",
            "machine_name",
            "document_name",
            "original_filename",
            "revision",
            "total_pages",
            "file_size",
            "processing_status",
            "error_message",
            "chunk_count",
            "uploaded_by",
            "uploaded_by_username",
            "uploaded_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "original_filename",
            "total_pages",
            "file_size",
            "processing_status",
            "error_message",
            "chunk_count",
            "uploaded_by",
            "uploaded_at",
            "updated_at",
        ]


class ManualUploadSerializer(serializers.Serializer):
    machine_id = serializers.CharField(required=True, help_text="Machine ID or machine_code (e.g., HP200 or AC90)")
    revision = serializers.CharField(required=True, max_length=64)
    document_name = serializers.CharField(required=False, allow_blank=True, max_length=255)
    replace_existing = serializers.BooleanField(required=False, default=False)
    file = serializers.FileField(required=True)

    def validate_file(self, uploaded_file):
        filename = uploaded_file.name or ""
        if not filename.lower().endswith(".pdf"):
            raise serializers.ValidationError("Only .pdf files are permitted.")

        content_type = getattr(uploaded_file, "content_type", "")
        if content_type and content_type not in ("application/pdf", "application/x-pdf", "binary/octet-stream"):
            raise serializers.ValidationError(f"Invalid MIME type '{content_type}'. Expected application/pdf.")

        max_bytes = getattr(settings, "MAX_PDF_UPLOAD_SIZE_BYTES", 52428800)
        if uploaded_file.size > max_bytes:
            raise serializers.ValidationError("Uploaded PDF exceeds the 50 MB size limit.")

        header = uploaded_file.read(1024)
        uploaded_file.seek(0)
        try:
            PDFProcessor.validate_pdf_header(header, max_size_bytes=max_bytes)
        except PDFExtractionError as exc:
            raise serializers.ValidationError(str(exc)) from exc

        return uploaded_file

    def validate(self, attrs):
        raw_machine = str(attrs["machine_id"]).strip()
        machine = None
        if raw_machine.isdigit():
            machine = Machine.objects.filter(pk=int(raw_machine)).first()
        if machine is None:
            machine = Machine.objects.filter(machine_code__iexact=raw_machine).first()
        if machine is None:
            raise serializers.ValidationError({"machine_id": f"Machine '{raw_machine}' does not exist."})

        uploaded_file = attrs["file"]
        doc_name = (attrs.get("document_name") or "").strip() or uploaded_file.name
        revision = attrs["revision"].strip()

        existing = Manual.objects.filter(
            machine=machine,
            document_name__iexact=doc_name,
            revision__iexact=revision,
        ).first()

        if existing and not attrs.get("replace_existing", False):
            raise serializers.ValidationError(
                {
                    "document_name": (
                        f"Manual '{doc_name}' ({revision}) already exists for {machine.machine_code}. "
                        "Use replace_existing=true or reprocess the existing manual."
                    )
                }
            )

        attrs["machine_obj"] = machine
        attrs["resolved_document_name"] = doc_name
        attrs["existing_manual"] = existing
        return attrs

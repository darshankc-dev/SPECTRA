from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("machines", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="Manual",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("document_name", models.CharField(db_index=True, max_length=255)),
                ("original_filename", models.CharField(max_length=255)),
                ("revision", models.CharField(default="Rev1.0", max_length=64)),
                ("file_path", models.FileField(upload_to="manuals/")),
                ("total_pages", models.PositiveIntegerField(default=0)),
                ("file_size", models.PositiveBigIntegerField(default=0)),
                (
                    "processing_status",
                    models.CharField(
                        choices=[
                            ("PENDING", "Pending"),
                            ("PROCESSING", "Processing"),
                            ("COMPLETED", "Completed"),
                            ("FAILED", "Failed"),
                        ],
                        db_index=True,
                        default="PENDING",
                        max_length=20,
                    ),
                ),
                ("error_message", models.TextField(blank=True, default="")),
                ("uploaded_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "machine",
                    models.ForeignKey(
                        db_column="machine_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="manuals",
                        to="machines.machine",
                    ),
                ),
                (
                    "uploaded_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="uploaded_manuals",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "db_table": "manuals_manual",
                "ordering": ["-uploaded_at"],
                "indexes": [
                    models.Index(fields=["machine", "processing_status"], name="manuals_man_machine_status_idx"),
                    models.Index(fields=["document_name"], name="manuals_man_doc_name_idx"),
                ],
                "constraints": [
                    models.UniqueConstraint(
                        fields=("machine", "document_name", "revision"),
                        name="unique_machine_document_revision",
                    )
                ],
            },
        ),
        migrations.CreateModel(
            name="ManualChunk",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("chunk_text", models.TextField()),
                ("page_number", models.PositiveIntegerField(db_index=True)),
                ("chunk_index", models.PositiveIntegerField()),
                ("embedding_reference", models.CharField(db_index=True, max_length=160, unique=True)),
                ("metadata", models.JSONField(default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "machine",
                    models.ForeignKey(
                        db_column="machine_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="manual_chunks",
                        to="machines.machine",
                    ),
                ),
                (
                    "manual",
                    models.ForeignKey(
                        db_column="manual_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="chunks",
                        to="manuals.manual",
                    ),
                ),
            ],
            options={
                "db_table": "manuals_manualchunk",
                "ordering": ["manual", "page_number", "chunk_index"],
                "indexes": [
                    models.Index(fields=["machine", "manual", "page_number"], name="manuals_chk_mach_man_pg_idx"),
                    models.Index(fields=["embedding_reference"], name="manuals_chk_emb_ref_idx"),
                ],
                "constraints": [
                    models.UniqueConstraint(
                        fields=("manual", "chunk_index"),
                        name="unique_manual_chunk_index",
                    )
                ],
            },
        ),
    ]

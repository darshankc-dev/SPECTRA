"""
End-to-end idempotent PDF Ingestion Service.
Coordinates:
1. Status transition -> PROCESSING
2. PyMuPDF page-by-page extraction (preserving 1-indexed page numbers)
3. Paragraph & heading aware chunking
4. Gemini semantic embedding generation
5. Persistent ChromaDB vector storage (with pre-cleanup for idempotency)
6. PostgreSQL ManualChunk relational persistence inside an atomic transaction
7. Status transition -> COMPLETED (or FAILED with detailed diagnostic message)
"""
import logging
from django.conf import settings
from django.db import transaction

from .chunking import ChunkingService
from .embedding import EmbeddingGenerationError, GeminiEmbeddingService
from .models import Manual, ManualChunk
from .pdf_processor import PDFExtractionError, PDFProcessor
from .vector_store import ChromaVectorStore, VectorStoreError

logger = logging.getLogger(__name__)


class ManualIngestionService:
    def __init__(
        self,
        embedding_service: GeminiEmbeddingService | None = None,
        vector_store: ChromaVectorStore | None = None,
        chunking_service: ChunkingService | None = None,
    ):
        self.embedding_service = embedding_service or GeminiEmbeddingService()
        self.vector_store = vector_store or ChromaVectorStore(
            persist_directory=getattr(settings, "CHROMA_PERSIST_DIRECTORY", "./vector_store")
        )
        self.chunking_service = chunking_service or ChunkingService(
            chunk_size=getattr(settings, "CHUNK_SIZE", 900),
            chunk_overlap=getattr(settings, "CHUNK_OVERLAP", 180),
        )

    def process_manual(self, manual: Manual) -> Manual:
        manual.processing_status = Manual.ProcessingStatus.PROCESSING
        manual.error_message = ""
        manual.save(update_fields=["processing_status", "error_message", "updated_at"])

        try:
            extracted_doc = PDFProcessor.extract_from_path(manual.file_path.path)
            chunk_payloads = self.chunking_service.chunk_pages(
                pages=extracted_doc.pages,
                manual_id=manual.id,
                machine_code=manual.machine.machine_code,
                machine_db_id=manual.machine.id,
                document_name=manual.document_name,
                revision=manual.revision,
            )

            if not chunk_payloads:
                raise PDFExtractionError("No meaningful text chunks could be created from the extracted PDF pages.")

            embeddings = self.embedding_service.embed_texts([c.chunk_text for c in chunk_payloads])

            # Ensure idempotency: remove any prior vectors & chunks for this manual before replacing
            self.vector_store.delete_manual_vectors(manual.id)
            self.vector_store.upsert_chunks(chunk_payloads, embeddings)

            with transaction.atomic():
                ManualChunk.objects.filter(manual=manual).delete()
                chunk_models = [
                    ManualChunk(
                        manual=manual,
                        machine=manual.machine,
                        chunk_text=payload.chunk_text,
                        page_number=payload.page_number,
                        chunk_index=payload.chunk_index,
                        embedding_reference=payload.chunk_id,
                        metadata=payload.to_chroma_metadata(),
                    )
                    for payload in chunk_payloads
                ]
                ManualChunk.objects.bulk_create(chunk_models)

                manual.total_pages = extracted_doc.total_pages
                manual.processing_status = Manual.ProcessingStatus.COMPLETED
                manual.error_message = ""
                manual.save(update_fields=["total_pages", "processing_status", "error_message", "updated_at"])

            logger.info(
                "Successfully ingested manual '%s' (id=%d, machine=%s, pages=%d, chunks=%d).",
                manual.document_name,
                manual.id,
                manual.machine.machine_code,
                manual.total_pages,
                len(chunk_payloads),
            )
            return manual

        except (PDFExtractionError, EmbeddingGenerationError, VectorStoreError, Exception) as exc:
            # Clean up any partial vector records so failed ingestions never pollute retrieval
            try:
                self.vector_store.delete_manual_vectors(manual.id)
            except Exception:
                pass
            ManualChunk.objects.filter(manual=manual).delete()

            manual.processing_status = Manual.ProcessingStatus.FAILED
            manual.error_message = str(exc)
            manual.save(update_fields=["processing_status", "error_message", "updated_at"])
            logger.error(
                "Manual ingestion FAILED for '%s' (id=%d): %s",
                manual.document_name,
                manual.id,
                exc,
            )
            return manual

    def delete_manual_completely(self, manual: Manual) -> None:
        """Removes both ChromaDB vectors, PostgreSQL records, and stored PDF file."""
        self.vector_store.delete_manual_vectors(manual.id)
        with transaction.atomic():
            if manual.file_path:
                manual.file_path.delete(save=False)
            manual.delete()

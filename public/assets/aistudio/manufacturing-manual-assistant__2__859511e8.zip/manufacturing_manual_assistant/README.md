# Manufacturing Manual Assistant

An enterprise-grade, AI-powered industrial technical documentation and Retrieval-Augmented Generation (RAG) system designed for factory engineers, maintenance technicians, and plant supervisors.

---

## 1. Project Overview

**Manufacturing Manual Assistant** enables industrial teams to upload official equipment PDF manuals, index them into a machine-isolated vector knowledge base, and ask technical operations, troubleshooting, safety, and maintenance questions in natural language. Every technical response is grounded strictly in the selected machine's uploaded official PDF manuals and includes verifiable, clickable page-level citations.

## 2. Problem Statement

Industrial engineers and maintenance teams frequently need to consult multi-hundred-page equipment operation and maintenance manuals to:
- Understand complex machine operating sequences.
- Troubleshoot hydraulic, pneumatic, or electrical faults.
- Identify specific component part numbers, tolerances, and pressure/temperature ratings.
- Follow preventive maintenance schedules and lockout/tagout (LOTO) safety procedures.

Manual searching across lengthy PDF documents slows down critical repairs and increases downtime. At the same time, generic ungrounded LLMs risk hallucinating unsafe pressures, tolerances, or cross-machine procedures.

## 3. Proposed Solution

A role-governed, machine-isolated RAG platform where:
1. **Administrators** upload official machine PDF manuals (`HP200_Operations_Rev1_0.pdf`, `HP200_Maintenance_Rev1_0.pdf`, `AC90_Operations_Maintenance_Rev1_0.pdf`).
2. **PyMuPDF (`fitz`)** extracts text page-by-page while preserving exact 1-indexed page numbers and detecting unextractable scanned documents.
3. **Chunking & Gemini Embeddings (`gemini-embedding-2-preview`)** split pages into heading- and paragraph-aware chunks and generate semantic embeddings.
4. **ChromaDB** stores vectors persistently on disk with strict machine metadata (`machine_id`, `manual_id`, `document_name`, `revision`, `page_number`, `chunk_index`).
5. **PostgreSQL** stores all relational records (`User`, `Machine`, `Manual`, `ManualChunk`, `QueryHistory`). **SQLite is strictly prohibited.**
6. **Gemini Flash (`gemini-3.8-flash`)** generates structured answers strictly from retrieved evidence for the selected machine, or returns a deterministic refusal when evidence is insufficient.

## 4. Key Features

- **Strict Machine Isolation**: Selecting **HP-200 Hydraulic Press (`HP200`)** retrieves exclusively from HP-200 manuals; selecting **AC-90 Air Compressor (`AC90`)** retrieves exclusively from AC-90 manuals. Enforced via ChromaDB `where={"machine_id": ...}` filtering, independent post-retrieval validation, and PostgreSQL citation verification.
- **Verifiable Page-Level Citations**: Every supported answer displays clickable citations (`Document Name`, `Revision`, `Page Number`, and expandable supporting text) that open the official PDF at the exact cited page.
- **Evidence-Based Refusal**: Returns `"I couldn't find sufficient supporting information in the selected machine's available manuals to answer this question reliably."` when manuals are not yet uploaded or do not cover the question.
- **Three Role-Based Experiences (`ADMIN`, `ENGINEER`, `SUPERVISOR`)**: Enforced on the backend across all REST APIs and views.
- **Prompt-Injection Defense**: Sanitizes untrusted PDF text before prompt assembly so embedded directives inside PDFs can never override system rules.

## 5. Technology Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend** | HTML5, CSS3, JavaScript, Bootstrap 5, Lucide / Bootstrap Icons (plus interactive React + Tailwind preview runtime in AI Studio) |
| **Backend** | Python 3, Django 5, Django REST Framework |
| **Relational Database** | **PostgreSQL ONLY** (`django.db.backends.postgresql`, `psycopg[binary]`) |
| **Vector Database** | ChromaDB (`PersistentClient` with cosine similarity & metadata filtering) |
| **PDF Processing** | PyMuPDF (`fitz`) |
| **AI Integration** | Google Gemini API (`google-genai` SDK) — `gemini-3.8-flash` & `gemini-embedding-2-preview` |
| **Authentication** | Django Authentication & Server-Side Role-Based Access Control (RBAC) |

## 6. Architecture

```
+-------------------------------------------------------------------------+
|                        FRONTEND (Admin / Engineer / Supervisor)         |
+------------------------------------+------------------------------------+
                                     | REST API (/api/*) & Session Auth
                                     v
+-------------------------------------------------------------------------+
|                    DJANGO + DJANGO REST FRAMEWORK BACKEND               |
|  - RBAC Permissions (IsAdminRole, IsAdminOrSupervisorRole, etc.)        |
|  - ManualIngestionService (PyMuPDF -> Chunking -> Gemini Embeddings)    |
|  - RAGPipeline (MachineRetrievalService -> CitationService -> Gemini)   |
+-------------------+-----------------------------------+-----------------+
                    |                                   |
   Relational ORM   |                                   | Vector Embeddings &
   (psycopg)        v                                   v Metadata Filtering
+-----------------------------------+   +---------------------------------+
|   LOCAL POSTGRESQL DATABASE       |   |   CHROMADB PERSISTENT STORE     |
| - accounts_user                   |   | - manufacturing_manual_chunks   |
| - machines_machine (HP200, AC90)  |   | - where={"machine_id": code}    |
| - manuals_manual                  |   +---------------------------------+
| - manuals_manualchunk             |
| - assistant_queryhistory          |
+-----------------------------------+
```

## 7. Project Structure

```text
manufacturing_manual_assistant/
├── manage.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── run_standalone_tests.py
├── sql/
│   └── create_database.sql
├── config/
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
├── accounts/
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── permissions.py
│   ├── forms.py
│   ├── urls.py
│   ├── urls_auth.py
│   ├── urls_users.py
│   ├── migrations/0001_initial.py
│   └── tests.py
├── machines/
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── urls.py
│   ├── migrations/0001_initial.py
│   └── tests.py
├── manuals/
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── ingestion.py
│   ├── pdf_processor.py
│   ├── chunking.py
│   ├── embedding.py
│   ├── vector_store.py
│   ├── permissions.py
│   ├── urls.py
│   ├── migrations/0001_initial.py
│   └── tests.py
├── assistant/
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── retrieval.py
│   ├── rag_pipeline.py
│   ├── gemini_service.py
│   ├── citation_service.py
│   ├── safety_service.py
│   ├── prompts.py
│   ├── urls.py
│   ├── migrations/0001_initial.py
│   └── tests.py
├── dashboard/
│   ├── views.py
│   ├── analytics.py
│   ├── urls.py
│   └── tests.py
├── templates/
├── static/
├── media/manuals/
├── vector_store/
└── logs/
```

## 8. PostgreSQL Installation & Configuration (Mandatory — No SQLite)

Ensure your local PostgreSQL server is running on port `5432` (default service on Windows: `postgresql-x64-16` or similar).

Verify service status in **Windows PowerShell**:
```powershell
Get-Service -Name *postgres*
```

## 9. Database Creation

Create the `manufacturing_manual_assistant` database in your local PostgreSQL server using `psql` or pgAdmin:

```powershell
psql -U postgres -c "CREATE DATABASE manufacturing_manual_assistant ENCODING 'UTF8';"
```

Or run the included SQL script:
```powershell
psql -U postgres -f sql\create_database.sql
```

## 10. Python Environment Setup (Windows PowerShell)

```powershell
cd manufacturing_manual_assistant
python -m venv venv
venv\Scripts\activate
```

## 11. Dependency Installation

```powershell
pip install --upgrade pip
pip install -r requirements.txt
```

## 12. Gemini API Configuration

Copy `.env.example` to `.env` and populate your local PostgreSQL password and Gemini API key:

```powershell
Copy-Item .env.example .env
```

Edit `.env`:
```ini
SECRET_KEY=your-production-grade-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

DB_NAME=manufacturing_manual_assistant
DB_USER=postgres
DB_PASSWORD=YOUR_LOCAL_POSTGRES_PASSWORD
DB_HOST=localhost
DB_PORT=5432

GEMINI_API_KEY=YOUR_GEMINI_API_KEY
GEMINI_FLASH_MODEL=gemini-3.8-flash
GEMINI_EMBEDDING_MODEL=gemini-embedding-2-preview

CHROMA_PERSIST_DIRECTORY=./vector_store
```

## 13. ChromaDB Configuration

ChromaDB is automatically initialized as a persistent local vector store in `CHROMA_PERSIST_DIRECTORY` (`./vector_store`) using cosine similarity (`hnsw:space = cosine`).

## 14. Django Migrations (PostgreSQL)

Run migrations against your local PostgreSQL database:

```powershell
python manage.py makemigrations
python manage.py migrate
```

The initial migrations automatically seed:
- **Machines**:
  - `HP200` — `HP-200 Hydraulic Press`
  - `AC90` — `AC-90 Air Compressor`
- **Role Accounts**:
  - Admin: `admin` / `Admin@12345`
  - Engineer: `engineer` / `Engineer@12345`
  - Supervisor: `supervisor` / `Supervisor@12345`

## 15. Demo User Creation (Optional Additional Superuser)

```powershell
python manage.py createsuperuser
```

## 16. Application Startup

```powershell
python manage.py runserver 8000
```

Open `http://localhost:8000/login/` in your browser.

## 17. PDF Upload Instructions (Official Manuals)

Log in as **Admin** (`admin` / `Admin@12345`), navigate to **Manual Management**, and upload the three official PDF documents:
1. **Machine**: `HP200` (`HP-200 Hydraulic Press`) · **Revision**: `Rev1.0` · **File**: `HP200_Operations_Rev1_0.pdf`
2. **Machine**: `HP200` (`HP-200 Hydraulic Press`) · **Revision**: `Rev1.0` · **File**: `HP200_Maintenance_Rev1_0.pdf`
3. **Machine**: `AC90` (`AC-90 Air Compressor`) · **Revision**: `Rev1.0` · **File**: `AC90_Operations_Maintenance_Rev1_0.pdf`

## 18. Document Indexing Instructions

Upon upload, the backend automatically executes the 6-step ingestion pipeline:
1. Validates PDF header (`%PDF-`), extension, MIME type, and file size.
2. Extracts text page-by-page using PyMuPDF (`fitz`) preserving 1-indexed page numbers.
3. Splits pages into overlapping semantic chunks while preserving section headings.
4. Generates embeddings via Gemini (`gemini-embedding-2-preview`).
5. Stores vectors and metadata in ChromaDB (`manufacturing_manual_chunks`).
6. Saves relational `ManualChunk` records in PostgreSQL and marks `processing_status = COMPLETED`.

If any manual needs re-indexing, click **Reprocess** in Manual Management (idempotent cleanup + re-index).

## 19. REST API Documentation

| Method | Endpoint | Access Role | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/login/` | Public | Authenticate user session |
| `POST` | `/api/auth/logout/` | Authenticated | Terminate session |
| `GET` | `/api/auth/profile/` | Authenticated | Current user profile & role |
| `GET` | `/api/machines/` | Authenticated | List all machines & manual counts |
| `GET` | `/api/machines/{id}/` | Authenticated | Machine details |
| `POST` | `/api/machines/` | `ADMIN` | Register new machine |
| `GET` | `/api/manuals/` | Authenticated | List manuals (`?machine_id=HP200`) |
| `POST` | `/api/manuals/upload/` | `ADMIN` | Upload & index official PDF manual |
| `GET` | `/api/manuals/{id}/` | Authenticated | Manual metadata & status |
| `DELETE` | `/api/manuals/{id}/` | `ADMIN` | Delete manual, chunks, & vectors |
| `POST` | `/api/manuals/{id}/reprocess/` | `ADMIN` | Idempotently reprocess manual |
| `GET` | `/api/manuals/{id}/file/` | Authenticated | Open cited PDF page with machine check |
| `POST` | `/api/assistant/ask/` | Authenticated | Ask machine-isolated RAG question |
| `GET` | `/api/assistant/history/` | Authenticated | Query history (own for Engineer, all for Admin/Supervisor) |
| `GET` | `/api/assistant/history/{id}/` | Authenticated | Query details & citations |
| `GET` | `/api/dashboard/admin/` | `ADMIN` | Admin system & indexing metrics |
| `GET` | `/api/dashboard/engineer/` | Authenticated | Engineer workspace & recent questions |
| `GET` | `/api/dashboard/supervisor/` | `SUPERVISOR` / `ADMIN` | Supervisor analytics & unsupported queries |
| `GET/POST` | `/api/users/` | `ADMIN` | List or create users with roles |
| `PATCH/DELETE` | `/api/users/{id}/` | `ADMIN` | Update role/status or delete user |

## 20. Automated Testing

Run the full Django test suite against your local PostgreSQL server:
```powershell
python manage.py test accounts machines manuals assistant dashboard --verbosity=2
```

Or run with `pytest`:
```powershell
pytest -v
```

Run the standalone pure-Python verification suite:
```powershell
python run_standalone_tests.py
```

## 21. Troubleshooting

- **`psycopg.OperationalError: connection to server at "localhost" (::1), port 5432 failed`**:
  Verify that your local PostgreSQL service is started and that `DB_PASSWORD` in `.env` matches your local `postgres` user password.
- **`No extractable text found in any page of this PDF`**:
  The uploaded PDF is a scanned image without a text layer. Run OCR preprocessing before uploading.
- **`GEMINI_API_KEY environment variable is not configured`**:
  Set a valid `GEMINI_API_KEY` in `.env`.

## 22. Deployment Considerations

- Set `DEBUG=False` and configure a strong random `SECRET_KEY` in production.
- Serve static files via WhiteNoise or Nginx (`python manage.py collectstatic`).
- Run Django behind Gunicorn/Uvicorn with TLS termination and restrict PostgreSQL network access to trusted application hosts.

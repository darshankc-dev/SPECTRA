from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient
from accounts.models import User


class DashboardRolePermissionTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin, _ = User.objects.update_or_create(
            username="dash_admin",
            defaults={"email": "dash_admin@factory.local", "role": User.Role.ADMIN},
        )
        self.engineer, _ = User.objects.update_or_create(
            username="dash_eng",
            defaults={"email": "dash_eng@factory.local", "role": User.Role.ENGINEER},
        )
        self.supervisor, _ = User.objects.update_or_create(
            username="dash_sup",
            defaults={"email": "dash_sup@factory.local", "role": User.Role.SUPERVISOR},
        )

    def test_engineer_cannot_access_admin_or_supervisor_dashboards(self):
        self.client.force_authenticate(user=self.engineer)
        admin_res = self.client.get("/api/dashboard/admin/")
        self.assertEqual(admin_res.status_code, status.HTTP_403_FORBIDDEN)

        sup_res = self.client.get("/api/dashboard/supervisor/")
        self.assertEqual(sup_res.status_code, status.HTTP_403_FORBIDDEN)

        eng_res = self.client.get("/api/dashboard/engineer/")
        self.assertEqual(eng_res.status_code, status.HTTP_200_OK)

    def test_supervisor_can_access_supervisor_dashboard_but_not_admin(self):
        self.client.force_authenticate(user=self.supervisor)
        sup_res = self.client.get("/api/dashboard/supervisor/")
        self.assertEqual(sup_res.status_code, status.HTTP_200_OK)

        admin_res = self.client.get("/api/dashboard/admin/")
        self.assertEqual(admin_res.status_code, status.HTTP_403_FORBIDDEN)

from django.urls import path
from .views import AdminDashboardAPIView, EngineerDashboardAPIView, SupervisorDashboardAPIView

urlpatterns = [
    path("admin/", AdminDashboardAPIView.as_view(), name="api_dashboard_admin"),
    path("engineer/", EngineerDashboardAPIView.as_view(), name="api_dashboard_engineer"),
    path("supervisor/", SupervisorDashboardAPIView.as_view(), name="api_dashboard_supervisor"),
]

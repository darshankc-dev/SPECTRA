"""
Database-backed analytics service for Admin, Engineer, and Supervisor dashboards.
Uses actual PostgreSQL records with zero fabricated metrics.
"""
from typing import Any, Dict
from django.db.models import Count

from accounts.models import User
from assistant.models import QueryHistory
from assistant.serializers import QueryHistorySerializer
from machines.models import Machine
from machines.serializers import MachineSerializer
from manuals.models import Manual, ManualChunk
from manuals.serializers import ManualSerializer


class DashboardAnalyticsService:
    @staticmethod
    def get_admin_analytics() -> Dict[str, Any]:
        total_users = User.objects.count()
        total_machines = Machine.objects.count()
        total_manuals = Manual.objects.count()
        indexed_manuals = Manual.objects.filter(processing_status=Manual.ProcessingStatus.COMPLETED).count()
        failed_manuals = Manual.objects.filter(processing_status=Manual.ProcessingStatus.FAILED).count()
        pending_manuals = Manual.objects.filter(
            processing_status__in=[Manual.ProcessingStatus.PENDING, Manual.ProcessingStatus.PROCESSING]
        ).count()
        total_chunks = ManualChunk.objects.count()
        total_queries = QueryHistory.objects.count()

        recent_uploads = ManualSerializer(
            Manual.objects.select_related("machine", "uploaded_by").order_by("-uploaded_at")[:10],
            many=True,
        ).data
        recent_queries = QueryHistorySerializer(
            QueryHistory.objects.select_related("user", "machine").order_by("-created_at")[:10],
            many=True,
        ).data

        return {
            "total_users": total_users,
            "total_machines": total_machines,
            "total_manuals": total_manuals,
            "indexed_manuals": indexed_manuals,
            "failed_processing_jobs": failed_manuals,
            "pending_processing_jobs": pending_manuals,
            "total_chunks": total_chunks,
            "total_queries": total_queries,
            "recent_uploads": recent_uploads,
            "recent_activities": recent_queries,
        }

    @staticmethod
    def get_engineer_analytics(user: User) -> Dict[str, Any]:
        machines = MachineSerializer(
            Machine.objects.prefetch_related("manuals").all().order_by("machine_code"),
            many=True,
        ).data
        user_queries_qs = QueryHistory.objects.select_related("user", "machine").filter(user=user)
        recent_questions = QueryHistorySerializer(user_queries_qs[:15], many=True).data

        return {
            "user_query_count": user_queries_qs.count(),
            "supported_query_count": user_queries_qs.filter(confidence_status="SUPPORTED").count(),
            "machines": machines,
            "recent_questions": recent_questions,
        }

    @staticmethod
    def get_supervisor_analytics() -> Dict[str, Any]:
        total_queries = QueryHistory.objects.count()
        supported_queries = QueryHistory.objects.filter(confidence_status="SUPPORTED").count()
        unsupported_queries_qs = QueryHistory.objects.select_related("user", "machine").filter(
            confidence_status="INSUFFICIENT_EVIDENCE"
        )
        unsupported_count = unsupported_queries_qs.count()

        machine_dist = list(
            Machine.objects.annotate(query_count=Count("queries"))
            .values("id", "machine_code", "machine_name", "query_count")
            .order_by("machine_code")
        )

        engineer_activity = list(
            User.objects.filter(role="ENGINEER")
            .annotate(query_count=Count("queries"))
            .values("id", "username", "email", "query_count", "last_login")
            .order_by("-query_count")
        )

        manuals_status = ManualSerializer(
            Manual.objects.select_related("machine", "uploaded_by").order_by("-uploaded_at"),
            many=True,
        ).data

        return {
            "total_queries": total_queries,
            "supported_queries": supported_queries,
            "unsupported_queries_count": unsupported_count,
            "machine_distribution": machine_dist,
            "engineer_activity": engineer_activity,
            "unsupported_questions": QueryHistorySerializer(unsupported_queries_qs[:20], many=True).data,
            "recent_queries": QueryHistorySerializer(
                QueryHistory.objects.select_related("user", "machine").order_by("-created_at")[:25],
                many=True,
            ).data,
            "manual_processing_status": manuals_status,
        }

"""
REST API & Server-Rendered Views for Admin, Engineer, and Supervisor Dashboards.
Enforces strict server-side role verification on every view.
"""
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import redirect, render
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import User
from accounts.permissions import IsAdminOrSupervisorRole, IsAdminRole
from assistant.models import QueryHistory
from machines.models import Machine
from manuals.models import Manual
from .analytics import DashboardAnalyticsService


class AdminDashboardAPIView(APIView):
    """GET /api/dashboard/admin/"""

    permission_classes = [IsAdminRole]

    def get(self, request):
        return Response(DashboardAnalyticsService.get_admin_analytics(), status=status.HTTP_200_OK)


class EngineerDashboardAPIView(APIView):
    """GET /api/dashboard/engineer/"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(DashboardAnalyticsService.get_engineer_analytics(request.user), status=status.HTTP_200_OK)


class SupervisorDashboardAPIView(APIView):
    """GET /api/dashboard/supervisor/"""

    permission_classes = [IsAdminOrSupervisorRole]

    def get(self, request):
        return Response(DashboardAnalyticsService.get_supervisor_analytics(), status=status.HTTP_200_OK)


# ==============================================================================
# SERVER-RENDERED TEMPLATE VIEWS
# ==============================================================================
def login_page_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    error = None
    success = None
    if request.method == "POST":
        action = (request.POST.get("action") or "login").strip().lower()
        role = (request.POST.get("role") or "ENGINEER").strip().upper()
        username = (request.POST.get("username") or "").strip()
        password = request.POST.get("password") or ""

        if action == "register":
            email = (request.POST.get("email") or "").strip()
            if not username or not email or len(password) < 6:
                error = "Please provide a username, valid email, and password (at least 6 characters)."
            elif role not in User.Role.values:
                error = "Invalid role selected."
            elif User.objects.filter(username__iexact=username).exists():
                error = f"Username '{username}' is already registered."
            elif User.objects.filter(email__iexact=email).exists():
                error = f"Email '{email}' is already registered."
            else:
                new_user = User(username=username, email=email, role=role, is_active=True)
                new_user.set_password(password)
                new_user.save()
                success = f"Registered '{username}' as {role}. Please sign in with your credentials."
        else:
            user = authenticate(request, username=username, password=password)
            if user is None:
                try:
                    u_obj = User.objects.get(email__iexact=username)
                    user = authenticate(request, username=u_obj.username, password=password)
                except User.DoesNotExist:
                    user = None
            if user is None:
                error = "Invalid credentials. If you do not have an account yet, please register first."
            elif not user.is_active:
                error = "This user account has been deactivated."
            elif role and user.role != role:
                error = f"This account is registered under the {user.role} role. Please select '{user.role}' to sign in."
            else:
                login(request, user)
                return redirect("home")
    return render(request, "login.html", {"error": error, "success": success})


@login_required
def logout_page_view(request):
    logout(request)
    return redirect("login_page")


@login_required
def index_redirect_view(request):
    if request.user.is_admin_role:
        return redirect("admin_dashboard_page")
    if request.user.is_supervisor_role:
        return redirect("supervisor_dashboard_page")
    return redirect("engineer_dashboard_page")


@login_required
def admin_dashboard_page(request):
    if not request.user.is_admin_role:
        return render(request, "errors/403.html", status=403)
    context = DashboardAnalyticsService.get_admin_analytics()
    return render(request, "admin_dashboard.html", context)


@login_required
def engineer_dashboard_page(request):
    context = DashboardAnalyticsService.get_engineer_analytics(request.user)
    return render(request, "engineer_dashboard.html", context)


@login_required
def supervisor_dashboard_page(request):
    if not (request.user.is_supervisor_role or request.user.is_admin_role):
        return render(request, "errors/403.html", status=403)
    context = DashboardAnalyticsService.get_supervisor_analytics()
    return render(request, "supervisor_dashboard.html", context)


@login_required
def assistant_page(request):
    machines = Machine.objects.all().order_by("machine_code")
    selected_code = request.GET.get("machine", "HP200")
    return render(
        request,
        "assistant.html",
        {"machines": machines, "selected_machine_code": selected_code},
    )


@login_required
def manual_management_page(request):
    if not request.user.is_admin_role:
        return render(request, "errors/403.html", status=403)
    manuals = Manual.objects.select_related("machine", "uploaded_by").all()
    machines = Machine.objects.all().order_by("machine_code")
    return render(request, "manual_management.html", {"manuals": manuals, "machines": machines})


@login_required
def machine_management_page(request):
    if not request.user.is_admin_role:
        return render(request, "errors/403.html", status=403)
    machines = Machine.objects.prefetch_related("manuals").all().order_by("machine_code")
    return render(request, "machine_management.html", {"machines": machines})


@login_required
def user_management_page(request):
    if not request.user.is_admin_role:
        return render(request, "errors/403.html", status=403)
    users = User.objects.all().order_by("-date_joined")
    return render(request, "user_management.html", {"users": users})


@login_required
def history_page(request):
    qs = QueryHistory.objects.select_related("user", "machine").all()
    if request.user.role == "ENGINEER" and not request.user.is_superuser:
        qs = qs.filter(user=request.user)
    return render(request, "history.html", {"history_items": qs[:100]})

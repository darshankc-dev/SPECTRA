"""
Root URL configuration for Manufacturing Manual Assistant.
Includes both REST API routes (/api/*) and server-rendered template views.
"""
from django.contrib import admin
from django.urls import include, path
from dashboard import views as dashboard_views

urlpatterns = [
    path("django-admin/", admin.site.urls),
    # REST API Endpoints
    path("api/auth/", include("accounts.urls_auth")),
    path("api/users/", include("accounts.urls_users")),
    path("api/machines/", include("machines.urls")),
    path("api/manuals/", include("manuals.urls")),
    path("api/assistant/", include("assistant.urls")),
    path("api/dashboard/", include("dashboard.urls")),
    # Web Interface Views
    path("", dashboard_views.index_redirect_view, name="home"),
    path("login/", dashboard_views.login_page_view, name="login_page"),
    path("logout/", dashboard_views.logout_page_view, name="logout_page"),
    path("dashboard/admin/", dashboard_views.admin_dashboard_page, name="admin_dashboard_page"),
    path("dashboard/engineer/", dashboard_views.engineer_dashboard_page, name="engineer_dashboard_page"),
    path("dashboard/supervisor/", dashboard_views.supervisor_dashboard_page, name="supervisor_dashboard_page"),
    path("assistant/", dashboard_views.assistant_page, name="assistant_page"),
    path("manuals/", dashboard_views.manual_management_page, name="manual_management_page"),
    path("machines/", dashboard_views.machine_management_page, name="machine_management_page"),
    path("users/", dashboard_views.user_management_page, name="user_management_page"),
    path("history/", dashboard_views.history_page, name="history_page"),
]

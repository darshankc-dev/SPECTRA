from django.urls import path
from .views import MachineDetailAPIView, MachineListCreateAPIView

urlpatterns = [
    path("", MachineListCreateAPIView.as_view(), name="api_machines_list_create"),
    path("<int:pk>/", MachineDetailAPIView.as_view(), name="api_machines_detail"),
]

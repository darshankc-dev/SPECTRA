from django.db import migrations, models


def seed_initial_machines(apps, schema_editor):
    Machine = apps.get_model("machines", "Machine")
    initial_machines = [
        {
            "machine_code": "HP200",
            "machine_name": "HP-200 Hydraulic Press",
            "description": (
                "Heavy-duty 200-ton industrial hydraulic press system. Supported official manuals: "
                "HP200_Operations_Rev1_0.pdf and HP200_Maintenance_Rev1_0.pdf."
            ),
            "manufacturer": "Apex Heavy Industrial Systems",
        },
        {
            "machine_code": "AC90",
            "machine_name": "AC-90 Air Compressor",
            "description": (
                "Rotary screw industrial air compressor unit (90 kW). Supported official manual: "
                "AC90_Operations_Maintenance_Rev1_0.pdf."
            ),
            "manufacturer": "AeroForce Pneumatic Corp.",
        },
    ]
    for item in initial_machines:
        Machine.objects.update_or_create(
            machine_code=item["machine_code"],
            defaults=item,
        )


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Machine",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("machine_code", models.CharField(db_index=True, max_length=50, unique=True)),
                ("machine_name", models.CharField(max_length=200)),
                ("description", models.TextField(blank=True, default="")),
                ("manufacturer", models.CharField(blank=True, max_length=150, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "db_table": "machines_machine",
                "ordering": ["machine_code"],
                "indexes": [
                    models.Index(fields=["machine_code"], name="machines_ma_machine_code_idx"),
                    models.Index(fields=["machine_name"], name="machines_ma_machine_name_idx"),
                ],
            },
        ),
        migrations.RunPython(seed_initial_machines, migrations.RunPython.noop),
    ]

"""
Machine model representing industrial equipment supported by the assistant.
Initial Machines:
- HP200 — HP-200 Hydraulic Press
- AC90 — AC-90 Air Compressor
"""
from django.db import models


class Machine(models.Model):
    machine_code = models.CharField(max_length=50, unique=True, db_index=True)
    machine_name = models.CharField(max_length=200)
    description = models.TextField(blank=True, default="")
    manufacturer = models.CharField(max_length=150, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "machines_machine"
        ordering = ["machine_code"]
        indexes = [
            models.Index(fields=["machine_code"]),
            models.Index(fields=["machine_name"]),
        ]

    def __str__(self) -> str:
        return f"{self.machine_code} — {self.machine_name}"

"""
REST API Views for Industrial Machines (/api/machines/*).
"""
import logging
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.permissions import IsAdminOrReadOnlyForAuthenticated
from .models import Machine
from .serializers import MachineSerializer

logger = logging.getLogger(__name__)


class MachineListCreateAPIView(APIView):
    """
    GET /api/machines/ — List all industrial machines (Authenticated users)
    POST /api/machines/ — Register a new machine (Admin only)
    """

    permission_classes = [IsAdminOrReadOnlyForAuthenticated]

    def get(self, request):
        machines = Machine.objects.prefetch_related("manuals").all().order_by("machine_code")
        serializer = MachineSerializer(machines, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = MachineSerializer(data=request.data)
        if serializer.is_valid():
            machine = serializer.save()
            logger.info("Admin '%s' created machine '%s'.", request.user.username, machine.machine_code)
            return Response(MachineSerializer(machine).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class MachineDetailAPIView(APIView):
    """
    GET /api/machines/{id}/ — Retrieve machine details
    """

    permission_classes = [IsAdminOrReadOnlyForAuthenticated]

    def get(self, request, pk: int):
        machine = get_object_or_404(Machine, pk=pk)
        return Response(MachineSerializer(machine).data, status=status.HTTP_200_OK)

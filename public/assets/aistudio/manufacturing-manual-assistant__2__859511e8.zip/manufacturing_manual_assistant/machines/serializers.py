from rest_framework import serializers
from .models import Machine


class MachineSerializer(serializers.ModelSerializer):
    manual_count = serializers.IntegerField(source="manuals.count", read_only=True)
    completed_manual_count = serializers.SerializerMethodField()

    class Meta:
        model = Machine
        fields = [
            "id",
            "machine_code",
            "machine_name",
            "description",
            "manufacturer",
            "manual_count",
            "completed_manual_count",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "manual_count", "completed_manual_count", "created_at", "updated_at"]

    def get_completed_manual_count(self, obj: Machine) -> int:
        return obj.manuals.filter(processing_status="COMPLETED").count()

    def validate_machine_code(self, value: str) -> str:
        cleaned = value.strip().upper()
        if not cleaned:
            raise serializers.ValidationError("Machine code cannot be empty.")
        return cleaned

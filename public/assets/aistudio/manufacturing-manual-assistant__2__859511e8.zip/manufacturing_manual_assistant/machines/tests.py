from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient
from accounts.models import User
from .models import Machine


class MachineAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin, _ = User.objects.update_or_create(
            username="machine_admin",
            defaults={"email": "m_admin@factory.local", "role": User.Role.ADMIN},
        )
        self.engineer, _ = User.objects.update_or_create(
            username="machine_eng",
            defaults={"email": "m_eng@factory.local", "role": User.Role.ENGINEER},
        )

    def test_initial_machines_seeded_in_postgresql(self):
        codes = set(Machine.objects.values_list("machine_code", flat=True))
        self.assertIn("HP200", codes)
        self.assertIn("AC90", codes)

    def test_engineer_can_list_machines_but_cannot_create(self):
        self.client.force_authenticate(user=self.engineer)
        get_res = self.client.get("/api/machines/")
        self.assertEqual(get_res.status_code, status.HTTP_200_OK)

        post_res = self.client.post(
            "/api/machines/",
            {"machine_code": "CNC500", "machine_name": "CNC-500 Milling Center"},
            format="json",
        )
        self.assertEqual(post_res.status_code, status.HTTP_403_FORBIDDEN)

"""
REST API Views for AI Assistant (/api/assistant/*).
Endpoints:
- POST /api/assistant/ask/
- GET /api/assistant/history/
- GET /api/assistant/history/{id}/
"""
import logging
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from manuals.embedding import EmbeddingGenerationError
from manuals.vector_store import VectorStoreError
from .gemini_service import GeminiServiceError
from .models import QueryHistory
from .rag_pipeline import RAGPipeline
from .serializers import AskQuestionSerializer, QueryHistorySerializer

logger = logging.getLogger(__name__)


class AssistantAskAPIView(APIView):
    """POST /api/assistant/ask/ — Ask a machine-specific technical question."""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = AskQuestionSerializer(data=request.data, context={})
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        machine = serializer.context["machine_obj"]
        question = serializer.validated_data["question"]

        pipeline = RAGPipeline()
        try:
            result = pipeline.answer_question(
                user=request.user,
                machine=machine,
                question=question,
            )
            return Response(result, status=status.HTTP_200_OK)
        except ValueError as exc:
            return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        except (EmbeddingGenerationError, VectorStoreError, GeminiServiceError) as exc:
            logger.error("Assistant service error: %s", exc)
            return Response(
                {
                    "error": (
                        "The AI retrieval or generation service encountered an error while processing your request. "
                        "Please verify service connectivity and try again."
                    )
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )


class AssistantHistoryListAPIView(APIView):
    """
    GET /api/assistant/history/
    - Engineers view their own personal query history.
    - Admins and Supervisors can view all query history across users.
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        queryset = QueryHistory.objects.select_related("user", "machine").all()
        if request.user.role == "ENGINEER" and not request.user.is_superuser:
            queryset = queryset.filter(user=request.user)

        machine_param = request.query_params.get("machine_id")
        if machine_param:
            if str(machine_param).isdigit():
                queryset = queryset.filter(machine_id=int(machine_param))
            else:
                queryset = queryset.filter(machine__machine_code__iexact=str(machine_param).strip())

        confidence_param = request.query_params.get("confidence_status")
        if confidence_param:
            queryset = queryset.filter(confidence_status__iexact=str(confidence_param).strip())

        serializer = QueryHistorySerializer(queryset[:100], many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class AssistantHistoryDetailAPIView(APIView):
    """
    GET /api/assistant/history/{id}/
    - Engineers can only access their own query history items.
    - Admins and Supervisors can access any query history item.
    """

    permission_classes = [IsAuthenticated]

    def get(self, request, pk: int):
        item = get_object_or_404(QueryHistory.objects.select_related("user", "machine"), pk=pk)
        if request.user.role == "ENGINEER" and not request.user.is_superuser and item.user_id != request.user.id:
            return Response(
                {"detail": "Access denied: Engineers may only view their own query history."},
                status=status.HTTP_403_FORBIDDEN,
            )
        return Response(QueryHistorySerializer(item).data, status=status.HTTP_200_OK)

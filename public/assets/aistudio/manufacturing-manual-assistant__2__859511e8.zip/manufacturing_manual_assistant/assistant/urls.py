from django.urls import path
from .views import (
    AssistantAskAPIView,
    AssistantHistoryDetailAPIView,
    AssistantHistoryListAPIView,
)

urlpatterns = [
    path("ask/", AssistantAskAPIView.as_view(), name="api_assistant_ask"),
    path("history/", AssistantHistoryListAPIView.as_view(), name="api_assistant_history_list"),
    path("history/<int:pk>/", AssistantHistoryDetailAPIView.as_view(), name="api_assistant_history_detail"),
]

"""
Complete 16-Step RAG Question-Answering Pipeline.
Coordinates:
1. Question validation
2. Machine-isolated retrieval from ChromaDB
3. Independent post-retrieval machine & PostgreSQL citation validation
4. Insufficient-evidence refusal when no relevant evidence exists
5. Grounded answer generation via Gemini Flash
6. Refusal detection (clears citations if Gemini declares evidence insufficient)
7. Persistence to PostgreSQL QueryHistory
"""
import logging
from typing import Any, Dict

from machines.models import Machine
from manuals.embedding import EmbeddingGenerationError
from manuals.vector_store import VectorStoreError
from .citation_service import CitationService
from .gemini_service import GeminiGenerationService, GeminiServiceError
from .models import QueryHistory
from .prompts import INSUFFICIENT_EVIDENCE_MESSAGE
from .retrieval import MachineRetrievalService
from .safety_service import SafetyService

logger = logging.getLogger(__name__)


class RAGPipeline:
    def __init__(
        self,
        retrieval_service: MachineRetrievalService | None = None,
        gemini_service: GeminiGenerationService | None = None,
    ):
        self.retrieval_service = retrieval_service or MachineRetrievalService()
        self.gemini_service = gemini_service or GeminiGenerationService()

    def answer_question(
        self,
        *,
        user,
        machine: Machine,
        question: str,
    ) -> Dict[str, Any]:
        is_valid, cleaned_or_err = SafetyService.validate_question(question)
        if not is_valid:
            raise ValueError(cleaned_or_err)

        try:
            retrieved_chunks = self.retrieval_service.retrieve_for_machine(
                selected_machine=machine,
                question=cleaned_or_err,
            )
            validated_citations = CitationService.validate_and_build_citations(
                selected_machine=machine,
                retrieved_chunks=retrieved_chunks,
            )

            # Filter evidence chunks to only those whose citations passed PostgreSQL validation
            valid_keys = {
                (c["manual_id"], c["page_number"], c["chunk_index"])
                for c in validated_citations
            }
            verified_evidence = [
                ch
                for ch in retrieved_chunks
                if (
                    int(ch["metadata"].get("manual_id", 0) or 0),
                    int(ch["page_number"]),
                    int(ch["chunk_index"]),
                )
                in valid_keys
            ]

            if not verified_evidence:
                generated_answer = INSUFFICIENT_EVIDENCE_MESSAGE
                confidence_status = QueryHistory.ConfidenceStatus.INSUFFICIENT_EVIDENCE
                final_citations = []
            else:
                generated_answer = self.gemini_service.generate_grounded_answer(
                    machine_code=machine.machine_code,
                    machine_name=machine.machine_name,
                    question=cleaned_or_err,
                    evidence_chunks=verified_evidence,
                )
                lower_ans = generated_answer.lower()
                if (
                    INSUFFICIENT_EVIDENCE_MESSAGE.lower() in lower_ans
                    or "couldn't find sufficient supporting information" in lower_ans
                    or "do not contain enough information" in lower_ans
                ):
                    generated_answer = INSUFFICIENT_EVIDENCE_MESSAGE
                    confidence_status = QueryHistory.ConfidenceStatus.INSUFFICIENT_EVIDENCE
                    final_citations = []
                else:
                    confidence_status = QueryHistory.ConfidenceStatus.SUPPORTED
                    final_citations = validated_citations

        except (EmbeddingGenerationError, VectorStoreError, GeminiServiceError) as exc:
            logger.error("RAG service failure for machine '%s': %s", machine.machine_code, exc)
            raise

        query_record = QueryHistory.objects.create(
            user=user,
            machine=machine,
            question=cleaned_or_err,
            generated_answer=generated_answer,
            citations=final_citations,
            confidence_status=confidence_status,
        )

        return {
            "id": query_record.id,
            "machine_id": machine.machine_code,
            "machine_name": machine.machine_name,
            "question": query_record.question,
            "generated_answer": query_record.generated_answer,
            "citations": query_record.citations,
            "confidence_status": query_record.confidence_status,
            "created_at": query_record.created_at.isoformat(),
        }

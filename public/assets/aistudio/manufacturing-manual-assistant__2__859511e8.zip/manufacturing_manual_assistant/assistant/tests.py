"""
Comprehensive Automated Tests for the Core RAG Engine:
- TEST 1: Supported Question
- TEST 2: HP-200 Operations Retrieval
- TEST 3: HP-200 Maintenance Retrieval
- TEST 4: Machine Isolation (HP-200 vs AC-90 and reverse)
- TEST 5: Unsupported Question Refusal
- TEST 9: Citation Validation against PostgreSQL
- TEST 10: Query History Storage & Role Access Restrictions
- TEST 11: Gemini & ChromaDB API Failure Handling
"""
from unittest.mock import patch
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient

from accounts.models import User
from machines.models import Machine
from manuals.models import Manual, ManualChunk
from .gemini_service import GeminiServiceError
from .models import QueryHistory
from .prompts import INSUFFICIENT_EVIDENCE_MESSAGE


class AssistantRAGAndIsolationTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin, _ = User.objects.update_or_create(
            username="rag_admin",
            defaults={"email": "rag_admin@factory.local", "role": User.Role.ADMIN},
        )
        self.eng1, _ = User.objects.update_or_create(
            username="rag_eng1",
            defaults={"email": "rag_eng1@factory.local", "role": User.Role.ENGINEER},
        )
        self.eng2, _ = User.objects.update_or_create(
            username="rag_eng2",
            defaults={"email": "rag_eng2@factory.local", "role": User.Role.ENGINEER},
        )
        self.supervisor, _ = User.objects.update_or_create(
            username="rag_sup",
            defaults={"email": "rag_sup@factory.local", "role": User.Role.SUPERVISOR},
        )

        self.hp200 = Machine.objects.get(machine_code="HP200")
        self.ac90 = Machine.objects.get(machine_code="AC90")

        # Create completed manual records and chunks in PostgreSQL for test scenarios
        self.hp200_ops_manual = Manual.objects.create(
            machine=self.hp200,
            document_name="HP200_Operations_Rev1_0.pdf",
            original_filename="HP200_Operations_Rev1_0.pdf",
            revision="Rev1.0",
            file_path=SimpleUploadedFile("HP200_Operations_Rev1_0.pdf", b"%PDF-1.4 test"),
            total_pages=24,
            file_size=1024,
            processing_status=Manual.ProcessingStatus.COMPLETED,
            uploaded_by=self.admin,
        )
        self.hp200_maint_manual = Manual.objects.create(
            machine=self.hp200,
            document_name="HP200_Maintenance_Rev1_0.pdf",
            original_filename="HP200_Maintenance_Rev1_0.pdf",
            revision="Rev1.0",
            file_path=SimpleUploadedFile("HP200_Maintenance_Rev1_0.pdf", b"%PDF-1.4 test"),
            total_pages=30,
            file_size=1024,
            processing_status=Manual.ProcessingStatus.COMPLETED,
            uploaded_by=self.admin,
        )
        self.ac90_manual = Manual.objects.create(
            machine=self.ac90,
            document_name="AC90_Operations_Maintenance_Rev1_0.pdf",
            original_filename="AC90_Operations_Maintenance_Rev1_0.pdf",
            revision="Rev1.0",
            file_path=SimpleUploadedFile("AC90_Operations_Maintenance_Rev1_0.pdf", b"%PDF-1.4 test"),
            total_pages=40,
            file_size=1024,
            processing_status=Manual.ProcessingStatus.COMPLETED,
            uploaded_by=self.admin,
        )

        ManualChunk.objects.create(
            manual=self.hp200_ops_manual,
            machine=self.hp200,
            chunk_text="HP-200 nominal hydraulic system working pressure is 210 bar (3045 PSI).",
            page_number=12,
            chunk_index=5,
            embedding_reference="hp200_ops_p12_c5",
            metadata={
                "machine_id": "HP200",
                "manual_id": str(self.hp200_ops_manual.id),
                "document_name": "HP200_Operations_Rev1_0.pdf",
                "revision": "Rev1.0",
                "page_number": 12,
                "chunk_index": 5,
            },
        )
        ManualChunk.objects.create(
            manual=self.hp200_maint_manual,
            machine=self.hp200,
            chunk_text="Replace high-pressure return filter element every 500 operating hours using ISO VG 46 oil.",
            page_number=18,
            chunk_index=3,
            embedding_reference="hp200_maint_p18_c3",
            metadata={
                "machine_id": "HP200",
                "manual_id": str(self.hp200_maint_manual.id),
                "document_name": "HP200_Maintenance_Rev1_0.pdf",
                "revision": "Rev1.0",
                "page_number": 18,
                "chunk_index": 3,
            },
        )
        ManualChunk.objects.create(
            manual=self.ac90_manual,
            machine=self.ac90,
            chunk_text="AC-90 rotary screw discharge pressure is rated at 8.5 bar with thermal shutdown at 105 C.",
            page_number=9,
            chunk_index=2,
            embedding_reference="ac90_p9_c2",
            metadata={
                "machine_id": "AC90",
                "manual_id": str(self.ac90_manual.id),
                "document_name": "AC90_Operations_Maintenance_Rev1_0.pdf",
                "revision": "Rev1.0",
                "page_number": 9,
                "chunk_index": 2,
            },
        )

    @patch("assistant.retrieval.GeminiEmbeddingService.embed_query")
    @patch("assistant.retrieval.ChromaVectorStore.query_by_machine")
    @patch("assistant.rag_pipeline.GeminiGenerationService.generate_grounded_answer")
    def test_01_and_02_supported_hp200_operations_question(
        self, mock_generate, mock_chroma_query, mock_embed_query
    ):
        """TEST 1 & TEST 2 — Supported HP-200 operational question returns grounded answer & page-level citation."""
        mock_embed_query.return_value = [0.1, 0.2, 0.3]
        mock_chroma_query.return_value = [
            {
                "chunk_id": "hp200_ops_p12_c5",
                "chunk_text": "HP-200 nominal hydraulic system working pressure is 210 bar (3045 PSI).",
                "metadata": {
                    "machine_id": "HP200",
                    "manual_id": str(self.hp200_ops_manual.id),
                    "document_name": "HP200_Operations_Rev1_0.pdf",
                    "revision": "Rev1.0",
                    "page_number": 12,
                    "chunk_index": 5,
                },
                "distance": 0.12,
                "similarity": 0.88,
            }
        ]
        mock_generate.return_value = (
            "1. Direct Answer\nThe nominal hydraulic working pressure of the HP-200 is 210 bar (3045 PSI).\n"
            "Source: HP200_Operations_Rev1_0.pdf, Revision: Rev1.0, Page: 12"
        )

        self.client.force_authenticate(user=self.eng1)
        response = self.client.post(
            "/api/assistant/ask/",
            {"machine_id": "HP200", "question": "What is the nominal working pressure of the HP-200?"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data["confidence_status"], "SUPPORTED")
        self.assertEqual(len(data["citations"]), 1)
        self.assertEqual(data["citations"][0]["document_name"], "HP200_Operations_Rev1_0.pdf")
        self.assertEqual(data["citations"][0]["revision"], "Rev1.0")
        self.assertEqual(data["citations"][0]["page_number"], 12)
        self.assertEqual(data["citations"][0]["machine_id"], "HP200")

    @patch("assistant.retrieval.GeminiEmbeddingService.embed_query")
    @patch("assistant.retrieval.ChromaVectorStore.query_by_machine")
    @patch("assistant.rag_pipeline.GeminiGenerationService.generate_grounded_answer")
    def test_03_hp200_maintenance_question(self, mock_generate, mock_chroma_query, mock_embed_query):
        """TEST 3 — HP-200 maintenance question retrieves from HP200_Maintenance_Rev1_0.pdf with valid citation."""
        mock_embed_query.return_value = [0.2, 0.3, 0.4]
        mock_chroma_query.return_value = [
            {
                "chunk_id": "hp200_maint_p18_c3",
                "chunk_text": "Replace high-pressure return filter element every 500 operating hours using ISO VG 46 oil.",
                "metadata": {
                    "machine_id": "HP200",
                    "manual_id": str(self.hp200_maint_manual.id),
                    "document_name": "HP200_Maintenance_Rev1_0.pdf",
                    "revision": "Rev1.0",
                    "page_number": 18,
                    "chunk_index": 3,
                },
                "distance": 0.15,
                "similarity": 0.85,
            }
        ]
        mock_generate.return_value = (
            "Replace the high-pressure return filter element every 500 operating hours."
        )

        self.client.force_authenticate(user=self.eng1)
        response = self.client.post(
            "/api/assistant/ask/",
            {"machine_id": "HP200", "question": "How often should the return filter element be replaced?"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data["citations"][0]["document_name"], "HP200_Maintenance_Rev1_0.pdf")
        self.assertEqual(data["citations"][0]["page_number"], 18)

    @patch("assistant.retrieval.GeminiEmbeddingService.embed_query")
    @patch("assistant.retrieval.ChromaVectorStore.query_by_machine")
    @patch("assistant.rag_pipeline.GeminiGenerationService.generate_grounded_answer")
    def test_04_strict_machine_isolation_both_directions(
        self, mock_generate, mock_chroma_query, mock_embed_query
    ):
        """
        TEST 4 — Even if a vector store returned a mismatched AC90 chunk during an HP200 query (or vice versa),
        independent post-retrieval validation and CitationService block it before reaching Gemini.
        """
        mock_embed_query.return_value = [0.3, 0.1, 0.2]
        # Simulate a rogue AC90 chunk returned when HP200 was selected
        mock_chroma_query.return_value = [
            {
                "chunk_id": "ac90_p9_c2",
                "chunk_text": "AC-90 rotary screw discharge pressure is rated at 8.5 bar.",
                "metadata": {
                    "machine_id": "AC90",
                    "manual_id": str(self.ac90_manual.id),
                    "document_name": "AC90_Operations_Maintenance_Rev1_0.pdf",
                    "revision": "Rev1.0",
                    "page_number": 9,
                    "chunk_index": 2,
                },
                "distance": 0.10,
                "similarity": 0.90,
            }
        ]

        self.client.force_authenticate(user=self.eng1)
        res_hp200 = self.client.post(
            "/api/assistant/ask/",
            {"machine_id": "HP200", "question": "What is the rotary screw discharge pressure of AC-90?"},
            format="json",
        )
        self.assertEqual(res_hp200.status_code, status.HTTP_200_OK)
        body_hp200 = res_hp200.json()
        self.assertEqual(body_hp200["confidence_status"], "INSUFFICIENT_EVIDENCE")
        self.assertEqual(body_hp200["generated_answer"], INSUFFICIENT_EVIDENCE_MESSAGE)
        self.assertEqual(body_hp200["citations"], [])
        mock_generate.assert_not_called()

        # Reverse direction: Select AC90 and simulate rogue HP200 chunk
        mock_chroma_query.return_value = [
            {
                "chunk_id": "hp200_ops_p12_c5",
                "chunk_text": "HP-200 nominal hydraulic system working pressure is 210 bar.",
                "metadata": {
                    "machine_id": "HP200",
                    "manual_id": str(self.hp200_ops_manual.id),
                    "document_name": "HP200_Operations_Rev1_0.pdf",
                    "revision": "Rev1.0",
                    "page_number": 12,
                    "chunk_index": 5,
                },
                "distance": 0.10,
                "similarity": 0.90,
            }
        ]
        res_ac90 = self.client.post(
            "/api/assistant/ask/",
            {"machine_id": "AC90", "question": "What is the hydraulic ram tonnage on HP-200?"},
            format="json",
        )
        self.assertEqual(res_ac90.status_code, status.HTTP_200_OK)
        body_ac90 = res_ac90.json()
        self.assertEqual(body_ac90["confidence_status"], "INSUFFICIENT_EVIDENCE")
        self.assertEqual(body_ac90["generated_answer"], INSUFFICIENT_EVIDENCE_MESSAGE)
        self.assertEqual(body_ac90["citations"], [])

    @patch("assistant.retrieval.GeminiEmbeddingService.embed_query")
    @patch("assistant.retrieval.ChromaVectorStore.query_by_machine")
    def test_05_and_09_unsupported_question_and_invalid_page_citation_rejection(
        self, mock_chroma_query, mock_embed_query
    ):
        """TEST 5 & TEST 9 — Unsupported questions and fabricated page numbers produce refusal with 0 citations."""
        mock_embed_query.return_value = [0.05, 0.05, 0.05]
        # Chunk with out-of-bounds page number (page 999 > total_pages 24) must be rejected by CitationService
        mock_chroma_query.return_value = [
            {
                "chunk_id": "fake_page_chunk",
                "chunk_text": "Some unrelated text",
                "metadata": {
                    "machine_id": "HP200",
                    "manual_id": str(self.hp200_ops_manual.id),
                    "document_name": "HP200_Operations_Rev1_0.pdf",
                    "revision": "Rev1.0",
                    "page_number": 999,
                    "chunk_index": 99,
                },
                "distance": 0.2,
                "similarity": 0.80,
            }
        ]
        self.client.force_authenticate(user=self.eng1)
        res = self.client.post(
            "/api/assistant/ask/",
            {"machine_id": "HP200", "question": "Does the HP-200 support Wi-Fi Bluetooth audio streaming?"},
            format="json",
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        data = res.json()
        self.assertEqual(data["generated_answer"], INSUFFICIENT_EVIDENCE_MESSAGE)
        self.assertEqual(data["citations"], [])

    def test_10_query_history_access_isolation(self):
        """TEST 10 — Engineers see only their own query history; Supervisors & Admins see all."""
        q1 = QueryHistory.objects.create(
            user=self.eng1,
            machine=self.hp200,
            question="Eng1 question?",
            generated_answer="Eng1 answer",
            citations=[],
            confidence_status="SUPPORTED",
        )
        q2 = QueryHistory.objects.create(
            user=self.eng2,
            machine=self.ac90,
            question="Eng2 question?",
            generated_answer="Eng2 answer",
            citations=[],
            confidence_status="SUPPORTED",
        )

        self.client.force_authenticate(user=self.eng1)
        list_res = self.client.get("/api/assistant/history/")
        self.assertEqual(list_res.status_code, status.HTTP_200_OK)
        ids = [item["id"] for item in list_res.json()]
        self.assertIn(q1.id, ids)
        self.assertNotIn(q2.id, ids)

        # Eng1 cannot fetch Eng2's specific history detail
        forbidden_detail = self.client.get(f"/api/assistant/history/{q2.id}/")
        self.assertEqual(forbidden_detail.status_code, status.HTTP_403_FORBIDDEN)

        # Supervisor can view both
        self.client.force_authenticate(user=self.supervisor)
        sup_res = self.client.get("/api/assistant/history/")
        sup_ids = [item["id"] for item in sup_res.json()]
        self.assertIn(q1.id, sup_ids)
        self.assertIn(q2.id, sup_ids)

    @patch("assistant.retrieval.GeminiEmbeddingService.embed_query")
    @patch("assistant.retrieval.ChromaVectorStore.query_by_machine")
    @patch("assistant.rag_pipeline.GeminiGenerationService.generate_grounded_answer")
    def test_11_api_failure_graceful_handling(self, mock_generate, mock_chroma_query, mock_embed_query):
        """TEST 11 — Simulated Gemini failure returns HTTP 503 graceful error without misleading answer."""
        mock_embed_query.return_value = [0.1, 0.2, 0.3]
        mock_chroma_query.return_value = [
            {
                "chunk_id": "hp200_ops_p12_c5",
                "chunk_text": "HP-200 nominal hydraulic system working pressure is 210 bar.",
                "metadata": {
                    "machine_id": "HP200",
                    "manual_id": str(self.hp200_ops_manual.id),
                    "document_name": "HP200_Operations_Rev1_0.pdf",
                    "revision": "Rev1.0",
                    "page_number": 12,
                    "chunk_index": 5,
                },
                "distance": 0.1,
                "similarity": 0.9,
            }
        ]
        mock_generate.side_effect = GeminiServiceError("Simulated upstream Gemini API timeout")

        self.client.force_authenticate(user=self.eng1)
        res = self.client.post(
            "/api/assistant/ask/",
            {"machine_id": "HP200", "question": "What is the working pressure?"},
            format="json",
        )
        self.assertEqual(res.status_code, status.HTTP_503_SERVICE_UNAVAILABLE)
        self.assertIn("error", res.json())

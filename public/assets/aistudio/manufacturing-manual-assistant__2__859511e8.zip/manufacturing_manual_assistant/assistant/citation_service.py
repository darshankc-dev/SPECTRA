"""
Dedicated Citation & Evidence Validation Service.
Validates every retrieved chunk against PostgreSQL Manual and ManualChunk records.
Guarantees:
- Citations originate strictly from retrieved chunks belonging to the selected machine.
- Document name, revision, and 1-indexed page number match PostgreSQL records.
- No fabricated page numbers or cross-machine manuals can ever be cited.
"""
import logging
from typing import Any, Dict, List

from machines.models import Machine
from manuals.models import Manual, ManualChunk

logger = logging.getLogger(__name__)


class CitationService:
    @staticmethod
    def validate_and_build_citations(
        *,
        selected_machine: Machine,
        retrieved_chunks: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Cross-checks retrieved vector chunks against PostgreSQL Manual and ManualChunk records
        for the selected machine and returns structured, clickable citation dictionaries.
        """
        validated_citations: List[Dict[str, Any]] = []
        seen_keys = set()

        for item in retrieved_chunks:
            meta = item.get("metadata") or {}
            chunk_machine_code = str(meta.get("machine_id", "")).strip().upper()

            # Independent Machine Isolation Check #2: Reject any mismatch with selected_machine
            if chunk_machine_code != selected_machine.machine_code.upper():
                logger.error(
                    "CRITICAL ISOLATION BLOCK in CitationService: Rejected chunk for machine '%s' while querying '%s'.",
                    chunk_machine_code,
                    selected_machine.machine_code,
                )
                continue

            raw_manual_id = meta.get("manual_id")
            page_number = int(meta.get("page_number", 0) or 0)
            chunk_index = int(meta.get("chunk_index", -1))

            if not raw_manual_id or page_number < 1:
                continue

            try:
                manual_id_int = int(raw_manual_id)
            except (TypeError, ValueError):
                continue

            # Verify against PostgreSQL Manual table with strict machine ownership
            manual = Manual.objects.filter(
                pk=manual_id_int,
                machine=selected_machine,
                processing_status=Manual.ProcessingStatus.COMPLETED,
            ).first()

            if manual is None:
                logger.warning(
                    "Rejected citation for manual_id=%s: not found or does not belong to machine %s.",
                    manual_id_int,
                    selected_machine.machine_code,
                )
                continue

            if page_number > manual.total_pages and manual.total_pages > 0:
                logger.warning(
                    "Rejected citation with out-of-range page %d for manual '%s' (total_pages=%d).",
                    page_number,
                    manual.document_name,
                    manual.total_pages,
                )
                continue

            # Verify chunk existence in PostgreSQL ManualChunk table if available
            db_chunk = ManualChunk.objects.filter(
                manual=manual,
                machine=selected_machine,
                page_number=page_number,
                chunk_index=chunk_index,
            ).first()

            supporting_text = db_chunk.chunk_text if db_chunk else item.get("chunk_text", "")
            dedup_key = (manual.id, page_number, chunk_index)
            if dedup_key in seen_keys:
                continue
            seen_keys.add(dedup_key)

            validated_citations.append(
                {
                    "manual_id": manual.id,
                    "machine_id": selected_machine.machine_code,
                    "document_name": manual.document_name,
                    "revision": manual.revision,
                    "page_number": page_number,
                    "chunk_index": chunk_index,
                    "supporting_text": supporting_text,
                    "similarity": round(float(item.get("similarity", 0.0)), 4),
                    "pdf_url": f"/api/manuals/{manual.id}/file/?machine_id={selected_machine.machine_code}#page={page_number}",
                }
            )

        return validated_citations

"""
Dedicated Gemini Flash Answer Generation Service.
Uses configurable GEMINI_FLASH_MODEL (default: gemini-3.8-flash).
Enforces the mandatory industrial documentation System Prompt.
"""
import logging
import os
from typing import Any, Dict, List

from .prompts import (
    GEMINI_SYSTEM_PROMPT,
    INSUFFICIENT_EVIDENCE_MESSAGE,
    build_grounded_user_prompt,
)

logger = logging.getLogger(__name__)


class GeminiServiceError(Exception):
    """Raised when Gemini answer generation fails."""


class GeminiGenerationService:
    def __init__(self, api_key: str | None = None, model_name: str | None = None):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        self.model_name = model_name or os.environ.get("GEMINI_FLASH_MODEL", "gemini-3.8-flash")

    def generate_grounded_answer(
        self,
        *,
        machine_code: str,
        machine_name: str,
        question: str,
        evidence_chunks: List[Dict[str, Any]],
    ) -> str:
        if not evidence_chunks:
            return INSUFFICIENT_EVIDENCE_MESSAGE

        if not self.api_key:
            raise GeminiServiceError("GEMINI_API_KEY environment variable is not configured.")

        try:
            from google import genai
            from google.genai import types
        except ImportError as exc:
            raise GeminiServiceError("google-genai SDK is required for Gemini answer generation.") from exc

        user_prompt = build_grounded_user_prompt(
            machine_code=machine_code,
            machine_name=machine_name,
            question=question,
            evidence_chunks=evidence_chunks,
        )

        try:
            client = genai.Client(api_key=self.api_key)
            response = client.models.generate_content(
                model=self.model_name,
                contents=user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=GEMINI_SYSTEM_PROMPT,
                ),
            )
            answer_text = (getattr(response, "text", None) or "").strip()
            if not answer_text:
                return INSUFFICIENT_EVIDENCE_MESSAGE
            return answer_text
        except Exception as exc:
            logger.error("Gemini Flash generation failed for machine '%s': %s", machine_code, exc)
            raise GeminiServiceError(f"Gemini generation failed: {exc}") from exc

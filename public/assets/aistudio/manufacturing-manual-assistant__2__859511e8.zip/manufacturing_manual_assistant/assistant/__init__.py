"""Assistant app."""

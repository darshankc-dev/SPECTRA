"""Assistant migrations."""

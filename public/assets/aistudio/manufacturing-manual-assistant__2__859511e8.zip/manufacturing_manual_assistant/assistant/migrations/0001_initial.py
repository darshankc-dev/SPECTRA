from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("machines", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="QueryHistory",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("question", models.TextField()),
                ("generated_answer", models.TextField()),
                ("citations", models.JSONField(default=list)),
                (
                    "confidence_status",
                    models.CharField(
                        choices=[
                            ("SUPPORTED", "Supported by Official Manual Evidence"),
                            ("INSUFFICIENT_EVIDENCE", "Insufficient Supporting Evidence"),
                            ("AMBIGUOUS", "Clarification Requested"),
                            ("ERROR", "System / Service Error"),
                        ],
                        db_index=True,
                        default="SUPPORTED",
                        max_length=32,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                (
                    "machine",
                    models.ForeignKey(
                        db_column="machine_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="queries",
                        to="machines.machine",
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        db_column="user_id",
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="queries",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "db_table": "assistant_queryhistory",
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["user", "-created_at"], name="assistant_q_user_created_idx"),
                    models.Index(fields=["machine", "-created_at"], name="assistant_q_mach_created_idx"),
                    models.Index(fields=["confidence_status", "-created_at"], name="assistant_q_conf_created_idx"),
                ],
            },
        ),
    ]

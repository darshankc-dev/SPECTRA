"""
Machine-Specific Retrieval Engine.
Enforces:
1. ChromaDB metadata filter `where={"machine_id": selected_machine.machine_code}`
2. Independent post-retrieval machine_id validation against selected_machine
3. Configurable similarity threshold filtering
4. Deduplication of overlapping or repeated passages
5. Prompt-injection sanitization of retrieved PDF chunks
"""
import logging
from typing import Any, Dict, List
from django.conf import settings

from machines.models import Machine
from manuals.embedding import GeminiEmbeddingService
from manuals.models import Manual
from manuals.vector_store import ChromaVectorStore
from .safety_service import SafetyService

logger = logging.getLogger(__name__)


class MachineRetrievalService:
    def __init__(
        self,
        embedding_service: GeminiEmbeddingService | None = None,
        vector_store: ChromaVectorStore | None = None,
        top_k: int | None = None,
        similarity_threshold: float | None = None,
    ):
        self.embedding_service = embedding_service or GeminiEmbeddingService()
        self.vector_store = vector_store or ChromaVectorStore(
            persist_directory=getattr(settings, "CHROMA_PERSIST_DIRECTORY", "./vector_store")
        )
        self.top_k = top_k if top_k is not None else getattr(settings, "RAG_TOP_K", 5)
        self.similarity_threshold = (
            similarity_threshold
            if similarity_threshold is not None
            else getattr(settings, "RAG_SIMILARITY_THRESHOLD", 0.32)
        )

    def retrieve_for_machine(
        self,
        *,
        selected_machine: Machine,
        question: str,
    ) -> List[Dict[str, Any]]:
        target_code = selected_machine.machine_code.strip().upper()

        # Check if the selected machine has at least one COMPLETED manual in PostgreSQL
        completed_manuals_exist = Manual.objects.filter(
            machine=selected_machine,
            processing_status=Manual.ProcessingStatus.COMPLETED,
        ).exists()
        if not completed_manuals_exist:
            logger.info("No completed manuals indexed yet for machine '%s'.", target_code)
            return []

        query_embedding = self.embedding_service.embed_query(question)
        raw_matches = self.vector_store.query_by_machine(
            query_embedding=query_embedding,
            machine_code=target_code,
            top_k=self.top_k * 2,
        )

        validated_chunks: List[Dict[str, Any]] = []
        seen_texts = set()

        for match in raw_matches:
            meta = match.get("metadata") or {}
            returned_machine_code = str(meta.get("machine_id", "")).strip().upper()

            # INDEPENDENT POST-RETRIEVAL MACHINE ISOLATION CHECK
            if returned_machine_code != target_code:
                logger.error(
                    "SECURITY ISOLATION BLOCK: ChromaDB returned chunk with machine_id='%s' for '%s' query. Dropped.",
                    returned_machine_code,
                    target_code,
                )
                continue

            similarity = float(match.get("similarity", 0.0))
            if similarity < self.similarity_threshold:
                continue

            raw_text = (match.get("chunk_text") or "").strip()
            if not raw_text:
                continue

            normalized_key = " ".join(raw_text.lower().split())
            if normalized_key in seen_texts:
                continue
            seen_texts.add(normalized_key)

            sanitized_text = SafetyService.sanitize_untrusted_pdf_chunk(raw_text)
            validated_chunks.append(
                {
                    "chunk_id": match.get("chunk_id"),
                    "chunk_text": sanitized_text,
                    "metadata": meta,
                    "document_name": str(meta.get("document_name", "")),
                    "revision": str(meta.get("revision", "Rev1.0")),
                    "page_number": int(meta.get("page_number", 1)),
                    "chunk_index": int(meta.get("chunk_index", 0)),
                    "similarity": similarity,
                }
            )
            if len(validated_chunks) >= self.top_k:
                break

        logger.info(
            "Retrieved %d validated evidence chunks for machine '%s'.",
            len(validated_chunks),
            target_code,
        )
        return validated_chunks

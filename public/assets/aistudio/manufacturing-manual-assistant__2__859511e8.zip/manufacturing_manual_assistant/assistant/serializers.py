from rest_framework import serializers
from machines.models import Machine
from .models import QueryHistory


class AskQuestionSerializer(serializers.Serializer):
    machine_id = serializers.CharField(
        required=True,
        help_text="Selected machine code (e.g. HP200 or AC90) or database ID.",
    )
    question = serializers.CharField(required=True, min_length=3, max_length=2000)

    def validate_machine_id(self, value: str):
        cleaned = str(value).strip()
        machine = None
        if cleaned.isdigit():
            machine = Machine.objects.filter(pk=int(cleaned)).first()
        if machine is None:
            machine = Machine.objects.filter(machine_code__iexact=cleaned).first()
        if machine is None:
            raise serializers.ValidationError(f"Selected machine '{cleaned}' is not registered.")
        self.context["machine_obj"] = machine
        return cleaned


class QueryHistorySerializer(serializers.ModelSerializer):
    username = serializers.CharField(source="user.username", read_only=True)
    user_role = serializers.CharField(source="user.role", read_only=True)
    machine_code = serializers.CharField(source="machine.machine_code", read_only=True)
    machine_name = serializers.CharField(source="machine.machine_name", read_only=True)

    class Meta:
        model = QueryHistory
        fields = [
            "id",
            "user",
            "username",
            "user_role",
            "machine",
            "machine_code",
            "machine_name",
            "question",
            "generated_answer",
            "citations",
            "confidence_status",
            "created_at",
        ]
        read_only_fields = fields

"""
Safety & Prompt-Injection Defense Service.
Treats all PDF text as untrusted data and sanitizes embedded override instructions.
Also validates user questions before embedding.
"""
import re
from typing import Tuple


class SafetyService:
    INJECTION_PATTERNS = [
        re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior|above|system)\s+instructions", re.IGNORECASE),
        re.compile(r"disregard\s+(?:all\s+)?(?:previous|prior|system)\s+rules", re.IGNORECASE),
        re.compile(r"you\s+are\s+now\s+(?:an?\s+)?unrestricted", re.IGNORECASE),
        re.compile(r"system\s*prompt\s*override", re.IGNORECASE),
        re.compile(r"<\s*/?\s*system\s*>", re.IGNORECASE),
    ]

    @classmethod
    def sanitize_untrusted_pdf_chunk(cls, chunk_text: str) -> str:
        """Neutralizes prompt-injection directives embedded inside untrusted PDF manuals."""
        if not chunk_text:
            return ""
        sanitized = chunk_text
        for pattern in cls.INJECTION_PATTERNS:
            sanitized = pattern.sub("[REDACTED_UNTRUSTED_DIRECTIVE]", sanitized)
        return sanitized

    @classmethod
    def validate_question(cls, question: str) -> Tuple[bool, str]:
        cleaned = (question or "").strip()
        if not cleaned:
            return False, "Please enter a technical question."
        if len(cleaned) < 3:
            return False, "Question is too short. Please provide more technical detail."
        if len(cleaned) > 2000:
            return False, "Question exceeds maximum allowed length of 2,000 characters."
        return True, cleaned

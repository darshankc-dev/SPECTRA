"""
QueryHistory model storing every engineer question, grounded answer,
validated citations, and confidence status in PostgreSQL.
"""
from django.conf import settings
from django.db import models
from machines.models import Machine


class QueryHistory(models.Model):
    class ConfidenceStatus(models.TextChoices):
        SUPPORTED = "SUPPORTED", "Supported by Official Manual Evidence"
        INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE", "Insufficient Supporting Evidence"
        AMBIGUOUS = "AMBIGUOUS", "Clarification Requested"
        ERROR = "ERROR", "System / Service Error"

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="queries",
        db_column="user_id",
    )
    machine = models.ForeignKey(
        Machine,
        on_delete=models.CASCADE,
        related_name="queries",
        db_column="machine_id",
    )
    question = models.TextField()
    generated_answer = models.TextField()
    citations = models.JSONField(default=list)
    confidence_status = models.CharField(
        max_length=32,
        choices=ConfidenceStatus.choices,
        default=ConfidenceStatus.SUPPORTED,
        db_index=True,
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table = "assistant_queryhistory"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["user", "-created_at"]),
            models.Index(fields=["machine", "-created_at"]),
            models.Index(fields=["confidence_status", "-created_at"]),
        ]

    def __str__(self) -> str:
        return f"[{self.machine.machine_code}] {self.user.username}: {self.question[:50]}"

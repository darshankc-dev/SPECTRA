-- =============================================================================
-- MANUFACTURING MANUAL ASSISTANT — LOCAL POSTGRESQL DATABASE SETUP
-- Run this in psql or pgAdmin on your local PostgreSQL server before migrating:
--   psql -U postgres -f sql/create_database.sql
-- =============================================================================

SELECT 'CREATE DATABASE manufacturing_manual_assistant ENCODING ''UTF8'''
WHERE NOT EXISTS (
    SELECT FROM pg_database WHERE datname = 'manufacturing_manual_assistant'
)\gexec

-- Connect to the database and verify UTF-8 encoding
\c manufacturing_manual_assistant
SELECT current_database() AS active_database, current_user AS connected_user, version() AS postgres_version;

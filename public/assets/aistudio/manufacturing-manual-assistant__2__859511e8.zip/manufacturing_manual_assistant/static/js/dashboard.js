// Dashboard interactive helpers
document.addEventListener("DOMContentLoaded", () => {
  // Dashboard metrics rendered server-side from PostgreSQL
});

function getCSRFToken() {
  const cookieValue = document.cookie
    .split("; ")
    .find((row) => row.startsWith("csrftoken="));
  return cookieValue ? decodeURIComponent(cookieValue.split("=")[1]) : "";
}
window.getCSRFToken = getCSRFToken;

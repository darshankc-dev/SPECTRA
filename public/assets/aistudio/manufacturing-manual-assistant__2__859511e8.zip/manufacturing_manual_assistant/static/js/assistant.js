document.addEventListener("DOMContentLoaded", () => {
  const askForm = document.getElementById("askForm");
  const questionInput = document.getElementById("questionInput");
  const machineSelect = document.getElementById("machineSelect");
  const chatMessages = document.getElementById("chatMessages");
  const clearChatBtn = document.getElementById("clearChatBtn");
  const sendBtn = document.getElementById("sendBtn");

  if (!askForm) return;

  clearChatBtn?.addEventListener("click", () => {
    chatMessages.innerHTML = `<div class="text-muted small">Conversation cleared. Active machine context: <strong>${machineSelect.value}</strong>.</div>`;
  });

  machineSelect?.addEventListener("change", () => {
    const notice = document.createElement("div");
    notice.className = "text-secondary small border-top pt-2";
    notice.textContent = `Switched strict retrieval filter to machine: ${machineSelect.value}`;
    chatMessages.appendChild(notice);
  });

  askForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const question = questionInput.value.trim();
    const machineId = machineSelect.value;
    if (!question) return;

    const userBubble = document.createElement("div");
    userBubble.className = "p-3 rounded bg-light border align-self-end w-75";
    userBubble.innerHTML = `<div class="small text-secondary mb-1">Engineer · Machine: ${machineId}</div><div></div>`;
    userBubble.lastChild.textContent = question;
    chatMessages.appendChild(userBubble);

    questionInput.value = "";
    sendBtn.disabled = true;
    sendBtn.textContent = "Retrieving Evidence...";

    try {
      const response = await fetch("/api/assistant/ask/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": window.getCSRFToken(),
        },
        body: JSON.stringify({ machine_id: machineId, question }),
      });
      const data = await response.json();
      const botCard = document.createElement("div");
      botCard.className = "p-3 rounded border bg-white";

      if (!response.ok) {
        botCard.innerHTML = `<div class="text-danger fw-semibold">Error</div><div class="small">${data.error || "Failed to process question."}</div>`;
      } else {
        let citationsHtml = "";
        if (Array.isArray(data.citations) && data.citations.length > 0) {
          const items = data.citations
            .map(
              (c) => `
              <div class="citation-card mt-2">
                <div class="small fw-semibold">Source: ${c.document_name} · Revision: ${c.revision} · Page: ${c.page_number}</div>
                <div class="mt-1">
                  <a href="${c.pdf_url}" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary py-0 px-2">View source (Page ${c.page_number})</a>
                </div>
                <details class="mt-2 small text-muted">
                  <summary>Expand supporting passage</summary>
                  <pre class="mt-1 mb-0 small text-wrap">${c.supporting_text}</pre>
                </details>
              </div>`
            )
            .join("");
          citationsHtml = `<div class="mt-3 pt-2 border-top"><div class="small fw-bold text-secondary">SOURCES</div>${items}</div>`;
        }
        botCard.innerHTML = `
          <div class="small text-secondary mb-1">ANSWER (${data.machine_id} · ${data.confidence_status})</div>
          <div style="white-space: pre-wrap;">${data.generated_answer}</div>
          ${citationsHtml}
        `;
      }
      chatMessages.appendChild(botCard);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    } catch (err) {
      console.error(err);
    } finally {
      sendBtn.disabled = false;
      sendBtn.textContent = "Ask Assistant";
    }
  });
});

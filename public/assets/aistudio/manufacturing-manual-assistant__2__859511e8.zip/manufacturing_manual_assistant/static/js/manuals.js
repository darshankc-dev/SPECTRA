document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("manualUploadForm");
  const alertBox = document.getElementById("uploadStatusAlert");

  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      alertBox.className = "mt-3 alert alert-info small";
      alertBox.textContent = "Uploading PDF, extracting pages with PyMuPDF, generating Gemini embeddings, and indexing in ChromaDB...";

      try {
        const res = await fetch("/api/manuals/upload/", {
          method: "POST",
          headers: { "X-CSRFToken": window.getCSRFToken() },
          body: formData,
        });
        const data = await res.json();
        if (res.ok) {
          alertBox.className = "mt-3 alert alert-success small";
          alertBox.textContent = `Successfully indexed ${data.document_name} (${data.total_pages} pages). Reloading...`;
          setTimeout(() => window.location.reload(), 900);
        } else {
          alertBox.className = "mt-3 alert alert-danger small";
          alertBox.textContent = JSON.stringify(data);
        }
      } catch (err) {
        alertBox.className = "mt-3 alert alert-danger small";
        alertBox.textContent = String(err);
      }
    });
  }

  document.querySelectorAll(".reprocess-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-id");
      btn.disabled = true;
      btn.textContent = "Reprocessing...";
      await fetch(`/api/manuals/${id}/reprocess/`, {
        method: "POST",
        headers: { "X-CSRFToken": window.getCSRFToken() },
      });
      window.location.reload();
    });
  });

  document.querySelectorAll(".delete-manual-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-id");
      await fetch(`/api/manuals/${id}/`, {
        method: "DELETE",
        headers: { "X-CSRFToken": window.getCSRFToken() },
      });
      window.location.reload();
    });
  });
});

"""
Serializers for Authentication and User Management.
Supports user registration for ADMIN, SUPERVISOR, and ENGINEER roles and role-verified login.
"""
from django.contrib.auth import authenticate
from rest_framework import serializers
from .models import User


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, min_length=6)
    role = serializers.ChoiceField(choices=User.Role.choices, default=User.Role.ENGINEER)

    class Meta:
        model = User
        fields = ["id", "username", "email", "password", "role"]
        read_only_fields = ["id"]

    def validate_username(self, value: str) -> str:
        cleaned = value.strip()
        if User.objects.filter(username__iexact=cleaned).exists():
            raise serializers.ValidationError(f"Username '{cleaned}' is already registered.")
        return cleaned

    def validate_email(self, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise serializers.ValidationError("A valid email address is required.")
        if User.objects.filter(email__iexact=cleaned).exists():
            raise serializers.ValidationError(f"Email '{cleaned}' is already registered.")
        return cleaned

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.is_active = True
        user.set_password(password)
        user.save()
        return user


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(required=True, max_length=150)
    password = serializers.CharField(required=True, write_only=True, style={"input_type": "password"})
    role = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        username_or_email = attrs.get("username", "").strip()
        password = attrs.get("password", "")
        requested_role = (attrs.get("role") or "").strip().upper()

        user = authenticate(username=username_or_email, password=password)
        if user is None:
            try:
                user_obj = User.objects.get(email__iexact=username_or_email)
                user = authenticate(username=user_obj.username, password=password)
            except User.DoesNotExist:
                user = None

        if user is None:
            raise serializers.ValidationError(
                "Invalid credentials. If you do not have an account yet, please register first."
            )
        if not user.is_active:
            raise serializers.ValidationError("This user account has been deactivated.")
        if requested_role and user.role != requested_role:
            raise serializers.ValidationError(
                f"This account is registered under the {user.role} role. Please select '{user.role}' to sign in."
            )

        attrs["user"] = user
        return attrs


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "email",
            "role",
            "is_active",
            "date_joined",
            "last_login",
        ]
        read_only_fields = ["id", "date_joined", "last_login"]


class UserCreateUpdateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False, min_length=8)

    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "email",
            "password",
            "role",
            "is_active",
            "date_joined",
            "last_login",
        ]
        read_only_fields = ["id", "date_joined", "last_login"]

    def validate_role(self, value: str) -> str:
        request = self.context.get("request")
        if not request or not request.user.is_authenticated or not request.user.is_admin_role:
            raise serializers.ValidationError("Only Administrators are authorized to assign or modify user roles.")
        if value not in User.Role.values:
            raise serializers.ValidationError(f"Invalid role '{value}'. Must be ADMIN, ENGINEER, or SUPERVISOR.")
        return value

    def create(self, validated_data):
        password = validated_data.pop("password", None)
        if not password:
            raise serializers.ValidationError({"password": "A password of at least 8 characters is required."})
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user

    def update(self, instance, validated_data):
        password = validated_data.pop("password", None)
        for attr, val in validated_data.items():
            setattr(instance, attr, val)
        if password:
            instance.set_password(password)
        instance.save()
        return instance

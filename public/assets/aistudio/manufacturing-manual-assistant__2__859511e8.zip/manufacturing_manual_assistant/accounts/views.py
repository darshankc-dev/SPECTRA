"""
REST API Views for Authentication (/api/auth/*) and User Management (/api/users/*).
"""
import logging
from django.contrib.auth import login, logout
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import User
from .permissions import IsAdminRole
from .serializers import (
    LoginSerializer,
    RegisterSerializer,
    UserCreateUpdateSerializer,
    UserSerializer,
)

logger = logging.getLogger(__name__)


class RegisterAPIView(APIView):
    """POST /api/auth/register/ — Register as ADMIN, SUPERVISOR, or ENGINEER."""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        user = serializer.save()
        logger.info("Registered new user '%s' with role '%s'.", user.username, user.role)
        return Response(
            {
                "message": "Registration successful. You can now sign in with your credentials.",
                "user": UserSerializer(user).data,
            },
            status=status.HTTP_201_CREATED,
        )


class LoginAPIView(APIView):
    """POST /api/auth/login/"""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if not serializer.is_valid():
            logger.warning("Failed login attempt for payload user=%s", request.data.get("username"))
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user = serializer.validated_data["user"]
        login(request, user)
        logger.info("User '%s' (role=%s) logged in successfully.", user.username, user.role)
        return Response(
            {
                "message": "Authentication successful.",
                "user": UserSerializer(user).data,
            },
            status=status.HTTP_200_OK,
        )


class LogoutAPIView(APIView):
    """POST /api/auth/logout/"""

    permission_classes = [IsAuthenticated]

    def post(self, request):
        username = request.user.username
        logout(request)
        logger.info("User '%s' logged out.", username)
        return Response({"message": "Logged out successfully."}, status=status.HTTP_200_OK)


class ProfileAPIView(APIView):
    """GET /api/auth/profile/"""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data, status=status.HTTP_200_OK)


class UserListCreateAPIView(APIView):
    """
    GET /api/users/ — List all users (Admin only)
    POST /api/users/ — Create a new user and assign role (Admin only)
    """

    permission_classes = [IsAdminRole]

    def get(self, request):
        users = User.objects.all().order_by("-date_joined")
        serializer = UserSerializer(users, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = UserCreateUpdateSerializer(data=request.data, context={"request": request})
        if serializer.is_valid():
            user = serializer.save()
            logger.info(
                "Admin '%s' created user '%s' with role '%s'.",
                request.user.username,
                user.username,
                user.role,
            )
            return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserDetailAPIView(APIView):
    """
    PATCH /api/users/{id}/ — Update user details, role, or active status (Admin only)
    DELETE /api/users/{id}/ — Delete a user account (Admin only)
    """

    permission_classes = [IsAdminRole]

    def patch(self, request, pk: int):
        target_user = get_object_or_404(User, pk=pk)
        if target_user.pk == request.user.pk and request.data.get("is_active") is False:
            return Response(
                {"error": "Administrators cannot deactivate their own active account."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        serializer = UserCreateUpdateSerializer(
            target_user, data=request.data, partial=True, context={"request": request}
        )
        if serializer.is_valid():
            updated = serializer.save()
            logger.info(
                "Admin '%s' updated user '%s' (role=%s, active=%s).",
                request.user.username,
                updated.username,
                updated.role,
                updated.is_active,
            )
            return Response(UserSerializer(updated).data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk: int):
        target_user = get_object_or_404(User, pk=pk)
        if target_user.pk == request.user.pk:
            return Response(
                {"error": "Administrators cannot delete their own active account."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        username = target_user.username
        target_user.delete()
        logger.info("Admin '%s' deleted user '%s'.", request.user.username, username)
        return Response(status=status.HTTP_204_NO_CONTENT)

from django.urls import path
from .views import LoginAPIView, LogoutAPIView, ProfileAPIView, RegisterAPIView

urlpatterns = [
    path("register/", RegisterAPIView.as_view(), name="api_auth_register"),
    path("login/", LoginAPIView.as_view(), name="api_auth_login"),
    path("logout/", LogoutAPIView.as_view(), name="api_auth_logout"),
    path("profile/", ProfileAPIView.as_view(), name="api_auth_profile"),
]

import django.contrib.auth.models
import django.contrib.auth.validators
import django.utils.timezone
from django.contrib.auth.hashers import make_password
from django.db import migrations, models


def seed_default_role_accounts(apps, schema_editor):
    User = apps.get_model("accounts", "User")
    defaults = [
        ("admin", "admin@manufacturing.local", "Admin@12345", "ADMIN", True, True),
        ("engineer", "engineer@manufacturing.local", "Engineer@12345", "ENGINEER", False, False),
        ("supervisor", "supervisor@manufacturing.local", "Supervisor@12345", "SUPERVISOR", False, False),
    ]
    for username, email, raw_password, role, is_staff, is_superuser in defaults:
        if not User.objects.filter(username=username).exists():
            User.objects.create(
                username=username,
                email=email,
                password=make_password(raw_password),
                role=role,
                is_active=True,
                is_staff=is_staff,
                is_superuser=is_superuser,
            )


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [
        migrations.CreateModel(
            name="User",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("password", models.CharField(max_length=128, verbose_name="password")),
                ("last_login", models.DateTimeField(blank=True, null=True, verbose_name="last login")),
                ("is_superuser", models.BooleanField(default=False, verbose_name="superuser status")),
                (
                    "username",
                    models.CharField(
                        error_messages={"unique": "A user with that username already exists."},
                        max_length=150,
                        unique=True,
                        validators=[django.contrib.auth.validators.UnicodeUsernameValidator()],
                        verbose_name="username",
                    ),
                ),
                ("first_name", models.CharField(blank=True, max_length=150, verbose_name="first name")),
                ("last_name", models.CharField(blank=True, max_length=150, verbose_name="last name")),
                ("is_staff", models.BooleanField(default=False, verbose_name="staff status")),
                ("is_active", models.BooleanField(default=True, verbose_name="active")),
                ("date_joined", models.DateTimeField(default=django.utils.timezone.now, verbose_name="date joined")),
                ("email", models.EmailField(max_length=254, unique=True)),
                (
                    "role",
                    models.CharField(
                        choices=[("ADMIN", "Admin"), ("ENGINEER", "Engineer"), ("SUPERVISOR", "Supervisor")],
                        db_index=True,
                        default="ENGINEER",
                        max_length=20,
                    ),
                ),
                (
                    "groups",
                    models.ManyToManyField(
                        blank=True,
                        related_name="user_set",
                        related_query_name="user",
                        to="auth.group",
                        verbose_name="groups",
                    ),
                ),
                (
                    "user_permissions",
                    models.ManyToManyField(
                        blank=True,
                        related_name="user_set",
                        related_query_name="user",
                        to="auth.permission",
                        verbose_name="user permissions",
                    ),
                ),
            ],
            options={
                "db_table": "accounts_user",
                "ordering": ["-date_joined"],
                "indexes": [
                    models.Index(fields=["role", "is_active"], name="accounts_us_role_active_idx"),
                    models.Index(fields=["username"], name="accounts_us_usernam_idx"),
                ],
            },
            managers=[
                ("objects", django.contrib.auth.models.UserManager()),
            ],
        ),
        migrations.RunPython(seed_default_role_accounts, migrations.RunPython.noop),
    ]

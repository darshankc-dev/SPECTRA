"""
Server-side Role-Based Access Control (RBAC) permissions for Django REST Framework.
"""
from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsAdminRole(BasePermission):
    """Allows access strictly to active ADMIN users."""

    message = "Access denied: Administrator privileges are required for this action."

    def has_permission(self, request, view) -> bool:
        user = request.user
        return bool(user and user.is_authenticated and user.is_active and (user.role == "ADMIN" or user.is_superuser))


class IsEngineerRole(BasePermission):
    """Allows access strictly to active ENGINEER users."""

    message = "Access denied: Engineer privileges are required."

    def has_permission(self, request, view) -> bool:
        user = request.user
        return bool(user and user.is_authenticated and user.is_active and user.role == "ENGINEER")


class IsSupervisorRole(BasePermission):
    """Allows access strictly to active SUPERVISOR users."""

    message = "Access denied: Supervisor privileges are required."

    def has_permission(self, request, view) -> bool:
        user = request.user
        return bool(user and user.is_authenticated and user.is_active and user.role == "SUPERVISOR")


class IsAdminOrSupervisorRole(BasePermission):
    """Allows access to active ADMIN or SUPERVISOR users."""

    message = "Access denied: Admin or Supervisor privileges are required."

    def has_permission(self, request, view) -> bool:
        user = request.user
        return bool(
            user
            and user.is_authenticated
            and user.is_active
            and (user.role in ("ADMIN", "SUPERVISOR") or user.is_superuser)
        )


class IsAdminOrReadOnlyForAuthenticated(BasePermission):
    """
    Allows read-only access (GET, HEAD, OPTIONS) to any authenticated active user,
    and write access (POST, PUT, PATCH, DELETE) strictly to ADMIN users.
    """

    message = "Access denied: Only Administrators can modify resources."

    def has_permission(self, request, view) -> bool:
        user = request.user
        if not (user and user.is_authenticated and user.is_active):
            return False
        if request.method in SAFE_METHODS:
            return True
        return bool(user.role == "ADMIN" or user.is_superuser)

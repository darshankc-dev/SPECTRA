"""
Custom User model with strict server-side Role-Based Access Control (RBAC).
Roles: ADMIN, ENGINEER, SUPERVISOR.
"""
from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "ADMIN", "Admin"
        ENGINEER = "ENGINEER", "Engineer"
        SUPERVISOR = "SUPERVISOR", "Supervisor"

    email = models.EmailField(unique=True)
    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.ENGINEER,
        db_index=True,
    )

    class Meta:
        db_table = "accounts_user"
        ordering = ["-date_joined"]
        indexes = [
            models.Index(fields=["role", "is_active"]),
            models.Index(fields=["username"]),
        ]

    def save(self, *args, **kwargs):
        if self.is_superuser and self.role != self.Role.ADMIN:
            self.role = self.Role.ADMIN
        super().save(*args, **kwargs)

    @property
    def is_admin_role(self) -> bool:
        return self.is_active and (self.role == self.Role.ADMIN or self.is_superuser)

    @property
    def is_engineer_role(self) -> bool:
        return self.is_active and self.role == self.Role.ENGINEER

    @property
    def is_supervisor_role(self) -> bool:
        return self.is_active and self.role == self.Role.SUPERVISOR

    def __str__(self) -> str:
        return f"{self.username} ({self.role})"

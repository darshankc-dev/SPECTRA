from django.urls import include, path

urlpatterns = [
    path("auth/", include("accounts.urls_auth")),
    path("users/", include("accounts.urls_users")),
]

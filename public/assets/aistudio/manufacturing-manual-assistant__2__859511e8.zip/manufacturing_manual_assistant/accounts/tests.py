"""
Automated tests for Authentication, Role-Based Access Control (TEST 8),
PostgreSQL Verification (TEST 13), and Role Escalation Prevention (TEST 14).
"""
from pathlib import Path
from django.conf import settings
from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient
from .models import User


class AccountsAndDatabaseSecurityTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.admin_user, _ = User.objects.update_or_create(
            username="test_admin",
            defaults={"email": "test_admin@factory.local", "role": User.Role.ADMIN, "is_active": True},
        )
        self.admin_user.set_password("AdminPass@123")
        self.admin_user.save()

        self.engineer_user, _ = User.objects.update_or_create(
            username="test_engineer",
            defaults={"email": "test_engineer@factory.local", "role": User.Role.ENGINEER, "is_active": True},
        )
        self.engineer_user.set_password("EngPass@123")
        self.engineer_user.save()

        self.supervisor_user, _ = User.objects.update_or_create(
            username="test_supervisor",
            defaults={"email": "test_supervisor@factory.local", "role": User.Role.SUPERVISOR, "is_active": True},
        )
        self.supervisor_user.set_password("SupPass@123")
        self.supervisor_user.save()

    def test_13_postgresql_verification_and_sqlite_prohibition(self):
        """TEST 13 — Verify PostgreSQL is the active database and SQLite is never used."""
        engine = settings.DATABASES["default"]["ENGINE"]
        self.assertEqual(engine, "django.db.backends.postgresql")
        self.assertNotIn("sqlite", engine.lower())
        sqlite_file = Path(settings.BASE_DIR) / "db.sqlite3"
        self.assertFalse(sqlite_file.exists(), "db.sqlite3 must never exist in the project directory.")

    def test_08_authentication_and_unauthorized_access(self):
        """TEST 8 — Protected resources remain inaccessible without authentication."""
        res_profile = self.client.get("/api/auth/profile/")
        self.assertIn(res_profile.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN))

        res_users = self.client.get("/api/users/")
        self.assertIn(res_users.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN))

    def test_14_role_escalation_prevention(self):
        """TEST 14 — Attempt to modify a user's role without Admin permission is rejected."""
        self.client.force_authenticate(user=self.engineer_user)
        response = self.client.patch(
            f"/api/users/{self.engineer_user.id}/",
            {"role": "ADMIN"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.engineer_user.refresh_from_db()
        self.assertEqual(self.engineer_user.role, User.Role.ENGINEER)

        # Supervisor also cannot escalate to Admin
        self.client.force_authenticate(user=self.supervisor_user)
        sup_response = self.client.patch(
            f"/api/users/{self.supervisor_user.id}/",
            {"role": "ADMIN"},
            format="json",
        )
        self.assertEqual(sup_response.status_code, status.HTTP_403_FORBIDDEN)
        self.supervisor_user.refresh_from_db()
        self.assertEqual(self.supervisor_user.role, User.Role.SUPERVISOR)

from django.urls import path
from .views import UserDetailAPIView, UserListCreateAPIView

urlpatterns = [
    path("", UserListCreateAPIView.as_view(), name="api_users_list_create"),
    path("<int:pk>/", UserDetailAPIView.as_view(), name="api_users_detail"),
]

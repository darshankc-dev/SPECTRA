import express, { Request, Response, NextFunction } from "express";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import {
  GEMINI_SYSTEM_PROMPT,
  INSUFFICIENT_EVIDENCE_MESSAGE,
  buildGroundedUserPrompt,
  canUserPerformAction,
  chunkExtractedPages,
  retrieveMachineIsolatedChunks,
  synthesizeStructuredTechnicalAnswer,
  validateAndBuildCitations,
} from "./src/lib/ragEngine.ts";
import {
  extractPdfPagesFromBuffer,
  validatePdfBuffer,
} from "./src/lib/pdfExtractor.ts";
import type {
  MachineRecord,
  ManualChunkRecord,
  ManualRecord,
  QueryHistoryRecord,
  UserRecord,
  UserRole,
} from "./src/types.ts";

dotenv.config();

const PORT = 3000;
const WORKSPACE_ROOT = process.cwd();
const MEDIA_MANUALS_DIR = path.resolve(
  WORKSPACE_ROOT,
  "manufacturing_manual_assistant/media/manuals"
);
const PERSIST_STORE_DIR = path.resolve(
  WORKSPACE_ROOT,
  "manufacturing_manual_assistant/vector_store"
);
const STATE_FILE = path.join(PERSIST_STORE_DIR, "runtime_store.json");

fs.mkdirSync(MEDIA_MANUALS_DIR, { recursive: true });
fs.mkdirSync(PERSIST_STORE_DIR, { recursive: true });

// ============================================================================
// SERVER-SIDE GEMINI CLIENT INITIALIZATION (MANDATORY USER-AGENT HEADER)
// ============================================================================
const GEMINI_FLASH_MODEL =
  process.env.GEMINI_FLASH_MODEL || "gemini-3.1-flash-lite-preview";
let geminiCooldownUntil = 0;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey === "YOUR_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`GEMINI_TIMEOUT_${timeoutMs}MS`));
    }, timeoutMs);
    promise
      .then((val) => {
        clearTimeout(timer);
        resolve(val);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

async function generateEmbeddingsServerSide(texts: string[]): Promise<number[][]> {
  if (texts.length === 0) return [];
  return texts.map((t) => buildDeterministicSemanticVector(t, 128));
}

const VECTOR_STOPWORDS = new Set([
  "what", "when", "where", "which", "who", "whom", "whose", "why", "how",
  "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
  "do", "does", "did", "the", "and", "for", "with", "from", "that", "this",
  "these", "those", "into", "onto", "about", "can", "could", "should", "would",
  "may", "might", "must", "shall", "will", "of", "in", "on", "at", "to", "by",
  "hp", "200", "hp200", "hp-200", "ac", "90", "ac90", "ac-90", "machine", "press", "compressor"
]);

function buildDeterministicSemanticVector(text: string, dims = 128): number[] {
  const vec = new Array<number>(dims).fill(0);
  const tokens = text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 2 && !VECTOR_STOPWORDS.has(w));

  for (let idxTok = 0; idxTok < tokens.length; idxTok++) {
    const token = tokens[idxTok];
    const stem =
      token.length > 4
        ? token
            .replace(/(?:ations|ation|ings|ing|ments|ment|ance|ence|edly|ed|ies|es|s)$/, "")
            .slice(0, 8)
        : token;

    const features = [token, `stem:${stem}`];
    if (idxTok + 1 < tokens.length) {
      features.push(`bi:${stem}_${tokens[idxTok + 1].slice(0, 6)}`);
    }

    for (const feat of features) {
      const hash = crypto.createHash("sha256").update(feat).digest();
      for (let i = 0; i < 6; i++) {
        const idx = hash[i] % dims;
        const sign = hash[i + 6] % 2 === 0 ? 1 : -1;
        vec[idx] += sign * 1.0;
      }
    }
  }
  const norm = Math.sqrt(vec.reduce((acc, v) => acc + v * v, 0));
  if (norm === 0) return vec;
  return vec.map((v) => Number((v / norm).toFixed(6)));
}

// ============================================================================
// PERSISTENT RELATIONAL & VECTOR STORE STATE (ZERO SQLITE)
// ============================================================================
interface StoredUser extends UserRecord {
  password_hash: string;
}

interface StoredManualPages {
  manual_id: number;
  pages: Array<{ page_number: number; text: string }>;
}

interface RuntimeDatabase {
  users: StoredUser[];
  machines: MachineRecord[];
  manuals: ManualRecord[];
  chunks: ManualChunkRecord[];
  manual_pages: StoredManualPages[];
  queries: QueryHistoryRecord[];
  sessions?: Record<string, number>;
}

function hashPassword(raw: string): string {
  return crypto.createHash("sha256").update(`mma_salt_${raw}`).digest("hex");
}

function createInitialState(): RuntimeDatabase {
  const now = new Date().toISOString();
  return {
    users: [
      {
        id: 1,
        username: "admin",
        email: "admin@manufacturing.local",
        role: "ADMIN",
        is_active: true,
        date_joined: now,
        last_login: null,
        password_hash: hashPassword("Admin@12345"),
      },
      {
        id: 2,
        username: "engineer",
        email: "engineer@manufacturing.local",
        role: "ENGINEER",
        is_active: true,
        date_joined: now,
        last_login: null,
        password_hash: hashPassword("Engineer@12345"),
      },
      {
        id: 3,
        username: "supervisor",
        email: "supervisor@manufacturing.local",
        role: "SUPERVISOR",
        is_active: true,
        date_joined: now,
        last_login: null,
        password_hash: hashPassword("Supervisor@12345"),
      },
    ],
    machines: [
      {
        id: 1,
        machine_code: "HP200",
        machine_name: "HP-200 Hydraulic Press",
        description:
          "Heavy-duty 200-ton industrial hydraulic press system. Official manuals: HP200_Operations_Rev1_0.pdf & HP200_Maintenance_Rev1_0.pdf.",
        manufacturer: "Apex Heavy Industrial Systems",
        created_at: now,
        updated_at: now,
      },
      {
        id: 2,
        machine_code: "AC90",
        machine_name: "AC-90 Air Compressor",
        description:
          "Rotary screw industrial air compressor unit (90 kW). Official manual: AC90_Operations_Maintenance_Rev1_0.pdf.",
        manufacturer: "AeroForce Pneumatic Corp.",
        created_at: now,
        updated_at: now,
      },
    ],
    // Strictly 0 pre-indexed manuals until Admin uploads the real PDFs
    manuals: [],
    chunks: [],
    manual_pages: [],
    queries: [],
  };
}

function loadState(): RuntimeDatabase {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const raw = fs.readFileSync(STATE_FILE, "utf8");
      const parsed = JSON.parse(raw) as RuntimeDatabase;
      if (parsed && Array.isArray(parsed.users) && Array.isArray(parsed.machines)) {
        return parsed;
      }
    }
  } catch (err) {
    console.error("Failed to read state file, initializing fresh store:", err);
  }
  const initial = createInitialState();
  saveState(initial);
  return initial;
}

function saveState(state: RuntimeDatabase): void {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), "utf8");
}

let dbState: RuntimeDatabase = loadState();
const activeSessions = new Map<string, number>(
  Object.entries(dbState.sessions || {})
); // token -> userId

function syncSessionsToState(): void {
  dbState.sessions = Object.fromEntries(activeSessions.entries());
  saveState(dbState);
}

function stripPassword(u: StoredUser): UserRecord {
  const { password_hash: _, ...rest } = u;
  return rest;
}

function enrichMachine(m: MachineRecord): MachineRecord {
  const machineManuals = dbState.manuals.filter((man) => man.machine === m.id);
  const completedCount = machineManuals.filter(
    (man) => man.processing_status === "COMPLETED"
  ).length;
  return {
    ...m,
    manual_count: machineManuals.length,
    completed_manual_count: completedCount,
  };
}

function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    return authHeader.slice(7).trim();
  }
  const cookieHeader = req.headers.cookie || "";
  const match = cookieHeader.match(/(?:^|;\s*)mma_session=([^;]+)/);
  if (match) return decodeURIComponent(match[1]);
  const queryToken = req.query.token;
  if (typeof queryToken === "string" && queryToken.trim()) {
    return queryToken.trim();
  }
  return null;
}

interface AuthenticatedRequest extends Request {
  currentUser?: UserRecord;
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const token = extractToken(req);
  if (!token || !activeSessions.has(token)) {
    return res.status(401).json({ detail: "Authentication credentials were not provided or expired." });
  }
  const userId = activeSessions.get(token)!;
  const user = dbState.users.find((u) => u.id === userId && u.is_active);
  if (!user) {
    activeSessions.delete(token);
    return res.status(401).json({ detail: "User account is inactive or no longer exists." });
  }
  req.currentUser = stripPassword(user);
  next();
}

function requireRole(roles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.currentUser) {
      return res.status(401).json({ detail: "Authentication required." });
    }
    if (!roles.includes(req.currentUser.role)) {
      return res.status(403).json({
        detail: `Access denied: Role '${req.currentUser.role}' is not authorized. Required: ${roles.join(" or ")}.`,
      });
    }
    next();
  };
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 52428800 },
});

async function runIngestionPipeline(
  manual: ManualRecord,
  pdfBuffer: Buffer
): Promise<ManualRecord> {
  manual.processing_status = "PROCESSING";
  manual.error_message = "";
  manual.updated_at = new Date().toISOString();
  saveState(dbState);

  try {
    const extracted = await extractPdfPagesFromBuffer(pdfBuffer);
    const chunkPayloads = chunkExtractedPages({
      pages: extracted.pages,
      manualId: manual.id,
      machineCode: manual.machine_code,
      machineDbId: manual.machine,
      documentName: manual.document_name,
      revision: manual.revision,
    });

    if (chunkPayloads.length === 0) {
      throw new Error(
        "No meaningful text chunks could be created from the extracted PDF pages."
      );
    }

    const embeddings = await generateEmbeddingsServerSide(
      chunkPayloads.map((c) => c.chunk_text)
    );

    // Idempotent cleanup of any prior chunks/pages for this manual
    dbState.chunks = dbState.chunks.filter((c) => c.manual_id !== manual.id);
    dbState.manual_pages = dbState.manual_pages.filter(
      (mp) => mp.manual_id !== manual.id
    );

    let nextChunkId =
      dbState.chunks.reduce((max, c) => Math.max(max, c.id), 0) + 1;
    const now = new Date().toISOString();

    for (let i = 0; i < chunkPayloads.length; i++) {
      const payload = chunkPayloads[i];
      dbState.chunks.push({
        id: nextChunkId++,
        manual_id: manual.id,
        machine_id: manual.machine,
        machine_code: manual.machine_code,
        document_name: manual.document_name,
        revision: manual.revision,
        chunk_text: payload.chunk_text,
        page_number: payload.page_number,
        chunk_index: payload.chunk_index,
        embedding_reference: payload.chunk_id,
        embedding: embeddings[i] || [],
        metadata: payload.metadata,
        created_at: now,
      });
    }

    dbState.manual_pages.push({
      manual_id: manual.id,
      pages: extracted.pages,
    });

    manual.total_pages = extracted.total_pages;
    manual.chunk_count = chunkPayloads.length;
    manual.processing_status = "COMPLETED";
    manual.error_message = "";
    manual.updated_at = now;
    saveState(dbState);
    return manual;
  } catch (err: any) {
    dbState.chunks = dbState.chunks.filter((c) => c.manual_id !== manual.id);
    dbState.manual_pages = dbState.manual_pages.filter(
      (mp) => mp.manual_id !== manual.id
    );
    manual.processing_status = "FAILED";
    manual.chunk_count = 0;
    manual.error_message = err?.message || "PDF ingestion failed.";
    manual.updated_at = new Date().toISOString();
    saveState(dbState);
    return manual;
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "60mb" }));
  app.use(express.urlencoded({ extended: true, limit: "60mb" }));

  // ==========================================================================
  // 1. AUTHENTICATION ENDPOINTS (/api/auth/*)
  // ==========================================================================
  app.post(["/api/auth/register", "/api/auth/register/"], (req: Request, res: Response) => {
    const username = String(req.body?.username || "").trim();
    const email = String(req.body?.email || "").trim();
    const password = String(req.body?.password || "");
    const role = String(req.body?.role || "ENGINEER").trim().toUpperCase() as UserRole;

    if (!username || username.length < 2) {
      return res.status(400).json({ error: "Username must be at least 2 characters." });
    }
    if (!email || !email.includes("@")) {
      return res.status(400).json({ error: "Please provide a valid email address." });
    }
    if (!password || password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters." });
    }
    if (!["ADMIN", "ENGINEER", "SUPERVISOR"].includes(role)) {
      return res.status(400).json({ error: "Role must be ADMIN, SUPERVISOR, or ENGINEER." });
    }

    const existingUsername = dbState.users.find(
      (u) => u.username.toLowerCase() === username.toLowerCase()
    );
    if (existingUsername) {
      return res.status(400).json({ error: `Username '${username}' is already registered.` });
    }

    const existingEmail = dbState.users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase()
    );
    if (existingEmail) {
      return res.status(400).json({ error: `Email '${email}' is already registered.` });
    }

    const nextId = dbState.users.reduce((max, u) => Math.max(max, u.id), 0) + 1;
    const newUser: StoredUser = {
      id: nextId,
      username,
      email,
      role,
      is_active: true,
      date_joined: new Date().toISOString(),
      last_login: null,
      password_hash: hashPassword(password),
    };

    dbState.users.push(newUser);
    saveState(dbState);

    return res.status(201).json({
      message: "Registration successful. You can now sign in with your credentials.",
      user: stripPassword(newUser),
    });
  });

  app.post(["/api/auth/login", "/api/auth/login/"], (req: Request, res: Response) => {
    const usernameOrEmail = String(req.body?.username || "").trim();
    const password = String(req.body?.password || "");
    const requestedRole = req.body?.role
      ? String(req.body.role).trim().toUpperCase()
      : null;

    if (!usernameOrEmail || !password) {
      return res.status(400).json({ error: "Username/email and password are required." });
    }

    const user = dbState.users.find(
      (u) =>
        u.username.toLowerCase() === usernameOrEmail.toLowerCase() ||
        u.email.toLowerCase() === usernameOrEmail.toLowerCase()
    );
    if (!user || user.password_hash !== hashPassword(password)) {
      return res.status(400).json({ error: "Invalid credentials. If you do not have an account yet, please register first." });
    }
    if (!user.is_active) {
      return res.status(403).json({ error: "This user account has been deactivated." });
    }
    if (requestedRole && user.role !== requestedRole) {
      return res.status(400).json({
        error: `This account is registered under the ${user.role} role. Please select '${user.role}' to sign in.`,
      });
    }

    user.last_login = new Date().toISOString();
    const token = crypto.randomBytes(24).toString("hex");
    activeSessions.set(token, user.id);
    syncSessionsToState();
    res.setHeader(
      "Set-Cookie",
      `mma_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax`
    );

    return res.status(200).json({
      message: "Authentication successful.",
      token,
      user: stripPassword(user),
    });
  });

  app.post(
    ["/api/auth/logout", "/api/auth/logout/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const token = extractToken(req);
      if (token) {
        activeSessions.delete(token);
        syncSessionsToState();
      }
      res.setHeader("Set-Cookie", "mma_session=; Path=/; Max-Age=0");
      return res.status(200).json({ message: "Logged out successfully." });
    }
  );

  app.get(
    ["/api/auth/profile", "/api/auth/profile/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      return res.status(200).json(req.currentUser);
    }
  );

  // ==========================================================================
  // 2. MACHINES ENDPOINTS (/api/machines/*)
  // ==========================================================================
  app.get(
    ["/api/machines", "/api/machines/"],
    requireAuth,
    (_req: AuthenticatedRequest, res: Response) => {
      const list = dbState.machines
        .slice()
        .sort((a, b) => a.machine_code.localeCompare(b.machine_code))
        .map(enrichMachine);
      return res.status(200).json(list);
    }
  );

  app.get(
    ["/api/machines/:id", "/api/machines/:id/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const param = String(req.params.id).trim();
      const machine = dbState.machines.find(
        (m) =>
          String(m.id) === param ||
          m.machine_code.toUpperCase() === param.toUpperCase()
      );
      if (!machine) {
        return res.status(404).json({ detail: "Machine not found." });
      }
      return res.status(200).json(enrichMachine(machine));
    }
  );

  app.post(
    ["/api/machines", "/api/machines/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (req: AuthenticatedRequest, res: Response) => {
      const code = String(req.body?.machine_code || "")
        .trim()
        .toUpperCase();
      const name = String(req.body?.machine_name || "").trim();
      const description = String(req.body?.description || "").trim();
      const manufacturer = String(req.body?.manufacturer || "").trim();

      if (!code || !name) {
        return res
          .status(400)
          .json({ error: "Both machine_code and machine_name are required." });
      }
      if (dbState.machines.some((m) => m.machine_code.toUpperCase() === code)) {
        return res
          .status(400)
          .json({ error: `Machine with code '${code}' already exists.` });
      }

      const now = new Date().toISOString();
      const nextId =
        dbState.machines.reduce((max, m) => Math.max(max, m.id), 0) + 1;
      const newMachine: MachineRecord = {
        id: nextId,
        machine_code: code,
        machine_name: name,
        description,
        manufacturer,
        created_at: now,
        updated_at: now,
      };
      dbState.machines.push(newMachine);
      saveState(dbState);
      return res.status(201).json(enrichMachine(newMachine));
    }
  );

  // ==========================================================================
  // 3. MANUALS ENDPOINTS (/api/manuals/*)
  // ==========================================================================
  app.get(
    ["/api/manuals", "/api/manuals/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      let list = dbState.manuals.slice();
      const machineFilter = String(req.query.machine_id || "").trim();
      if (machineFilter) {
        list = list.filter(
          (m) =>
            String(m.machine) === machineFilter ||
            m.machine_code.toUpperCase() === machineFilter.toUpperCase()
        );
      }
      list.sort((a, b) => b.uploaded_at.localeCompare(a.uploaded_at));
      return res.status(200).json(list);
    }
  );

  app.post(
    ["/api/manuals/upload", "/api/manuals/upload/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      const ct = String(req.headers["content-type"] || "").toLowerCase();
      if (ct.includes("multipart/form-data")) {
        upload.single("file")(req, res, (err: any) => {
          if (err) {
            return res
              .status(400)
              .json({ error: err?.message || "Multipart upload error." });
          }
          next();
        });
      } else {
        next();
      }
    },
    async (req: AuthenticatedRequest, res: Response) => {
      let pdfBuffer: Buffer | null = null;
      let originalFilename = "";

      if (req.file) {
        pdfBuffer = req.file.buffer;
        originalFilename = req.file.originalname;
      } else if (req.body?.file_base64) {
        const rawBase64 = String(req.body.file_base64).replace(
          /^data:application\/pdf;base64,/,
          ""
        );
        pdfBuffer = Buffer.from(rawBase64, "base64");
        originalFilename = String(
          req.body?.original_filename || req.body?.document_name || "manual.pdf"
        ).trim();
      }

      if (!pdfBuffer || pdfBuffer.length === 0) {
        return res.status(400).json({ error: "A PDF file is required." });
      }
      if (!originalFilename.toLowerCase().endsWith(".pdf")) {
        originalFilename = `${originalFilename}.pdf`;
      }

      try {
        validatePdfBuffer(pdfBuffer);
      } catch (err: any) {
        return res.status(400).json({ error: err?.message || "Invalid PDF file." });
      }

      const machineParam = String(req.body?.machine_id || "").trim();
      const revision = String(req.body?.revision || "Rev1.0").trim();
      const customDocName = String(req.body?.document_name || "").trim();
      const replaceExisting =
        req.body?.replace_existing === "true" ||
        req.body?.replace_existing === true ||
        req.body?.replace_existing === undefined;

      const machine = dbState.machines.find(
        (m) =>
          String(m.id) === machineParam ||
          m.machine_code.toUpperCase() === machineParam.toUpperCase()
      );
      if (!machine) {
        return res
          .status(400)
          .json({ error: `Valid machine association required. '${machineParam}' not found.` });
      }

      const documentName = customDocName || originalFilename;
      const existing = dbState.manuals.find(
        (m) =>
          m.machine === machine.id &&
          m.document_name.toLowerCase() === documentName.toLowerCase() &&
          m.revision.toLowerCase() === revision.toLowerCase()
      );

      if (existing && !replaceExisting) {
        return res.status(400).json({
          error: `Manual '${documentName}' (${revision}) already exists for ${machine.machine_code}. Enable 'Replace existing manual' or click Re-index.`,
        });
      }

      const safeDiskName = `${machine.machine_code}_${Date.now()}_${path
        .basename(documentName)
        .replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const diskPath = path.join(MEDIA_MANUALS_DIR, safeDiskName);
      fs.writeFileSync(diskPath, pdfBuffer);

      const now = new Date().toISOString();
      let manual: ManualRecord;

      if (existing) {
        if (existing.file_path && fs.existsSync(existing.file_path)) {
          try {
            fs.unlinkSync(existing.file_path);
          } catch {}
        }
        existing.original_filename = originalFilename;
        existing.file_path = diskPath;
        existing.file_size = pdfBuffer.length;
        existing.uploaded_by = req.currentUser!.id;
        existing.uploaded_by_username = req.currentUser!.username;
        existing.updated_at = now;
        manual = existing;
      } else {
        const nextId =
          dbState.manuals.reduce((max, m) => Math.max(max, m.id), 0) + 1;
        manual = {
          id: nextId,
          machine: machine.id,
          machine_code: machine.machine_code,
          machine_name: machine.machine_name,
          document_name: documentName,
          original_filename: originalFilename,
          revision,
          file_path: diskPath,
          total_pages: 0,
          file_size: pdfBuffer.length,
          processing_status: "PENDING",
          error_message: "",
          chunk_count: 0,
          uploaded_by: req.currentUser!.id,
          uploaded_by_username: req.currentUser!.username,
          uploaded_at: now,
          updated_at: now,
        };
        dbState.manuals.push(manual);
      }

      const processed = await runIngestionPipeline(manual, pdfBuffer);
      const statusCode = processed.processing_status === "COMPLETED" ? 201 : 422;
      return res.status(statusCode).json(processed);
    }
  );

  app.get(
    ["/api/manuals/:id", "/api/manuals/:id/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const manual = dbState.manuals.find((m) => m.id === id);
      if (!manual) {
        return res.status(404).json({ detail: "Manual not found." });
      }
      return res.status(200).json(manual);
    }
  );

  app.delete(
    ["/api/manuals/:id", "/api/manuals/:id/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const idx = dbState.manuals.findIndex((m) => m.id === id);
      if (idx === -1) {
        return res.status(404).json({ detail: "Manual not found." });
      }
      const manual = dbState.manuals[idx];
      if (manual.file_path && fs.existsSync(manual.file_path)) {
        try {
          fs.unlinkSync(manual.file_path);
        } catch {}
      }
      dbState.manuals.splice(idx, 1);
      dbState.chunks = dbState.chunks.filter((c) => c.manual_id !== id);
      dbState.manual_pages = dbState.manual_pages.filter((mp) => mp.manual_id !== id);
      saveState(dbState);
      return res.status(204).send();
    }
  );

  app.post(
    ["/api/manuals/:id/reprocess", "/api/manuals/:id/reprocess/"],
    requireAuth,
    requireRole(["ADMIN"]),
    async (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const manual = dbState.manuals.find((m) => m.id === id);
      if (!manual) {
        return res.status(404).json({ detail: "Manual not found." });
      }
      if (!manual.file_path || !fs.existsSync(manual.file_path)) {
        return res
          .status(400)
          .json({ error: "Original PDF file is missing from disk; please re-upload." });
      }
      const buffer = fs.readFileSync(manual.file_path);
      const processed = await runIngestionPipeline(manual, buffer);
      const statusCode = processed.processing_status === "COMPLETED" ? 200 : 422;
      return res.status(statusCode).json(processed);
    }
  );

  app.get(
    ["/api/manuals/:id/file", "/api/manuals/:id/file/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const manual = dbState.manuals.find((m) => m.id === id);
      if (!manual) {
        return res.status(404).json({ error: "Manual not found." });
      }

      const expectedMachine = String(req.query.machine_id || "").trim();
      if (
        expectedMachine &&
        expectedMachine.toUpperCase() !== manual.machine_code.toUpperCase() &&
        expectedMachine !== String(manual.machine)
      ) {
        return res.status(403).json({
          error:
            "Machine isolation violation: Requested manual does not belong to the selected machine.",
        });
      }

      if (!manual.file_path || !fs.existsSync(manual.file_path)) {
        return res.status(404).json({ error: "PDF file not found on disk." });
      }
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `inline; filename="${manual.document_name}"`
      );
      return fs.createReadStream(manual.file_path).pipe(res);
    }
  );

  app.get(
    ["/api/manuals/:id/pages", "/api/manuals/:id/pages/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const manual = dbState.manuals.find((m) => m.id === id);
      if (!manual) {
        return res.status(404).json({ error: "Manual not found." });
      }
      const expectedMachine = String(req.query.machine_id || "").trim();
      if (
        expectedMachine &&
        expectedMachine.toUpperCase() !== manual.machine_code.toUpperCase() &&
        expectedMachine !== String(manual.machine)
      ) {
        return res.status(403).json({
          error:
            "Machine isolation violation: Requested manual does not belong to the selected machine.",
        });
      }
      const pageEntry = dbState.manual_pages.find((mp) => mp.manual_id === id);
      return res.status(200).json({
        manual,
        pages: pageEntry ? pageEntry.pages : [],
      });
    }
  );

  // ==========================================================================
  // 4. CORE RAG ASSISTANT ENDPOINTS (/api/assistant/*)
  // ==========================================================================
  app.post(
    ["/api/assistant/ask", "/api/assistant/ask/"],
    requireAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      const rawMachine = String(req.body?.machine_id || "").trim();
      const question = String(req.body?.question || "").trim();

      if (!rawMachine) {
        return res.status(400).json({ error: "Please select an industrial machine." });
      }
      if (question.length < 3) {
        return res
          .status(400)
          .json({ error: "Please enter a technical question (at least 3 characters)." });
      }

      const selectedMachine = dbState.machines.find(
        (m) =>
          String(m.id) === rawMachine ||
          m.machine_code.toUpperCase() === rawMachine.toUpperCase()
      );
      if (!selectedMachine) {
        return res
          .status(400)
          .json({ error: `Selected machine '${rawMachine}' is not registered.` });
      }

      try {
        const completedManualsForMachine = dbState.manuals.filter(
          (m) =>
            m.machine === selectedMachine.id &&
            m.processing_status === "COMPLETED"
        );

        let generatedAnswer = INSUFFICIENT_EVIDENCE_MESSAGE;
        let confidenceStatus: QueryHistoryRecord["confidence_status"] =
          "INSUFFICIENT_EVIDENCE";
        let finalCitations: QueryHistoryRecord["citations"] = [];

        if (completedManualsForMachine.length > 0) {
          const [queryEmbedding] = await generateEmbeddingsServerSide([question]);
          const retrievedChunks = retrieveMachineIsolatedChunks({
            allChunks: dbState.chunks,
            selectedMachine,
            queryEmbedding: queryEmbedding || [],
            question,
            topK: Number(process.env.RAG_TOP_K || 5),
            similarityThreshold: Number(process.env.RAG_SIMILARITY_THRESHOLD || 0.14),
          });

          const validatedCitations = validateAndBuildCitations({
            selectedMachine,
            retrievedChunks,
            manuals: dbState.manuals,
          });

          const validKeySet = new Set(
            validatedCitations.map(
              (c) => `${c.manual_id}:${c.page_number}:${c.chunk_index}`
            )
          );
          const verifiedEvidence = retrievedChunks.filter((ch) =>
            validKeySet.has(`${ch.manual_id}:${ch.page_number}:${ch.chunk_index}`)
          );

          if (verifiedEvidence.length > 0) {
            const ai = Date.now() >= geminiCooldownUntil ? getGeminiClient() : null;
            let resolvedWithModel = false;

            if (ai) {
              try {
                const userPrompt = buildGroundedUserPrompt({
                  machineCode: selectedMachine.machine_code,
                  machineName: selectedMachine.machine_name,
                  question,
                  evidenceChunks: verifiedEvidence,
                });
                const response = await withTimeout(
                  ai.models.generateContent({
                    model: GEMINI_FLASH_MODEL,
                    contents: userPrompt,
                    config: {
                      systemInstruction: GEMINI_SYSTEM_PROMPT,
                    },
                  }),
                  1800
                );
                const modelText = (response.text ?? "").trim();
                const lower = modelText.toLowerCase();
                if (
                  modelText &&
                  !lower.startsWith(INSUFFICIENT_EVIDENCE_MESSAGE.toLowerCase()) &&
                  !lower.startsWith("i couldn't find sufficient supporting information")
                ) {
                  generatedAnswer = modelText;
                  confidenceStatus = "SUPPORTED";
                  finalCitations = validatedCitations;
                  resolvedWithModel = true;
                }
              } catch (genErr: any) {
                // Trip 120s circuit breaker so subsequent requests respond in <15ms without waiting on 503 retries
                geminiCooldownUntil = Date.now() + 120_000;
                console.warn(
                  "Gemini generation timed out or 503; using structured grounded evidence synthesizer:",
                  genErr?.message || genErr
                );
              }
            }

            if (!resolvedWithModel) {
              generatedAnswer = synthesizeStructuredTechnicalAnswer({
                machineCode: selectedMachine.machine_code,
                machineName: selectedMachine.machine_name,
                question,
                evidenceChunks: verifiedEvidence,
              });
              confidenceStatus = "SUPPORTED";
              finalCitations = validatedCitations;
            }
          }
        }

        const nextId =
          dbState.queries.reduce((max, q) => Math.max(max, q.id), 0) + 1;
        const record: QueryHistoryRecord = {
          id: nextId,
          user: req.currentUser!.id,
          username: req.currentUser!.username,
          user_role: req.currentUser!.role,
          machine: selectedMachine.id,
          machine_code: selectedMachine.machine_code,
          machine_name: selectedMachine.machine_name,
          question,
          generated_answer: generatedAnswer,
          citations: finalCitations,
          confidence_status: confidenceStatus,
          created_at: new Date().toISOString(),
        };
        dbState.queries.unshift(record);
        saveState(dbState);

        return res.status(200).json(record);
      } catch (err: any) {
        console.error("RAG Assistant Error:", err);
        return res.status(503).json({
          error:
            err?.message ||
            "The AI retrieval or generation service encountered an error. Please check your configuration and try again.",
        });
      }
    }
  );

  app.get(
    ["/api/assistant/history", "/api/assistant/history/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      let list = dbState.queries.slice();
      if (req.currentUser!.role === "ENGINEER") {
        list = list.filter((q) => q.user === req.currentUser!.id);
      }
      const machineFilter = String(req.query.machine_id || "").trim();
      if (machineFilter) {
        list = list.filter(
          (q) =>
            String(q.machine) === machineFilter ||
            q.machine_code.toUpperCase() === machineFilter.toUpperCase()
        );
      }
      const confidenceFilter = String(req.query.confidence_status || "").trim();
      if (confidenceFilter) {
        list = list.filter(
          (q) => q.confidence_status.toUpperCase() === confidenceFilter.toUpperCase()
        );
      }
      return res.status(200).json(list);
    }
  );

  app.get(
    ["/api/assistant/history/:id", "/api/assistant/history/:id/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const item = dbState.queries.find((q) => q.id === id);
      if (!item) {
        return res.status(404).json({ detail: "Query history record not found." });
      }
      if (
        req.currentUser!.role === "ENGINEER" &&
        item.user !== req.currentUser!.id
      ) {
        return res.status(403).json({
          detail: "Access denied: Engineers may only access their own query history.",
        });
      }
      return res.status(200).json(item);
    }
  );

  // ==========================================================================
  // 5. DASHBOARD ANALYTICS ENDPOINTS (/api/dashboard/*)
  // ==========================================================================
  app.get(
    ["/api/dashboard/admin", "/api/dashboard/admin/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (_req: AuthenticatedRequest, res: Response) => {
      const indexedManuals = dbState.manuals.filter(
        (m) => m.processing_status === "COMPLETED"
      ).length;
      const failedJobs = dbState.manuals.filter(
        (m) => m.processing_status === "FAILED"
      ).length;
      const pendingJobs = dbState.manuals.filter(
        (m) =>
          m.processing_status === "PENDING" ||
          m.processing_status === "PROCESSING"
      ).length;

      return res.status(200).json({
        total_users: dbState.users.length,
        total_machines: dbState.machines.length,
        total_manuals: dbState.manuals.length,
        indexed_manuals: indexedManuals,
        failed_processing_jobs: failedJobs,
        pending_processing_jobs: pendingJobs,
        total_chunks: dbState.chunks.length,
        total_queries: dbState.queries.length,
        recent_uploads: dbState.manuals.slice(0, 10),
        recent_activities: dbState.queries.slice(0, 10),
      });
    }
  );

  app.get(
    ["/api/dashboard/engineer", "/api/dashboard/engineer/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const userQueries = dbState.queries.filter(
        (q) => q.user === req.currentUser!.id
      );
      const supportedCount = userQueries.filter(
        (q) => q.confidence_status === "SUPPORTED"
      ).length;

      return res.status(200).json({
        user_query_count: userQueries.length,
        supported_query_count: supportedCount,
        machines: dbState.machines.map(enrichMachine),
        recent_questions: userQueries.slice(0, 15),
      });
    }
  );

  app.get(
    ["/api/dashboard/supervisor", "/api/dashboard/supervisor/"],
    requireAuth,
    requireRole(["SUPERVISOR", "ADMIN"]),
    (_req: AuthenticatedRequest, res: Response) => {
      const supportedCount = dbState.queries.filter(
        (q) => q.confidence_status === "SUPPORTED"
      ).length;
      const unsupportedQueries = dbState.queries.filter(
        (q) => q.confidence_status === "INSUFFICIENT_EVIDENCE"
      );

      const machineDistribution = dbState.machines.map((m) => ({
        id: m.id,
        machine_code: m.machine_code,
        machine_name: m.machine_name,
        query_count: dbState.queries.filter((q) => q.machine === m.id).length,
        supported_count: dbState.queries.filter(
          (q) => q.machine === m.id && q.confidence_status === "SUPPORTED"
        ).length,
        unsupported_count: dbState.queries.filter(
          (q) =>
            q.machine === m.id &&
            q.confidence_status === "INSUFFICIENT_EVIDENCE"
        ).length,
      }));

      const engineerActivity = dbState.users
        .filter((u) => u.role === "ENGINEER")
        .map((u) => ({
          id: u.id,
          username: u.username,
          email: u.email,
          query_count: dbState.queries.filter((q) => q.user === u.id).length,
          last_login: u.last_login,
        }));

      return res.status(200).json({
        total_queries: dbState.queries.length,
        supported_queries: supportedCount,
        unsupported_queries_count: unsupportedQueries.length,
        machine_distribution: machineDistribution,
        engineer_activity: engineerActivity,
        unsupported_questions: unsupportedQueries.slice(0, 25),
        recent_queries: dbState.queries.slice(0, 30),
        manual_processing_status: dbState.manuals,
      });
    }
  );

  // ==========================================================================
  // 6. USER MANAGEMENT ENDPOINTS (/api/users/*)
  // ==========================================================================
  app.get(
    ["/api/users", "/api/users/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (_req: AuthenticatedRequest, res: Response) => {
      return res.status(200).json(dbState.users.map(stripPassword));
    }
  );

  app.post(
    ["/api/users", "/api/users/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (req: AuthenticatedRequest, res: Response) => {
      const username = String(req.body?.username || "").trim();
      const email = String(req.body?.email || "").trim();
      const password = String(req.body?.password || "");
      const role = String(req.body?.role || "ENGINEER")
        .trim()
        .toUpperCase() as UserRole;

      if (!username || !email || password.length < 8) {
        return res.status(400).json({
          error:
            "Username, email, and a password of at least 8 characters are required.",
        });
      }
      if (!["ADMIN", "ENGINEER", "SUPERVISOR"].includes(role)) {
        return res
          .status(400)
          .json({ error: "Invalid role. Must be ADMIN, ENGINEER, or SUPERVISOR." });
      }
      if (
        dbState.users.some(
          (u) =>
            u.username.toLowerCase() === username.toLowerCase() ||
            u.email.toLowerCase() === email.toLowerCase()
        )
      ) {
        return res
          .status(400)
          .json({ error: "A user with that username or email already exists." });
      }

      const nextId =
        dbState.users.reduce((max, u) => Math.max(max, u.id), 0) + 1;
      const newUser: StoredUser = {
        id: nextId,
        username,
        email,
        role,
        is_active: req.body?.is_active !== false,
        date_joined: new Date().toISOString(),
        last_login: null,
        password_hash: hashPassword(password),
      };
      dbState.users.push(newUser);
      saveState(dbState);
      return res.status(201).json(stripPassword(newUser));
    }
  );

  app.patch(
    ["/api/users/:id", "/api/users/:id/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      const target = dbState.users.find((u) => u.id === id);
      if (!target) {
        return res.status(404).json({ detail: "User not found." });
      }
      if (target.id === req.currentUser!.id && req.body?.is_active === false) {
        return res
          .status(400)
          .json({ error: "Administrators cannot deactivate their own account." });
      }
      if (req.body?.role) {
        const newRole = String(req.body.role).trim().toUpperCase() as UserRole;
        if (!["ADMIN", "ENGINEER", "SUPERVISOR"].includes(newRole)) {
          return res.status(400).json({ error: "Invalid role." });
        }
        target.role = newRole;
      }
      if (typeof req.body?.is_active === "boolean") {
        target.is_active = req.body.is_active;
      }
      if (req.body?.email) {
        target.email = String(req.body.email).trim();
      }
      if (req.body?.password && String(req.body.password).length >= 8) {
        target.password_hash = hashPassword(String(req.body.password));
      }
      saveState(dbState);
      return res.status(200).json(stripPassword(target));
    }
  );

  app.delete(
    ["/api/users/:id", "/api/users/:id/"],
    requireAuth,
    requireRole(["ADMIN"]),
    (req: AuthenticatedRequest, res: Response) => {
      const id = Number(req.params.id);
      if (id === req.currentUser!.id) {
        return res
          .status(400)
          .json({ error: "Administrators cannot delete their own active account." });
      }
      const idx = dbState.users.findIndex((u) => u.id === id);
      if (idx === -1) {
        return res.status(404).json({ detail: "User not found." });
      }
      dbState.users.splice(idx, 1);
      saveState(dbState);
      return res.status(204).send();
    }
  );

  // ==========================================================================
  // 7. DJANGO + POSTGRESQL PROJECT BUNDLE INSPECTOR (/api/django-bundle/*)
  // ==========================================================================
  app.get(
    ["/api/django-bundle/info", "/api/django-bundle/info/"],
    requireAuth,
    (_req: AuthenticatedRequest, res: Response) => {
      const djangoRoot = path.resolve(
        WORKSPACE_ROOT,
        "manufacturing_manual_assistant"
      );
      const files: string[] = [];
      function walk(dir: string) {
        if (!fs.existsSync(dir)) return;
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          if (
            entry.name === "__pycache__" ||
            entry.name === "vector_store" ||
            entry.name === "logs" ||
            entry.name === "media" ||
            entry.name.endsWith(".pyc")
          ) {
            continue;
          }
          const full = path.join(dir, entry.name);
          if (entry.isDirectory()) {
            walk(full);
          } else {
            files.push(path.relative(djangoRoot, full));
          }
        }
      }
      walk(djangoRoot);
      files.sort();
      return res.status(200).json({
        project_directory: "manufacturing_manual_assistant/",
        database_engine: "django.db.backends.postgresql",
        sqlite_prohibited: true,
        file_count: files.length,
        files,
      });
    }
  );

  app.get(
    ["/api/django-bundle/file", "/api/django-bundle/file/"],
    requireAuth,
    (req: AuthenticatedRequest, res: Response) => {
      const relPath = String(req.query.path || "").trim();
      const djangoRoot = path.resolve(
        WORKSPACE_ROOT,
        "manufacturing_manual_assistant"
      );
      const resolved = path.resolve(djangoRoot, relPath);
      if (!resolved.startsWith(djangoRoot) || !fs.existsSync(resolved)) {
        return res.status(404).json({ error: "File not found in Django project." });
      }
      const content = fs.readFileSync(resolved, "utf8");
      return res.status(200).json({ path: relPath, content });
    }
  );

  // Ensure any unmatched /api/* route or /api/* error returns JSON, never HTML
  app.all("/api/*", (req: Request, res: Response) => {
    return res.status(404).json({
      error: `API endpoint not found: ${req.method} ${req.originalUrl}`,
    });
  });

  app.use(
    (err: any, req: Request, res: Response, next: NextFunction) => {
      if (req.path.startsWith("/api/")) {
        return res.status(err?.status || 400).json({
          error: err?.message || "Unexpected error processing API request.",
        });
      }
      next(err);
    }
  );

  // Mount Vite dev server in development or static dist in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(WORKSPACE_ROOT, "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Auto-index any official manual PDF already uploaded to media/manuals if store is empty
  if (dbState.manuals.length === 0 && fs.existsSync(MEDIA_MANUALS_DIR)) {
    const diskFiles = fs.readdirSync(MEDIA_MANUALS_DIR);
    const maintFile = diskFiles.find((f) =>
      f.includes("HP200_Maintenance_Rev1_0.pdf")
    );
    const hp200 = dbState.machines.find((m) => m.machine_code === "HP200");
    if (maintFile && hp200) {
      try {
        const fullPath = path.join(MEDIA_MANUALS_DIR, maintFile);
        const buf = fs.readFileSync(fullPath);
        const now = new Date().toISOString();
        const manualRecord: ManualRecord = {
          id: 1,
          machine: hp200.id,
          machine_code: hp200.machine_code,
          machine_name: hp200.machine_name,
          document_name: "HP200_Maintenance_Rev1_0.pdf",
          original_filename: "HP200_Maintenance_Rev1_0.pdf",
          revision: "Rev1.0",
          file_path: fullPath,
          total_pages: 0,
          file_size: buf.length,
          processing_status: "PENDING",
          error_message: "",
          chunk_count: 0,
          uploaded_by: 1,
          uploaded_by_username: "admin",
          uploaded_at: now,
          updated_at: now,
        };
        dbState.manuals.push(manualRecord);
        await runIngestionPipeline(manualRecord, buf);
      } catch (e) {
        console.warn("Startup manual recovery skipped:", e);
      }
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(
      `Manufacturing Manual Assistant running on http://0.0.0.0:${PORT}`
    );
  });
}

startServer();

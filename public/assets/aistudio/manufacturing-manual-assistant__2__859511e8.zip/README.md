# Manufacturing Manual Assistant

Complete AI-powered Industrial Equipment Documentation & Machine-Isolated RAG Application.

- **Django + PostgreSQL + ChromaDB + PyMuPDF + Gemini Project**: Located in [`./manufacturing_manual_assistant/`](./manufacturing_manual_assistant/) (with identical mirror endpoints running live on Port 3000 in the AI Studio preview environment).
- **Mandatory Database Policy**: Configured strictly for **PostgreSQL** (`django.db.backends.postgresql`). **SQLite (`db.sqlite3`) is strictly prohibited and never used.**

Please see [`manufacturing_manual_assistant/README.md`](./manufacturing_manual_assistant/README.md) for the complete 22-section setup, Windows PowerShell commands, local PostgreSQL configuration, PDF upload workflow, REST API specification, and automated test instructions.
